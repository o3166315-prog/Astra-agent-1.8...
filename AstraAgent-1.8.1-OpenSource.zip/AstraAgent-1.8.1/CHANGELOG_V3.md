# Kairo V3 — 6 octobre 2026

Cette version rassemble la dernière série de corrections UX et agent demandées aujourd’hui.

## Interface
- Menu `File` centralisé.
- Ouverture d’un projet/dossier et d’un fichier local.
- `New Project` crée un vrai dossier de projet sur le Desktop et l’ouvre immédiatement.
- `New File` et `New Folder` créent directement dans le workspace actif.
- Icônes internes Kairo en SVG.
- Indicateur d’activité avec le symbole `K` animé lorsque l’agent travaille.
- Support clair / sombre / bleu nuit conservé.
- Mise en page responsive pour réduire les panneaux coupés.

## Agent
- Contexte ciblé plutôt que balayage complet inutile.
- Raisonnement opérationnel concis : le modèle peut fournir une courte raison avant une action.
- Plan adaptatif pour les tâches importantes.
- Autorisation implicite pour les actions explicitement demandées, protections maintenues pour les actions sensibles.
- Détection de répétition non destructive.

## Boucles
Au lieu d’arrêter automatiquement l’agent, Kairo affiche :

- `Sauter cette étape`
- `Arrêter l’agent`

Le choix est laissé à l’utilisateur.

## Architecture conservée
- Node.js sans migration vers React/Vue/TypeScript.
- Providers existants conservés.
- MCP conservé.
- Stockage JSON conservé.
- Diff / sauvegarde / restauration conservés.
