'use strict';
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');

const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'astra-hardening-'));
process.env.ASTRA_DATA = path.join(TMP, 'data');

const pathGuard = require('../server/path-guard');
const perms = require('../server/perms');
const tools = require('../server/tools');
const moretools = require('../server/moretools');
const { manager } = require('../server/time-machine');
const S = require('../server/store');
const REC = require('../server/recovery');
const TEST = require('../server/auto-testing');
const HEAL = require('../server/self-healing');

let ok = 0;
function T(name, fn) {
  try { fn(); ok++; console.log('  ✓ ' + name); }
  catch (error) { console.error('  ✗ ' + name + '\n    ' + (error.stack || error.message)); process.exitCode = 1; }
}

try {
  const root = path.join(TMP, 'project');
  const outside = path.join(TMP, 'outside');
  fs.mkdirSync(root, { recursive: true });
  fs.mkdirSync(outside, { recursive: true });
  fs.writeFileSync(path.join(outside, 'secret.txt'), 'outside-secret');
  fs.writeFileSync(path.join(root, 'index.js'), 'console.log("ok")');

  console.log('Path guard / sandbox');
  T('refuse la racine système et le dossier personnel comme workspace', () => {
    assert.throws(() => pathGuard.canonicalProjectRoot(path.parse(process.cwd()).root), /racine du système/i);
    assert.throws(() => pathGuard.canonicalProjectRoot(os.homedir()), /dossier personnel/i);
  });
  T('refuse un workspace dont le chemin parent contient un lien symbolique', () => {
    const link = path.join(TMP, 'root-link');
    fs.symlinkSync(root, link, 'dir');
    assert.throws(() => pathGuard.canonicalProjectRoot(path.join(link, 'sub')), /Lien symbolique refusé/);
  });
  T('safe(), perms.norm() et walk() refusent les liens symboliques du projet', () => {
    const link = path.join(root, 'escape');
    fs.symlinkSync(outside, link, 'dir');
    assert.throws(() => tools.safe(root, 'escape/secret.txt'), /Lien symbolique refusé/);
    assert.throws(() => perms.norm('escape/secret.txt', root), /Lien symbolique refusé/);
    assert.throws(() => tools.walk(root, root), /Lien symbolique refusé/);
    assert.throws(() => manager(path.join(TMP, 'tm-data')).snapshot('p', root), /Lien symbolique refusé/);
    fs.unlinkSync(link);
  });
  T('refuse aussi les liens matériels vers un fichier extérieur', () => {
    const linked = path.join(root, 'linked-secret.txt');
    try { fs.linkSync(path.join(outside, 'secret.txt'), linked); }
    catch (error) {
      if (['EPERM', 'EACCES', 'ENOSYS', 'ENOTSUP', 'EOPNOTSUPP'].includes(error.code)) {
        console.log('    (liens matériels indisponibles sur ce système : contrôle ignoré)');
        return;
      }
      throw error;
    }
    assert.throws(() => tools.safe(root, 'linked-secret.txt'), /Lien matériel refusé/);
    assert.throws(() => perms.norm('linked-secret.txt', root), /Lien matériel refusé/);
    fs.unlinkSync(linked);
  });

  console.log('Calculatrice sécurisée');
  T('calcule les opérations et fonctions mathématiques autorisées', () => {
    assert.strictEqual(moretools.calc('(12 + 8) * 3'), 60);
    assert.strictEqual(moretools.calc('sqrt(16) + max(1, 5)'), 9);
    assert.strictEqual(moretools.calc('sin(PI / 2)'), 1);
    assert.strictEqual(moretools.calc('2^3^2'), 512);
    assert.strictEqual(moretools.calc('1e3 + 1'), 1001);
  });
  T('bloque les accès propriétés et les constructions JavaScript', () => {
    for (const expr of ['(1).asin', '(1).constructor', 'Math.PI', 'globalThis.process', 'process.exit()', 'x=1', '1;2']) {
      assert.throws(() => moretools.calc(expr), undefined, expr + ' doit être refusé');
    }
  });
  T('classe les scripts de test npm comme opérations à confirmer', () => {
    assert.strictEqual(perms.classifyCommand('npm test', root).level, 'CONFIRM');
  });

  console.log('Stockage atomique');
  T('écrit un JSON complet avec remplacement atomique, sans fichier temporaire résiduel', () => {
    S.write('settings.json', { ollama: { url: 'http://localhost:11434' } });
    S.write('settings.json', { ollama: { url: 'http://localhost:11434', key: 'test-key' } });
    const parsed = JSON.parse(fs.readFileSync(path.join(S.dataDir, 'settings.json'), 'utf8'));
    assert.strictEqual(parsed.ollama.url, 'http://localhost:11434');
    assert.strictEqual(parsed.ollama.key, 'test-key');
    assert(!fs.readdirSync(S.dataDir).some(x => x.endsWith('.tmp')));
  });

  console.log('Recovery / Time Machine');
  T('Recovery partage Time Machine et met les fichiers excédentaires en quarantaine', () => {
    const project = path.join(TMP, 'recovery-project');
    fs.mkdirSync(project, { recursive: true });
    fs.writeFileSync(path.join(project, 'before.txt'), 'before');
    const snap = REC.snapshotProject(project, 'hardening-test', 'avant modification');
    fs.writeFileSync(path.join(project, 'extra.txt'), 'keep-me');
    const restored = REC.restoreSnapshot(project, 'hardening-test', snap.id);
    assert.strictEqual(fs.readFileSync(path.join(project, 'before.txt'), 'utf8'), 'before');
    assert.strictEqual(fs.existsSync(path.join(project, 'extra.txt')), false);
    assert.strictEqual(restored.quarantined, 1);
    const qFile = path.join(restored.quarantine, 'extra.txt');
    assert.strictEqual(fs.readFileSync(qFile, 'utf8'), 'keep-me');
    assert(REC.listSnapshots('hardening-test').length >= 2, 'snapshot original + sauvegarde avant restauration');
  });
  T('l’export exclut .env et refuse les liens symboliques', () => {
    const project = path.join(TMP, 'export-project');
    fs.mkdirSync(project, { recursive: true });
    fs.writeFileSync(path.join(project, '.env'), 'TOP_SECRET=' + crypto.randomBytes(8).toString('hex'));
    fs.writeFileSync(path.join(project, 'app.js'), 'module.exports = 1');
    const listed = REC.listFiles(project);
    assert(listed.files.some(x => x.rel === 'app.js'));
    assert(!listed.files.some(x => x.rel === '.env'));
    fs.symlinkSync(outside, path.join(project, 'shortcut'), 'dir');
    assert.throws(() => REC.listFiles(project), /lien symbolique/i);
  });

  console.log('Self-Healing / Auto Testing');
  T('Self-Healing réalise un scan statique en lecture seule', () => {
    const project = path.join(TMP, 'healing-project');
    fs.mkdirSync(project, { recursive: true });
    fs.writeFileSync(path.join(project, 'ok.js'), 'const x = 1;');
    fs.writeFileSync(path.join(project, 'bad.json'), '{');
    const scan = HEAL.scanProject(project);
    assert.strictEqual(scan.status, 'issues');
    assert(scan.issues.some(x => x.file === 'bad.json' && x.kind === 'json'));
    assert(fs.existsSync(path.join(project, 'bad.json')), 'aucune modification du fichier');
  });
  T('Auto Testing détecte un script de test, mais n’exécute rien à la détection', () => {
    const project = path.join(TMP, 'test-project');
    fs.mkdirSync(project, { recursive: true });
    fs.writeFileSync(path.join(project, 'package.json'), JSON.stringify({ scripts: { test: 'node --version' } }));
    assert.strictEqual(TEST.detectTest(project), 'npm test');
    assert.deepStrictEqual(TEST.reports('hardening-project'), []);
  });

  console.log('\n' + ok + ' contrôles de durcissement réussis');
} finally {
  fs.rmSync(TMP, { recursive: true, force: true });
}
