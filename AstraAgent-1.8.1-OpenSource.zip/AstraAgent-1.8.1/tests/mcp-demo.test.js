'use strict';
const assert = require('assert');
const { spawnSync } = require('child_process');
const path = require('path');

const input = [
  { jsonrpc: '2.0', id: 1, method: 'initialize', params: { protocolVersion: '2024-11-05' } },
  { jsonrpc: '2.0', id: 2, method: 'tools/call', params: { name: 'calculate', arguments: { expression: '2^3 + sqrt(9)' } } },
  { jsonrpc: '2.0', id: 3, method: 'tools/call', params: { name: 'calculate', arguments: { expression: '(1).constructor.constructor("return process")()' } } }
].map(x => JSON.stringify(x)).join('\n') + '\n';

const result = spawnSync(process.execPath, [path.resolve(__dirname, '../mcp-demo/server.js')], {
  input,
  encoding: 'utf8',
  timeout: 5000,
  maxBuffer: 1024 * 1024
});
assert.ifError(result.error);
assert.strictEqual(result.status, 0, result.stderr || 'MCP demo server returned a non-zero status');
const messages = result.stdout.trim().split(/\r?\n/).map(line => JSON.parse(line));
assert.strictEqual(messages.length, 3);
assert.ok(messages[1].result.content[0].text.includes('11'), 'safe math expression should be evaluated');
assert.ok(messages[2].result.isError, 'JavaScript property access/constructor must be rejected');
console.log('✓ MCP demo calculator uses the safe math parser and rejects JavaScript execution');
