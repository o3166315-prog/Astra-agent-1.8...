const assert = require('assert');
const SW = require('../server/swarm');

const mission = {
  workers: [{ id: 'a1', name: 'Builder' }, { id: 'a2', name: 'Tester' }],
  events: [
    { at: '2026-11-01T10:00:02.000Z', type: 'worker-event', workerId: 'a2', event: { at: '2026-11-01T10:00:02.000Z', type: 'tool', message: 'Test lancé' } },
    { at: '2026-11-01T10:00:01.000Z', type: 'plan', text: 'Plan réparti entre les agents' },
    { at: '2026-11-01T10:00:03.000Z', type: 'complete', text: 'Mission terminée' }
  ]
};
const timeline = SW.replayTimeline(mission);
assert.strictEqual(timeline.length, 3);
assert.strictEqual(timeline[0].type, 'plan', 'timeline should be chronological');
assert.strictEqual(timeline[1].actor, 'Tester', 'worker names should be resolved');
assert.strictEqual(timeline[1].message, 'Test lancé', 'nested worker event message should be shown');
assert.strictEqual(timeline[2].message, 'Mission terminée');
console.log('✓ Astra Mission Replay : chronologie triée, noms des agents et détails des événements');
