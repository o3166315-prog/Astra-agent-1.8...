'use strict';
const assert=require('assert');
const {create}=require('../server/council');
(async()=>{
 const calls=[];const providers={a:{label:'A',chat:async(s,m,msgs)=>{calls.push({p:'a',m,msgs});return 'Réponse A'}},b:{label:'B',chat:async(s,m,msgs)=>{calls.push({p:'b',m,msgs});return 'Réponse B'}}};
 const council=create({providers,getSettings:()=>({})});
 const r=await council.run({message:'Concevoir une app',agents:[{name:'Alpha',provider:'a',model:'a1'},{name:'Beta',provider:'b',model:'b1'}],coordinator:{provider:'a',model:'a1'}});
 assert.equal(r.members.length,2);assert.equal(r.members[0].answer,'Réponse A');assert.equal(r.members[1].answer,'Réponse B');assert.equal(r.final,'Réponse A');assert.equal(calls.length,3);assert.match(calls[2].msgs[1].content,/Réponse B/);
 await assert.rejects(()=>council.run({message:'x',agents:[{provider:'missing',model:'x'},{provider:'a',model:'a'}]}),/Modèle invalide/);
 await assert.rejects(()=>council.run({message:'',agents:[{provider:'a',model:'a'},{provider:'b',model:'b'}]}),/Décris la mission/);
 console.log('✓ Astra Council : propositions indépendantes, synthèse, validation des membres');
})().catch(e=>{console.error(e);process.exit(1)});
