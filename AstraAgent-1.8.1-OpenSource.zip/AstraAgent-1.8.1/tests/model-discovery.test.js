const assert=require('node:assert/strict');
const {providers}=require('../server/providers');
(async()=>{
 const expected=['openrouter','groq','together','fireworks','deepseek','mistral','xai','perplexity','deepinfra','siliconflow','alibaba','nebius','baseten','cloudflare'];
 for(const id of expected){assert.ok(providers[id],id+' provider registered');assert.equal(typeof providers[id].models,'function');assert.equal(typeof providers[id].chat,'function')}
 const original=global.fetch, calls=[];
 global.fetch=async(url,opts={})=>{calls.push({url:String(url),opts});return {ok:true,status:200,text:async()=>JSON.stringify({data:[{id:'model-a'},{id:'model-b'}]})}};
 try{
  const models=await providers.openrouter.models({key:'test-key'});
  assert.deepEqual(models,['model-a','model-b']);
  assert.equal(calls[0].url,'https://openrouter.ai/api/v1/models');
  assert.equal(calls[0].opts.headers.authorization,'Bearer test-key');
  await assert.rejects(()=>providers.baseten.models({key:'test-key'}),/base URL/i);
  const custom=await providers.baseten.models({key:'test-key',url:'https://example.test/v1'});
  assert.deepEqual(custom,['model-a','model-b']);
  assert.equal(calls[1].url,'https://example.test/v1/models');
  console.log('✓ Astra Model Discovery: 14 compatible providers, dynamic model lists and custom endpoints');
 } finally {global.fetch=original}
})().catch(e=>{console.error(e);process.exitCode=1});
