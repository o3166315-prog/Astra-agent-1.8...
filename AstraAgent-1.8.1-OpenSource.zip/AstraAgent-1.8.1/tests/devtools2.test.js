// Tests des outils V1.8 étape 2 (node tests/devtools2.test.js) : navigation, débogage, mode Auto. Aucun accès réseau.
const assert=require('node:assert/strict'),fs=require('fs'),os=require('os'),path=require('path');
const {tools}=require('../server/tools'),perms=require('../server/perms'),dev=require('../server/devtools'),{needsAgent}=require('../server/automode');
const root=fs.mkdtempSync(path.join(os.tmpdir(),'astra-dev2-')),ctx={root,emit(){},created:new Set()};
const run=(n,a)=>tools[n].run(a||{},ctx),txt=r=>String(r&&r.text!==undefined?r.text:r),lvl=(n,a)=>perms.classifyTool(n,a||{},{root,created:new Set()});
const rejects=async(p,re)=>{try{await p}catch(e){assert.match(e.message,re);return}assert.fail('aurait dû échouer')};
const W=(f,c)=>{const p=path.join(root,f);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,c)};
let ok=0;const T=async(n,f)=>{await f();ok++;console.log('  ✓',n)};
(async()=>{
 W('src/app.js','function computeScore(a,b){\n  return a+b;\n}\nconst total = computeScore(1,2);\nclass Player {\n  move(dx){ return dx; }\n}\nconst fooBar = 3; // computeScoreX n\'est pas computeScore\nmodule.exports.helper = () => computeScore(3,4);\n');
 W('src/util.py','def compute_score(x):\n    return x*2\n\nclass Board:\n    pass\n\nresult = compute_score(4)\n');
 W('player.gd','extends Node\nsignal died\nvar health := 10\nfunc take_damage(n):\n\thealth -= n\n');
 W('src/main.cpp','int addNumbers(int a, int b) {\n  return a + b;\n}\nint main() { return addNumbers(1,2); }\n');
 W('node_modules/lib/index.js','function computeScore(){}\n');
 W('.kairo/x.js','function computeScore(){}\n');
 await T('find_definition : JS, classe, méthode, export, Python, GDScript, C++',async()=>{
  const r=txt(await run('find_definition',{symbol:'computeScore'}));
  assert.match(r,/src[\\/]app\.js:1 .*function computeScore/);assert.doesNotMatch(r,/node_modules|\.kairo/);assert.doesNotMatch(r,/computeScoreX/);
  assert.match(txt(await run('find_definition',{symbol:'Player'})),/app\.js:5 .*classe/);
  assert.match(txt(await run('find_definition',{symbol:'move'})),/app\.js:6 .*méthode/);
  assert.match(txt(await run('find_definition',{symbol:'helper'})),/app\.js:9/);
  assert.match(txt(await run('find_definition',{symbol:'compute_score'})),/util\.py:1/);assert.match(txt(await run('find_definition',{symbol:'Board'})),/util\.py:4/);
  assert.match(txt(await run('find_definition',{symbol:'take_damage'})),/player\.gd:4/);assert.match(txt(await run('find_definition',{symbol:'health'})),/player\.gd:3/);assert.match(txt(await run('find_definition',{symbol:'died'})),/player\.gd:2/);
  assert.match(txt(await run('find_definition',{symbol:'addNumbers'})),/main\.cpp:1/);
  assert.match(txt(await run('find_definition',{symbol:'inconnu'})),/Aucune définition/)});
 await T('find_definition / find_references : symboles invalides et chemins hors projet refusés',async()=>{
  for(const bad of ['a b','x;y','','1abc','a.b'])await rejects(run('find_definition',{symbol:bad}),/invalide/);
  await rejects(run('find_references',{symbol:'a',path:'../..'}),/hors du projet/)});
 await T('find_references : mot entier, définitions marquées, node_modules ignoré',async()=>{
  const r=txt(await run('find_references',{symbol:'computeScore'}));
  assert.match(r,/4 occurrence\(s\) de « computeScore » dans 1 fichier/);assert.match(r,/1 \[déf\]: function computeScore/);assert.match(r,/4: const total/);assert.doesNotMatch(r,/node_modules|\.kairo/);assert.doesNotMatch(r,/fooBar = 3.*\[déf\]|\[déf\].*fooBar/);
  assert.match(txt(await run('find_references',{symbol:'compute_score',glob:'*.py'})),/util\.py/);
  assert.match(txt(await run('find_references',{symbol:'zzz'})),/Aucune occurrence/)});
 await T('rename_symbol : aperçu sans modification, puis application par mot entier avec sauvegardes',async()=>{
  const before=fs.readFileSync(path.join(root,'src/app.js'),'utf8');
  const pv=txt(await run('rename_symbol',{from:'computeScore',to:'calcScore'}));assert.match(pv,/Aperçu : .*4 occurrence\(s\) dans 1 fichier/);assert.equal(fs.readFileSync(path.join(root,'src/app.js'),'utf8'),before);
  const r=txt(await run('rename_symbol',{from:'computeScore',to:'calcScore',apply:true}));assert.match(r,/Renommé/);
  const after=fs.readFileSync(path.join(root,'src/app.js'),'utf8');assert.match(after,/function calcScore\(a,b\)/);assert.match(after,/computeScoreX/);assert.doesNotMatch(after,/\bcomputeScore\b/);
  assert.match(fs.readFileSync(path.join(root,'node_modules/lib/index.js'),'utf8'),/computeScore/);
  assert.ok(fs.readdirSync(path.join(root,'.kairo/backups')).length>=1)});
 await T('rename_symbol : refus des noms invalides, identiques ou hors projet ; avertit des collisions',async()=>{
  await rejects(run('rename_symbol',{from:'a',to:'b c'}),/invalide/);await rejects(run('rename_symbol',{from:'x1',to:'x1'}),/identiques/);
  await rejects(run('rename_symbol',{from:'a1',to:'b1',path:'../'}),/hors du projet/);
  assert.match(txt(await run('rename_symbol',{from:'fooBar',to:'Player'})),/existe déjà/)});
 await T('rename_symbol : permissions (aperçu = lecture, application = confirmation)',()=>{
  assert.equal(lvl('rename_symbol',{from:'a',to:'b'}).level,'SAFE');assert.equal(lvl('rename_symbol',{from:'a',to:'b',apply:true}).level,'CONFIRM');
  assert.equal(lvl('find_definition',{symbol:'a'}).level,'SAFE');assert.equal(lvl('find_references',{symbol:'a',path:'../x'}).level,'CONFIRM')});
 await T('parseTrace : Node, Python, Godot ; ignore node_modules et fichiers inexistants',()=>{
  W('bad.js','const a=1;\nfunction boom(){\n  throw new Error("boom");\n}\nboom();\n');W('tool.py','def f():\n    raise ValueError("oups")\nf()\n');W('scripts/hero.gd','extends Node\nfunc _ready():\n\tprint(nope)\n');
  const node=`${path.join(root,'bad.js')}:3\n  throw new Error("boom");\n  ^\n\nError: boom\n    at boom (${path.join(root,'bad.js')}:3:9)\n    at Object.<anonymous> (${path.join(root,'bad.js')}:5:1)\n    at Module._compile (node:internal/modules/cjs/loader:1554:14)\n    at x (${path.join(root,'node_modules/lib/index.js')}:1:1)`;
  const n=dev.parseTrace(node,root);assert.equal(n.message,'Error: boom');assert.deepEqual(n.frames.map(f=>f.file+':'+f.line),['bad.js:3','bad.js:5']);assert.equal(n.frames[0].fn,'boom');
  const py='Traceback (most recent call last):\n  File "tool.py", line 3, in <module>\n    f()\n  File "tool.py", line 2, in f\n    raise ValueError("oups")\nValueError: oups\n';
  const p=dev.parseTrace(py,root);assert.equal(p.message,'ValueError: oups');assert.deepEqual(p.frames.map(f=>f.file+':'+f.line),['tool.py:3','tool.py:2']);
  const gd='SCRIPT ERROR: Parse Error: Identifier "nope" not declared in the current scope.\n          at: GDScript::reload (res://scripts/hero.gd:3)\n';
  const g=dev.parseTrace(gd,root);assert.deepEqual(g.frames.map(f=>f.file+':'+f.line),['scripts/hero.gd:3']);assert.match(g.message,/Identifier "nope"/);
  assert.deepEqual(dev.parseTrace('rien d\'utile',root),{message:'',frames:[]});
  assert.match(dev.traceReport(node,root),/>\s+3│\s+throw new Error/)});
 await T('run_with_trace : commande en échec → erreur, pile et code ; succès → résumé',async()=>{
  const r=txt(await run('run_with_trace',{command:'node bad.js'}));
  assert.match(r,/Échec/);assert.match(r,/Erreur : Error: boom/);assert.match(r,/bad\.js:3/);assert.match(r,/>\s+3│\s+throw new Error/);
  assert.match(txt(await run('run_with_trace',{command:'node -v'})),/^Succès/);
  await rejects(run('run_with_trace',{command:'  '}),/vide/)});
 await T('run_with_trace / watch_process : mêmes permissions que run_command',()=>{
  for(const n of ['run_with_trace','watch_process']){
   assert.equal(lvl(n,{command:'node app.js'}).level,'SAFE');assert.equal(lvl(n,{command:'curl http://exemple.com'}).cat,'NETWORK');assert.equal(lvl(n,{command:'rm -rf /'}).level,'DANGER')}});
 await T('read_logs : fin du fichier, filtre, niveau, liste des logs, chemins refusés',async()=>{
  W('logs/app.log',Array.from({length:200},(_,i)=>i%50===0?`ERROR ligne ${i} échec`:i%7===0?`WARN ligne ${i}`:`INFO ligne ${i}`).join('\n')+'\n');
  const t=txt(await run('read_logs',{path:'logs/app.log',lines:3}));assert.match(t,/3 ligne\(s\) sur 200/);assert.match(t,/INFO ligne 199/);
  const e=txt(await run('read_logs',{path:'logs/app.log',level:'error'}));assert.match(e,/4 ligne\(s\)/);assert.doesNotMatch(e,/INFO/);
  assert.match(txt(await run('read_logs',{path:'logs/app.log',filter:'ligne 14'})),/ligne 14/);
  const d=txt(await run('read_logs',{}));assert.match(d,/Logs du projet/);assert.match(d,/logs\/app\.log/);
  await rejects(run('read_logs',{path:'../../etc/passwd'}),/hors du projet/);await rejects(run('read_logs',{path:'logs/app.log',level:'zzz'}),/niveau inconnu/);
  assert.equal(lvl('read_logs',{path:'logs/app.log'}).level,'SAFE');assert.equal(lvl('read_logs',{path:'/etc/hosts'}).level,'CONFIRM')});
 await T('watch_process : s’arrête au motif, à la fin du processus ou au délai, et tue le processus',async()=>{
  const t0=Date.now();
  const a=txt(await run('watch_process',{command:'node -e "console.log(\'serveur pret\');setInterval(()=>{},1000)"',seconds:20,until:'PRET'}));
  assert.match(a,/motif « PRET » trouvé/);assert.match(a,/processus arrêté/);assert.match(a,/serveur pret/);assert.ok(Date.now()-t0<8000,'doit s’arrêter dès le motif');
  const b=txt(await run('watch_process',{command:'node -e "console.log(1)"',seconds:10}));assert.match(b,/terminé avec le code 0/);assert.doesNotMatch(b,/processus arrêté/);
  const c=txt(await run('watch_process',{command:'node bad.js',seconds:10}));assert.match(c,/code 1/);assert.match(c,/Erreur : Error: boom/);assert.match(c,/bad\.js:3/);
  const d=txt(await run('watch_process',{command:'node -e "setInterval(()=>{},1000)"',seconds:1}));assert.match(d,/toujours en cours après 1 s/);assert.match(d,/processus arrêté/);
  await rejects(run('watch_process',{command:''}),/vide/);await rejects(run('watch_process',{command:'x',until:'/(/'}),/invalide/)});
 await T('mode Auto : tâches détectées, questions de culture générale laissées en discussion',()=>{
  for(const m of ['Recrée-moi Minecraft sur navigateur','Fais-moi un jeu de snake','Construis une API REST','Développe un site de recettes','Tu peux me recréer Fortnite ?','peux-tu faire une calculatrice en python','Corrige le bug dans index.js','Installe express','Pourquoi mon fichier index.js plante ?'])assert.equal(needsAgent(m).agent,true,m);
  for(const m of ['Bonjour, ça va ?','C’est quoi un script ?','Explique-moi la différence entre let et const','Raconte-moi une blague','Quelle est la capitale de la France ?','Pourquoi le ciel est bleu ?'])assert.equal(needsAgent(m).agent,false,m)});
 console.log('\n'+ok+' contrôles réussis');
})().catch(e=>{console.error('✗',e.message);process.exit(1)});
