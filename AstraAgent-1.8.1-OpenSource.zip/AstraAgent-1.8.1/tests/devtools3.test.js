// Tests des outils V1.8 étape 3 (node tests/devtools3.test.js) : serveurs, capture, modèles, README, tests, ZIP, patch. Sans réseau externe.
const assert=require('node:assert/strict'),fs=require('fs'),os=require('os'),path=require('path'),zlib=require('zlib'),{spawnSync}=require('child_process');
const {tools}=require('../server/tools'),perms=require('../server/perms'),d3=require('../server/devtools3');
const root=fs.mkdtempSync(path.join(os.tmpdir(),'astra-dev3-')),ctx={root,emit(){},created:new Set()};
const run=(n,a,c)=>tools[n].run(a||{},c||ctx),txt=r=>String(r&&r.text!==undefined?r.text:r),lvl=(n,a)=>perms.classifyTool(n,a||{},{root,created:new Set()});
const rejects=async(p,re)=>{try{await p}catch(e){assert.match(e.message,re);return}assert.fail('aurait dû échouer')};
const W=(f,c)=>{const p=path.join(root,f);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,c)},R=f=>fs.readFileSync(path.join(root,f),'utf8');
const get=async(url)=>{const r=await fetch(url);return{status:r.status,text:await r.text(),type:r.headers.get('content-type')}};
const have=cmd=>spawnSync(cmd,['--version']).status===0,py=['python3','python'].find(have);
let ok=0;const T=async(n,f)=>{await f();ok++;console.log('  ✓',n)};
(async()=>{
 await T('les 10 outils de l’étape 3 sont enregistrés',()=>{for(const n of Object.keys(d3.META)){assert.ok(tools[n],n);assert.ok(tools[n].desc.length>30)}assert.equal(Object.keys(d3.META).length,10)});
 await T('permissions',()=>{
  assert.equal(lvl('stop_dev_server').level,'SAFE');assert.equal(lvl('check_port',{port:80}).level,'SAFE');
  assert.equal(lvl('start_dev_server',{static:true}).level,'CONFIRM');assert.equal(lvl('start_dev_server',{command:'node srv.js'}).level,'SAFE');assert.equal(lvl('start_dev_server',{command:'npm run dev'}).level,lvl('run_command',{command:'npm run dev'}).level);assert.equal(lvl('start_dev_server',{command:'curl http://x.y'}).cat,'NETWORK');
  assert.equal(lvl('screenshot_page',{url:'http://localhost:3000'}).cat,'PROJECT_DEVELOPMENT');assert.equal(lvl('screenshot_page',{url:'https://exemple.com'}).cat,'NETWORK');assert.equal(lvl('screenshot_page',{path:'index.html'}).level,'CONFIRM');
  for(const n of ['scaffold_project','generate_tests','create_readme'])assert.equal(lvl(n,{path:'x'}).level,'CONFIRM');
  assert.equal(lvl('zip_files',{paths:['a'],output:'a.zip'}).level,'CONFIRM');assert.equal(lvl('unzip_files',{path:'a.zip'}).level,'CONFIRM');assert.notEqual(lvl('zip_files',{paths:['a'],output:'/etc/x.zip'}).level,'SAFE');
  assert.equal(lvl('patch_apply',{patch:'x'}).level,'CONFIRM');assert.equal(lvl('patch_apply',{patch:'x',check:true}).level,'SAFE')});

 // ── serveurs ──
 W('site/index.html','<h1>Bonjour</h1>');W('site/app.js','console.log(1)');W('site/.env','SECRET=1');W('site/node_modules/x.js','x');
 await T('start_dev_server statique : sert les fichiers, bloque .env et node_modules, évite ../',async()=>{
  const c2={root:path.join(root,'site'),emit(){},created:new Set()};
  const r=txt(await run('start_dev_server',{static:true,name:'test'},c2));assert.match(r,/prêt : http:\/\/127\.0\.0\.1:(\d+)/);const port=+/:(\d+)/.exec(r)[1];
  const base='http://127.0.0.1:'+port;
  const a=await get(base+'/');assert.equal(a.status,200);assert.match(a.text,/Bonjour/);assert.match(a.type,/text\/html/);
  assert.match((await get(base+'/app.js')).type,/javascript/);assert.equal((await get(base+'/.env')).status,403);assert.equal((await get(base+'/node_modules/x.js')).status,403);assert.equal((await get(base+'/nope')).status,404);
  assert.notEqual((await get(base+'/..%2f..%2fetc%2fpasswd')).status,200);
  assert.match(txt(await run('check_port',{port})),/ouvert.*\n.*srv1/s);assert.match(txt(await run('check_port',{port,logs:true})),/GET \/ → 200/);assert.match(txt(await run('check_port')),/srv1/);
  await rejects(run('start_dev_server',{static:true,port},c2),/déjà utilisé/);
  assert.match(txt(await run('stop_dev_server',{port})),/arrêté/);assert.match(txt(await run('check_port',{port})),/fermé/);assert.match(txt(await run('stop_dev_server')),/Aucun serveur/)});
 await T('start_dev_server avec commande : détecte le port, lit la sortie, puis stop_dev_server tue le processus',async()=>{
  W('srv.js',"const p=+process.env.PORT||0;require('http').createServer((q,r)=>r.end('ok')).listen(p,'127.0.0.1',function(){console.log('écoute sur http://127.0.0.1:'+this.address().port)});");
  const r=txt(await run('start_dev_server',{command:'node srv.js',timeout:20}));assert.match(r,/prêt : http:\/\/127\.0\.0\.1:(\d+)/);const port=+/:(\d+)/.exec(r)[1];
  assert.equal((await get('http://127.0.0.1:'+port)).text,'ok');assert.match(txt(await run('check_port',{port,logs:true})),/écoute sur/);
  assert.match(txt(await run('stop_dev_server',{id:/Serveur (srv\d+)/.exec(r)[1]})),/arrêté/);
  for(let i=0;i<20&&await fetch('http://127.0.0.1:'+port).then(()=>true,()=>false);i++)await new Promise(r=>setTimeout(r,150));
  assert.equal(await fetch('http://127.0.0.1:'+port).then(()=>true,()=>false),false,'le processus doit être mort')});
 await T('start_dev_server : échec rapide avec analyse d’erreur, limite de 3 serveurs, détection du script npm',async()=>{
  W('crash.js','function f(){\n  throw new Error("plantage test");\n}\nf();\n');
  await rejects(run('start_dev_server',{command:'node crash.js',timeout:15}),/s’est arrêté.*plantage test.*crash\.js:2/s);
  const c2={root:path.join(root,'site'),emit(){},created:new Set()};const ids=[];
  for(let i=0;i<3;i++)ids.push(/srv\d+/.exec(txt(await run('start_dev_server',{static:true},c2)))[0]);
  await rejects(run('start_dev_server',{static:true},c2),/3 serveurs maximum/);assert.match(txt(await run('stop_dev_server',{all:true})),/3 serveur/);
  W('pk/package.json',JSON.stringify({scripts:{dev:'node s.js'}}));W('pk/s.js',"require('http').createServer((q,r)=>r.end('x')).listen(+process.env.PORT,'127.0.0.1',()=>console.log('http://localhost:'+process.env.PORT))");
  const c3={root:path.join(root,'pk'),emit(){},created:new Set()},r=txt(await run('start_dev_server',{port:await new Promise(r=>{const s=require('net').createServer().listen(0,()=>{const p=s.address().port;s.close(()=>r(p))})})},c3));
  assert.match(r,/Commande : npm run dev/);await run('stop_dev_server',{all:true});
  await rejects(run('check_port',{port:99999}),/port invalide/);await rejects(run('start_dev_server',{command:'x',port:'abc'}),/port invalide/)});
 await T('screenshot_page : capture une page locale (ignoré si aucun navigateur)',async()=>{
  const b=d3.findBrowser();await rejects(run('screenshot_page',{url:'ftp://x'}),/http/);await rejects(run('screenshot_page',{url:'http://u:p@localhost'}),/identifiants/);await rejects(run('screenshot_page',{path:'x.txt'}),/\.html/);await rejects(run('screenshot_page',{path:'absent.html'}),/inexistant/);
  if(!b){console.log('    (aucun navigateur : capture ignorée)');return}
  W('shot.html','<body style="margin:0;background:#112233"><h1 style="color:#fff">Capture test</h1>');
  let r;try{r=txt(await run('screenshot_page',{path:'shot.html',width:640,height:360,name:'essai',wait:200}))}catch(e){if(/Aucune capture produite/.test(e.message)){console.log('    (navigateur de test instable : capture non vérifiée ici)');return}throw e}
  assert.match(r,/\.kairo\/screenshots\/essai\.png \(640×360\)/);assert.ok(fs.statSync(path.join(root,'.kairo/screenshots/essai.png')).size>200);console.log('    capture réelle vérifiée')});

 await T('screenshot_page : essais successifs, attente de l’image, arrêt du processus (faux navigateur)',async()=>{
  if(process.platform==='win32'){console.log('    (Windows : faux navigateur ignoré)');return}
  const bin=path.join(root,'fake-browser.js'),log=path.join(root,'fake-browser.log');
  fs.writeFileSync(bin,`#!/usr/bin/env node
const fs=require('fs'),zlib=require('zlib');const a=process.argv.slice(2);fs.appendFileSync(${JSON.stringify(log)},a.filter(x=>x.startsWith('--headless')||x.startsWith('--virtual')).join(' ')+'\\n');
if(a.some(x=>x.startsWith('--virtual-time-budget')))setInterval(()=>{},1000);else{
const out=a.find(x=>x.startsWith('--screenshot=')).slice(13),[w,h]=a.find(x=>x.startsWith('--window-size=')).slice(14).split(',').map(Number);
const crcT=Array.from({length:256},(_,n)=>{let c=n;for(let k=0;k<8;k++)c=c&1?0xEDB88320^(c>>>1):c>>>1;return c>>>0});const crc=b=>{let c=~0;for(const x of b)c=crcT[(c^x)&255]^(c>>>8);return~c>>>0};
const chunk=(t,d)=>{const l=Buffer.alloc(4);l.writeUInt32BE(d.length);const td=Buffer.concat([Buffer.from(t),d]),c=Buffer.alloc(4);c.writeUInt32BE(crc(td));return Buffer.concat([l,td,c])};
const ih=Buffer.alloc(13);ih.writeUInt32BE(w,0);ih.writeUInt32BE(h,4);ih[8]=8;ih[9]=2;const row=Buffer.alloc(1+w*3);for(let i=0;i<w;i++){row[1+i*3]=17;row[2+i*3]=34;row[3+i*3]=51}
fs.writeFileSync(out,Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),chunk('IHDR',ih),chunk('IDAT',zlib.deflateSync(Buffer.concat(Array.from({length:h},()=>row)))),chunk('IEND',Buffer.alloc(0))]));
setInterval(()=>{},1000)}
`);fs.chmodSync(bin,0o755);
  const prev=process.env.ASTRA_BROWSER;process.env.ASTRA_BROWSER=bin;
  try{W('fk.html','<p>x</p>');const t0=Date.now();
   const r=txt(await run('screenshot_page',{path:'fk.html',width:640,height:360,wait:300,name:'faux'}));
   assert.match(r,/\.kairo\/screenshots\/faux\.png \(640×360\)/);assert.ok(fs.statSync(path.join(root,'.kairo/screenshots/faux.png')).size>100);
   const tries=fs.readFileSync(log,'utf8').trim().split('\n');assert.equal(tries.length,2,'1er essai (temps virtuel) bloqué, 2e réussi');assert.match(tries[0],/virtual-time-budget=800/);assert.doesNotMatch(tries[1],/virtual/);
   assert.ok(Date.now()-t0<20000);
   const r2=txt(await run('screenshot_page',{path:'fk.html',wait:0,name:'faux2'}));assert.match(r2,/faux2\.png \(1280×800\)/);
   fs.writeFileSync(bin,'#!/usr/bin/env node\nsetInterval(()=>{},1000)\n');await rejects(run('screenshot_page',{path:'fk.html',wait:0,name:'rien'}),/Aucune capture produite/);
  }finally{if(prev===undefined)delete process.env.ASTRA_BROWSER;else process.env.ASTRA_BROWSER=prev}});

 // ── modèles ──
 await T('scaffold_project : 6 modèles, jamais d’écrasement, remplacement du nom',async()=>{
  for(const t of d3.TEMPLATES){const r=txt(await run('scaffold_project',{template:t,name:'Mon Jeu Été',path:'mon-jeu-ete-'+t}));assert.match(r,new RegExp('Modèle « '+t+' » créé'));}
  assert.match(R('mon-jeu-ete-html-site/index.html'),/Mon Jeu Été/);assert.match(R('mon-jeu-ete-node-cli/package.json'),/"name": "mon-jeu-ete"/);assert.doesNotMatch(R('mon-jeu-ete-node-cli/package.json')+R('mon-jeu-ete-html-site/index.html'),/\{\{/);
  await rejects(run('scaffold_project',{template:'html-site',name:'Mon Jeu Été',path:'mon-jeu-ete-html-site'}),/déjà présents \(rien n’a été écrit\)/);
  await rejects(run('scaffold_project',{template:'nimporte'}),/Modèle inconnu/);await rejects(run('scaffold_project',{template:'html-site',path:'../x'}),/hors du projet/);
  assert.match(txt(await run('scaffold_project',{template:'html-site',name:'Mon Jeu Été',path:'mon-jeu-ete-html-site',force:true})),/créé/);
  const g=R('mon-jeu-ete-godot-2d/project.godot');assert.match(g,/config_version=5/);assert.match(g,/config\/name="Mon Jeu Été"/);assert.match(R('mon-jeu-ete-godot-2d/main.tscn'),/\[gd_scene load_steps=3 format=3\]/)});
 await T('scaffold_project : les modèles Node, Python et le jeu HTML fonctionnent vraiment',async()=>{
  const sh=(cmd,args,cwd)=>spawnSync(cmd,args,{cwd:path.join(root,cwd),encoding:'utf8',timeout:60000});
  for(const t of['node-cli','node-api']){await run('scaffold_project',{template:t,name:'T '+t,path:'run-'+t});const r=sh('node',['--test'],'run-'+t);assert.equal(r.status,0,t+'\n'+r.stdout+r.stderr)}
  assert.equal(sh('node',['run-node-cli/src/index.js','Zoé','--shout'],'.').stdout.trim(),'BONJOUR ZOÉ !');
  assert.equal(sh('node',['--check','mon-jeu-ete-html-game/game.js'],'.').status,0);
  if(py){await run('scaffold_project',{template:'python-cli',name:'Py',path:'run-py'});const r=sh(py,['-m','unittest','discover','-s','tests'],'run-py');assert.equal(r.status,0,r.stdout+r.stderr)}else console.log('    (python absent : modèle Python non exécuté)')});

 // ── tests générés et README ──
 await T('generate_tests : JS (CommonJS et ESM) et Python, tests générés exécutés pour de bon',async()=>{
  W('lib/maths.js','function add(a,b){return a+b}\nconst mul=(a,b)=>a*b;\nmodule.exports={add,mul};\n');
  W('lib/esm.mjs','export function hello(){return 1}\nexport const PI2=6.28;\nexport class Box{}\n');
  const r=txt(await run('generate_tests',{path:'lib/maths.js'}));assert.match(r,/tests\/maths\.test\.js.*add, mul/s);assert.match(R('tests/maths.test.js'),/require\('\.\.\/lib\/maths\.js'\)/);
  await run('generate_tests',{path:'lib/esm.mjs'});assert.match(R('tests/esm.test.mjs'),/import \* as lib from '\.\.\/lib\/esm\.mjs'/);assert.match(R('tests/esm.test.mjs'),/PI2 est exporté'/);assert.doesNotMatch(R('tests/esm.test.mjs'),/PI2 est exporté et appelable/);assert.match(R('tests/esm.test.mjs'),/Box est exporté et appelable/);
  for(const f of['tests/maths.test.js','tests/esm.test.mjs']){const x=spawnSync('node',['--test',f],{cwd:root,encoding:'utf8'});assert.equal(x.status,0,f+'\n'+x.stdout+x.stderr)}
  await rejects(run('generate_tests',{path:'lib/maths.js'}),/existe déjà/);assert.match(txt(await run('generate_tests',{path:'lib/maths.js',force:true})),/créés/);
  await rejects(run('generate_tests',{path:'inconnu.js'}),/inexistant/);W('lib/vide.js','const x=1;\n');await rejects(run('generate_tests',{path:'lib/vide.js'}),/Aucune fonction/);await rejects(run('generate_tests',{path:'README.txt'}),/inexistant/);W('a.ts','export function f(){}');await rejects(run('generate_tests',{path:'a.ts'}),/Type non pris en charge/);
  if(py){W('pylib/calc.py','def add(a, b):\n    return a + b\n\nclass Calc:\n    pass\n\ndef _priv():\n    pass\n');await run('generate_tests',{path:'pylib/calc.py'});assert.doesNotMatch(R('tests/test_calc.py'),/_priv/);const x=spawnSync(py,['-m','unittest','discover','-s','tests','-p','test_calc.py'],{cwd:root,encoding:'utf8'});assert.equal(x.status,0,x.stdout+x.stderr)}});
 await T('create_readme : contenu issu du projet, pas d’écrasement',async()=>{
  W('proj/package.json',JSON.stringify({name:'super-outil',description:'Un outil super utile',scripts:{start:'node a.js',test:'node --test',dev:'node --watch a.js'}}));W('proj/a.js','x');W('proj/LICENSE','MIT');W('proj/src/b.js','y');
  const r=txt(await run('create_readme',{path:'proj'}));assert.match(r,/proj\/README\.md/);const m=R('proj/README.md');
  assert.match(m,/^# super-outil/);assert.match(m,/Un outil super utile/);assert.match(m,/npm install/);assert.match(m,/npm run dev/);assert.match(m,/npm test/);assert.match(m,/src\//);assert.match(m,/Licence/);assert.doesNotMatch(m,/node_modules/);
  await rejects(run('create_readme',{path:'proj'}),/existe déjà/);assert.match(txt(await run('create_readme',{path:'proj',title:'Autre',description:'Desc',force:true})),/créé/);assert.match(R('proj/README.md'),/^# Autre\n\nDesc/)});

 // ── ZIP ──
 W('z/a.txt','Bonjour éàü\n');W('z/sub/b.bin','');fs.writeFileSync(path.join(root,'z/sub/c.dat'),Buffer.from(Array.from({length:5000},(_,i)=>i%251)));W('z/.env','SECRET');W('z/node_modules/m.js','m');W('z/gros.txt','x'.repeat(50000));
 await T('zip_files : crée une archive valide (lue par Python/unzip), exclut .env et node_modules',async()=>{
  const r=txt(await run('zip_files',{paths:['z'],output:'out/z.zip'}));assert.match(r,/4 fichier\(s\)/);assert.match(r,/1 fichier\(s\) \.env exclu/);
  const lst=d3.readZipDir(fs.readFileSync(path.join(root,'out/z.zip'))).map(e=>e.name).sort();assert.deepEqual(lst,['z/a.txt','z/gros.txt','z/sub/b.bin','z/sub/c.dat']);
  if(py){const x=spawnSync(py,['-c','import zipfile,sys;z=zipfile.ZipFile(sys.argv[1]);print(z.testzip());print(sorted(z.namelist()));print(z.read("z/a.txt").decode())',path.join(root,'out/z.zip')],{encoding:'utf8'});assert.equal(x.status,0,x.stderr);assert.match(x.stdout,/^None/);assert.match(x.stdout,/Bonjour éàü/)}
  await rejects(run('zip_files',{paths:['z'],output:'out/z.zip'}),/existe déjà/);await rejects(run('zip_files',{paths:[],output:'a.zip'}),/paths vide/);await rejects(run('zip_files',{paths:['z'],output:'a.txt'}),/\.zip/);await rejects(run('zip_files',{paths:['absent']}),/inexistant/);await rejects(run('zip_files',{paths:['../..']}),/hors du projet/)});
 await T('unzip_files : aller-retour identique, lit aussi les ZIP faits par Python, refuse d’écraser',async()=>{
  await run('unzip_files',{path:'out/z.zip',dest:'back'});assert.equal(R('back/z/a.txt'),'Bonjour éàü\n');assert.ok(fs.readFileSync(path.join(root,'back/z/sub/c.dat')).equals(fs.readFileSync(path.join(root,'z/sub/c.dat'))));assert.equal(R('back/z/gros.txt').length,50000);assert.ok(!fs.existsSync(path.join(root,'back/z/.env')));
  await rejects(run('unzip_files',{path:'out/z.zip',dest:'back'}),/existent déjà \(rien n’a été extrait\)/);
  if(py){spawnSync(py,['-c','import zipfile;z=zipfile.ZipFile("pyz.zip","w",zipfile.ZIP_DEFLATED);z.writestr("d/x.txt","from python "*100);z.writestr("e/","");z.close()'],{cwd:root});await run('unzip_files',{path:'pyz.zip'});assert.match(R('pyz/d/x.txt'),/^from python/)}
  await rejects(run('unzip_files',{path:'absent.zip'}),/inexistante/);W('faux.zip','pas un zip');await rejects(run('unzip_files',{path:'faux.zip'}),/ZIP invalide/)});
 await T('unzip_files : protections (../, chemin absolu, .git, symlink, bombe, CRC, tronqué)',async()=>{
  const mk=entries=>d3.buildZip(entries.map(e=>({name:e[0],data:Buffer.from(e[1]),mtime:new Date()})));
  for(const [name,re] of [['../evil.txt',/dangereuse/],['a/../../evil.txt',/dangereuse/],['/etc/passwd',/dangereuse/],['C:/win.txt',/dangereuse/],['.git/config',/zone interne/],['.kairo/x',/zone interne/]]){fs.writeFileSync(path.join(root,'bad.zip'),mk([['ok.txt','1'],[name,'x']]));await rejects(run('unzip_files',{path:'bad.zip',dest:'bad-'+Math.random().toString(36).slice(2,6)}),re)}
  assert.ok(!fs.existsSync(path.join(root,'..','evil.txt')));
  const good=mk([['n.txt','hello']]),buf=Buffer.from(good);
  const lh=buf.indexOf(Buffer.from('hello'));buf[lh]=0x48^1;fs.writeFileSync(path.join(root,'crc.zip'),buf);await rejects(run('unzip_files',{path:'crc.zip',dest:'crcd'}),/contrôle incorrecte|Taille inattendue|Décompression/);
  fs.writeFileSync(path.join(root,'trunc.zip'),good.subarray(0,good.length-30));await rejects(run('unzip_files',{path:'trunc.zip',dest:'trd'}),/ZIP/);
  const bomb=d3.buildZip([{name:'big.txt',data:Buffer.alloc(150*1024*1024,65),mtime:new Date()}]);fs.writeFileSync(path.join(root,'bomb.zip'),bomb);assert.ok(bomb.length<1024*1024*5);
  const lie=Buffer.from(bomb);const cd=lie.indexOf(Buffer.from([0x50,0x4b,1,2]));lie.writeUInt32LE(10,cd+24);fs.writeFileSync(path.join(root,'lie.zip'),lie);await rejects(run('unzip_files',{path:'lie.zip',dest:'lied'}),/Décompression|Taille inattendue/);
  assert.ok(!fs.existsSync(path.join(root,'lied/big.txt')));
  const many=d3.buildZip(Array.from({length:20001},(_,i)=>({name:'f'+i,data:Buffer.alloc(0),mtime:new Date()})));fs.writeFileSync(path.join(root,'many.zip'),many);await rejects(run('unzip_files',{path:'many.zip',dest:'manyd'}),/Trop d’entrées/);
  const sym=Buffer.from(mk([['lien','/etc/passwd'],['reel.txt','r']]));const c0=sym.indexOf(Buffer.from([0x50,0x4b,1,2]));sym.writeUInt32LE(((0o120777<<16)>>>0),c0+38);fs.writeFileSync(path.join(root,'sym.zip'),sym);await run('unzip_files',{path:'sym.zip',dest:'symd'});assert.ok(!fs.existsSync(path.join(root,'symd/lien')));assert.equal(R('symd/reel.txt'),'r')});

 // ── patch ──
 const orig='un\ndeux\ntrois\nquatre\ncinq\nsix\nsept\nhuit\nneuf\ndix\n';
 await T('patch_apply : diff -u réel, aperçu, application, annulation',async()=>{
  W('p/f.txt',orig);W('p/g.txt','salut\nmonde\n');
  const mod='un\ndeux\nTROIS\nquatre\ncinq\nsix\nsept\nhuit\nneuf\nnouveau\ndix\n';fs.writeFileSync(path.join(root,'p/f2.txt'),mod);
  const diff=spawnSync('diff',['-u','--label','a/p/f.txt','--label','b/p/f.txt','p/f.txt','p/f2.txt'],{cwd:root,encoding:'utf8'}).stdout;assert.match(diff,/^--- a\/p\/f\.txt/);
  const chk=txt(await run('patch_apply',{patch:diff,check:true}));assert.match(chk,/s’applique proprement à 1 fichier/);assert.equal(R('p/f.txt'),orig);
  assert.match(txt(await run('patch_apply',{patch:diff})),/Patch appliqué sur 1 fichier/);assert.equal(R('p/f.txt'),mod);
  assert.match(txt(await run('patch_apply',{patch:diff,reverse:true})),/Patch annulé/);assert.equal(R('p/f.txt'),orig)});
 await T('patch_apply : tolère les décalages de lignes et les espaces de fin, plusieurs fichiers, création',async()=>{
  const diff='--- a/p/f.txt\n+++ b/p/f.txt\n@@ -5,3 +5,3 @@\n cinq\n-six\n+SIX\n sept\n--- a/p/g.txt\n+++ b/p/g.txt\n@@ -1,2 +1,3 @@\n salut\n monde\n+!\n--- /dev/null\n+++ b/p/new/n.txt\n@@ -0,0 +1,2 @@\n+ligne 1\n+ligne 2\n';
  W('p/f.txt','AJOUT1\nAJOUT2\n'+orig);const r=txt(await run('patch_apply',{patch:diff}));assert.match(r,/3 fichier\(s\)/);assert.match(r,/décalé de 2 ligne/);assert.match(R('p/f.txt'),/SIX/);assert.equal(R('p/g.txt'),'salut\nmonde\n!\n');assert.equal(R('p/new/n.txt'),'ligne 1\nligne 2\n');
  W('p/crlf.txt','a\r\nb\r\nc\r\n');await run('patch_apply',{patch:'--- a/p/crlf.txt\n+++ b/p/crlf.txt\n@@ -1,3 +1,3 @@\n a\n-b\n+B\n c\n'});assert.equal(R('p/crlf.txt'),'a\r\nB\r\nc\r\n')});
 await T('patch_apply : tout ou rien, refus des chemins dangereux, suppressions et patchs invalides',async()=>{
  const before=R('p/g.txt');
  await rejects(run('patch_apply',{patch:'--- a/p/g.txt\n+++ b/p/g.txt\n@@ -1,2 +1,2 @@\n salut\n-pas ça\n+x\n--- a/p/inconnu.txt\n+++ b/p/inconnu.txt\n@@ -1 +1 @@\n-a\n+b\n'}),/aucun fichier modifié.*introuvable.*inexistant/s);assert.equal(R('p/g.txt'),before);
  await rejects(run('patch_apply',{patch:'--- a/../../x.txt\n+++ b/../../x.txt\n@@ -1 +1 @@\n-a\n+b\n'}),/hors du projet/);await rejects(run('patch_apply',{patch:'--- a/.git/config\n+++ b/.git/config\n@@ -1 +1 @@\n-a\n+b\n'}),/zone interne/);
  await rejects(run('patch_apply',{patch:'--- a/p/g.txt\n+++ /dev/null\n@@ -1,3 +0,0 @@\n-salut\n-monde\n-!\n'}),/suppression de fichier/);await rejects(run('patch_apply',{patch:'--- /dev/null\n+++ b/p/g.txt\n@@ -0,0 +1 @@\n+x\n'}),/existe déjà/);
  await rejects(run('patch_apply',{patch:'du texte quelconque'}),/Aucun fichier reconnu/);await rejects(run('patch_apply',{patch:'  '}),/vide/);await rejects(run('patch_apply',{patch:'x'.repeat(1e6+1)}),/trop gros/);
  assert.ok(fs.readdirSync(path.join(root,'.kairo/backups')).length>5)});
 console.log('\n'+ok+' contrôles réussis');d3.killAllServers();process.exit(0);
})().catch(e=>{console.error('✗',e.message);d3.killAllServers();process.exit(1)});
