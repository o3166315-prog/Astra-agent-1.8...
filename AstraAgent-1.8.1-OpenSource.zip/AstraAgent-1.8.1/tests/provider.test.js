const assert=require('node:assert/strict');
const {providers}=require('../server/providers');

(async()=>{
 const meta=providers.meta;
 assert.ok(meta,'Meta provider must be registered');
 assert.equal(meta.label,'Meta AI · Muse');
 assert.equal(typeof meta.models,'function');
 assert.equal(typeof meta.chat,'function');
 assert.equal(typeof meta.vision,'function');

 const originalFetch=global.fetch;
 const requests=[];
 global.fetch=async(url,options={})=>{
  requests.push({url:String(url),options});
  const payload=String(url).endsWith('/models')
   ? {data:[{id:'muse-spark-1.3'},{id:'muse-wonder'}]}
   : {choices:[{message:{content:'Kairo connecté à Meta.'}}]};
  return {ok:true,status:200,text:async()=>JSON.stringify(payload)};
 };
 try{
  const models=await meta.models({key:'test-key'});
  assert.deepEqual(models,['muse-spark-1.3','muse-wonder']);
  assert.equal(requests[0].url,'https://api.meta.ai/v1/models');
  assert.equal(requests[0].options.headers.authorization,'Bearer test-key');

  const answer=await meta.chat({key:'test-key'},'muse-spark-1.3',[
   {role:'user',content:'Bonjour'}
  ]);
  assert.equal(answer,'Kairo connecté à Meta.');
  assert.equal(requests[1].url,'https://api.meta.ai/v1/chat/completions');
  assert.equal(requests[1].options.headers.authorization,'Bearer test-key');
  assert.equal(await meta.vision({},'muse-spark-1.3'),true);
  console.log('✓ Meta Model API : découverte des modèles, authentification et chat compatibles');
 }finally{
  global.fetch=originalFetch;
 }
})().catch(e=>{console.error(e);process.exitCode=1});
