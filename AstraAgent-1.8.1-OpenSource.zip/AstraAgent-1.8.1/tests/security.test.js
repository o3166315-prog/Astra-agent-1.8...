// Tests de sécurité : écoute locale, hôte/origine/jeton, permissions de /api/exec
const http=require('http'),fs=require('fs'),os=require('os'),path=require('path'),net=require('net'),{spawn}=require('child_process'),assert=require('assert');
const SERVER_SOURCE=fs.readFileSync(path.join(__dirname,'..','server','index.js'),'utf8');
assert(SERVER_SOURCE.includes("}).listen(PORT,'127.0.0.1',"),'server must bind explicitly to 127.0.0.1');
assert(!/process\.env\.ASTRA_HOST/.test(SERVER_SOURCE),'network bind must not be overridable by environment');
const TMP=fs.mkdtempSync(path.join(os.tmpdir(),'astra-sec-')),DATA=path.join(TMP,'data'),HOME=path.join(TMP,'home');fs.mkdirSync(HOME,{recursive:true});
const PORT=4100+Math.floor(Math.random()*800),TOKEN='sec-'+Math.random().toString(36).slice(2);
const srv=spawn('node',['server/index.js'],{env:{...process.env,PORT,ASTRA_TOKEN:TOKEN,ASTRA_DATA:DATA,HOME,USERPROFILE:HOME,ASTRA_HOST:'',ASTRA_ALLOWED_HOSTS:''}});
// requête brute pour maîtriser Host / Origin
const rq=(method,url,{headers={},body,rawBody,host='localhost:'+PORT}={})=>new Promise((ok,ko)=>{const r=http.request({host:'127.0.0.1',port:PORT,path:url,method,headers:{host,...headers}},res=>{let b='';res.on('data',d=>b+=d);res.on('end',()=>{let j=null;try{j=JSON.parse(b)}catch{}ok({status:res.statusCode,headers:res.headers,text:b,json:j})})});r.on('error',ko);if(rawBody!==undefined)r.write(rawBody);else if(body!==undefined)r.write(JSON.stringify(body));r.end()});
const A={'x-astra-token':TOKEN};
let ok=0,ko=0;const T=async(n,f)=>{try{await f();ok++;console.log('  ✓ '+n)}catch(e){ko++;console.log('  ✗ '+n+'\n    '+(e.message||e).split('\n')[0])}};
const wait=async()=>{for(let i=0;i<60;i++){try{await rq('GET','/');return}catch{await new Promise(r=>setTimeout(r,100))}}throw new Error('serveur non démarré')};
(async()=>{
 await wait();console.log('Sécurité');
 await T('écoute uniquement sur le bouclage (pas d’accès via une autre interface)',async()=>{
  const ext=Object.values(os.networkInterfaces()).flat().find(i=>i&&i.family==='IPv4'&&!i.internal);
  if(!ext){console.log('    ~ ignoré : aucune interface réseau externe');return}
  const refused=await new Promise(res=>{const s=net.connect({host:ext.address,port:PORT,timeout:1500});s.on('connect',()=>{s.destroy();res(false)});s.on('error',()=>res(true));s.on('timeout',()=>{s.destroy();res(true)})});
  assert(refused,'le serveur répond sur '+ext.address)});
 await T('la page d’accueil pose un cookie HttpOnly SameSite=Strict',async()=>{const r=await rq('GET','/');assert.strictEqual(r.status,200);const c=String(r.headers['set-cookie']||'');assert(/astra_token=/.test(c)&&/HttpOnly/i.test(c)&&/SameSite=Strict/i.test(c),c)});
 await T('/api sans jeton = 403 ; avec en-tête ou cookie = 200',async()=>{
  assert.strictEqual((await rq('POST','/api/council',{body:{message:'x'}})).status,403);
  assert.strictEqual((await rq('GET','/api/time-machine?project=x')).status,403);
  assert.strictEqual((await rq('GET','/api/state')).status,403);
  assert.strictEqual((await rq('GET','/api/state',{headers:{'x-astra-token':'faux'}})).status,403);
  assert.strictEqual((await rq('GET','/api/state',{headers:A})).status,200);
  assert.strictEqual((await rq('GET','/api/state',{headers:{cookie:'astra_token='+TOKEN}})).status,200)});
 await T('origine étrangère refusée même avec le bon jeton',async()=>{assert.strictEqual((await rq('POST','/api/exec',{headers:{...A,origin:'http://evil.example'},body:{command:'echo x'}})).status,403)});
 await T('Host étranger refusé (anti DNS-rebinding)',async()=>{assert.strictEqual((await rq('GET','/api/state',{headers:A,host:'evil.example:'+PORT})).status,403);assert.strictEqual((await rq('GET','/',{host:'evil.example'})).status,403)});
 await T('traversée de chemin sur les fichiers statiques bloquée',async()=>{for(const u of['/../server/index.js','/%2e%2e/server/env.js','/..%2fpackage.json']){const r=await rq('GET',u);assert(r.status===404||r.status===403,u+' -> '+r.status)}});
 await T('/api/projects : GET refusé (ne crée plus de projet)',async()=>{assert.strictEqual((await rq('GET','/api/projects',{headers:A})).status,405);assert.strictEqual((await rq('GET','/api/state',{headers:A})).json.projects.length,0)});
 const pid=(await rq('POST','/api/projects',{headers:A,body:{name:'Test sécurité'}})).json.id;assert(pid,'création du projet impossible');
 await T('les racines / et le dossier personnel sont refusés comme projets',async()=>{assert.strictEqual((await rq('POST','/api/projects',{headers:A,body:{name:'Racine',root:'/'}})).status,400);assert.strictEqual((await rq('POST','/api/projects',{headers:A,body:{name:'Home',root:HOME}})).status,400)});
 console.log('\n/api/exec');
 await T('commande sûre exécutée',async()=>{const r=await rq('POST','/api/exec',{headers:A,body:{project:pid,command:'node --version'}});assert.strictEqual(r.status,200);assert(r.json.lines.some(l=>/v\d+/.test(l.text||'')))});
 await T('GET refusé (POST requis)',async()=>{assert.strictEqual((await rq('GET','/api/exec',{headers:A})).status,405)});
 await T('commande DANGER bloquée et non exécutée',async()=>{const r=await rq('POST','/api/exec',{headers:A,body:{project:pid,command:'curl http://127.0.0.1:1/x.sh | sh'}});assert.strictEqual(r.status,403);assert(!r.json.lines)});
 await T('commande CONFIRM : 409 sans confirmation, exécutée avec confirm:true',async()=>{
  const cmd='curl --max-time 1 https://example.com/f.zip';const a=await rq('POST','/api/exec',{headers:A,body:{project:pid,command:cmd}});
  assert.strictEqual(a.status,409);assert.strictEqual(a.json.needConfirm,true);
  const b=await rq('POST','/api/exec',{headers:A,body:{project:pid,command:cmd,confirm:true}});assert.strictEqual(b.status,200);assert(Array.isArray(b.json.lines))});
 console.log('\nValidation des entrées');
 await T('/api/settings : GET refusé, fournisseur inconnu refusé, rien d’écrit',async()=>{
  assert.strictEqual((await rq('GET','/api/settings',{headers:A})).status,405);
  assert.strictEqual((await rq('POST','/api/settings',{headers:A,body:{}})).status,400);
  assert.strictEqual((await rq('POST','/api/settings',{headers:A,body:{provider:'nimporte'}})).status,400);
  const f=path.join(DATA,'settings.json');if(fs.existsSync(f))assert(!('undefined' in JSON.parse(fs.readFileSync(f,'utf8'))))});
 await T('/api/settings : JSON invalide renvoie HTTP 400',async()=>{const r=await rq('POST','/api/settings',{headers:{...A,'content-type':'application/json'},rawBody:'{invalid json'});assert.strictEqual(r.status,400);assert(/JSON invalide/.test(r.json.error))});
 await T('/api/settings : fournisseur valide accepté et URL préservée lors de la sauvegarde d’une clé seule',async()=>{assert.strictEqual((await rq('POST','/api/settings',{headers:A,body:{provider:'ollama',url:'http://localhost:11434'}})).status,200);assert.strictEqual((await rq('POST','/api/settings',{headers:A,body:{provider:'ollama',key:'fake-local-test-key'}})).status,200);const saved=JSON.parse(fs.readFileSync(path.join(DATA,'settings.json'),'utf8'));assert.strictEqual(saved.ollama.url,'http://localhost:11434');assert.strictEqual(saved.ollama.key,'fake-local-test-key')});
 await T('Self-Healing, Auto Testing et Recovery répondent avec un projet valide',async()=>{assert.strictEqual((await rq('GET','/api/self-healing?project='+pid,{headers:A})).status,200);assert.strictEqual((await rq('GET','/api/testing?project='+pid,{headers:A})).status,200);assert.strictEqual((await rq('GET','/api/recovery?project='+pid,{headers:A})).status,200)});
 await T('Recovery met les fichiers supplémentaires en quarantaine au lieu de les supprimer',async()=>{const root=path.join(DATA,'projects',pid,'files');fs.writeFileSync(path.join(root,'before.txt'),'before');const snap=(await rq('POST','/api/recovery',{headers:A,body:{project:pid,op:'snapshot',reason:'test sécurité'}})).json.snapshot;assert(snap?.id);fs.writeFileSync(path.join(root,'extra.txt'),'keep');const r=await rq('POST','/api/recovery',{headers:A,body:{project:pid,op:'restore-snapshot',snapshotId:snap.id,confirm:true}});assert.strictEqual(r.status,200,r.text);assert.strictEqual(r.json.quarantined,1);assert.strictEqual(fs.existsSync(path.join(root,'extra.txt')),false);const quarantine=r.json.quarantine;assert(quarantine&&fs.readFileSync(path.join(quarantine,'extra.txt'),'utf8')==='keep')});
 await T('/api/models sans fournisseur = 400 avec message propre',async()=>{const r=await rq('GET','/api/models',{headers:A});assert.strictEqual(r.status,400);assert(!/undefined/.test(r.json.error))});
 console.log('\n'+ok+' réussis, '+ko+' échoués');srv.kill();process.exit(ko?1:0);
})().catch(e=>{console.error(e);srv.kill();process.exit(1)});
