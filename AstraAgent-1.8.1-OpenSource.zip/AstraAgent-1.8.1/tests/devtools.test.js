// Tests des outils de développement V1.8 (node tests/devtools.test.js) : vrai dépôt git temporaire, aucun accès réseau.
const assert=require('node:assert/strict'),fs=require('fs'),os=require('os'),path=require('path'),{spawnSync}=require('child_process');
const {tools}=require('../server/tools'),perms=require('../server/perms'),dev=require('../server/devtools');
const root=fs.mkdtempSync(path.join(os.tmpdir(),'astra-dev-')),ctx={root,emit(){},created:new Set()};
const run=(n,a)=>tools[n].run(a||{},ctx),lvl=(n,a,x)=>perms.classifyTool(n,a||{},{root,created:new Set(),...x}).level;
const rejects=async(p,re)=>{try{await p}catch(e){assert.match(e.message,re);return}assert.fail('aurait dû échouer')};
const g=(...a)=>spawnSync('git',a,{cwd:root,encoding:'utf8'});
let ok=0;const T=async(n,f)=>{await f();ok++;console.log('  ✓',n)};
(async()=>{
 const hasGit=spawnSync('git',['--version']).status===0;
 await T('les 18 nouveaux outils sont enregistrés avec une catégorie',()=>{
  for(const n of Object.keys(dev.META)){assert.ok(tools[n],n);assert.ok(tools[n].desc.length>20,n)}
  assert.equal(Object.keys(dev.META).length,18)});
 await T('permissions : lecture libre, écriture à confirmer, annulation en DANGER',()=>{
  assert.equal(lvl('lint_code'),'SAFE');assert.equal(lvl('type_check'),'SAFE');
  assert.equal(lvl('lint_code',{fix:true}),'CONFIRM');assert.equal(lvl('format_code',{check:true}),'SAFE');assert.equal(lvl('format_code'),'CONFIRM');
  assert.equal(lvl('git_commit',{message:'x'}),'CONFIRM');assert.equal(lvl('git_checkout',{branch:'a'}),'CONFIRM');
  assert.equal(lvl('git_branch'),'SAFE');assert.equal(lvl('git_branch',{action:'create',name:'a'}),'CONFIRM');
  assert.equal(lvl('git_branch',{action:'delete',name:'a'}),'CONFIRM');assert.equal(lvl('git_branch',{action:'delete',name:'a',force:true}),'DANGER');
  assert.equal(lvl('git_stash',{action:'list'}),'SAFE');assert.equal(lvl('git_stash',{action:'drop'}),'CONFIRM');
  assert.equal(lvl('git_restore',{path:'a.js'}),'DANGER');
  assert.equal(lvl('deps_install'),'CONFIRM');assert.equal(lvl('deps_install',{},{userInstall:true}),'SAFE');
  assert.equal(lvl('deps_audit'),'CONFIRM');assert.equal(lvl('deps_outdated'),'CONFIRM');assert.equal(lvl('web_search',{query:'a'}),'CONFIRM');
  assert.equal(perms.classifyTool('git_restore',{path:'a'},{root,created:new Set()}).cat,'DESTRUCTIVE');
  assert.equal(perms.classifyTool('web_search',{query:'a'},{root,created:new Set()}).cat,'NETWORK')});
 if(hasGit){
  g('init','-q');g('config','user.name','');g('config','user.email','');
  fs.writeFileSync(path.join(root,'a.js'),'let a=1;\n');fs.mkdirSync(path.join(root,'node_modules'));fs.writeFileSync(path.join(root,'node_modules','x.js'),'x');fs.mkdirSync(path.join(root,'.kairo'));fs.writeFileSync(path.join(root,'.kairo','b.json'),'{}');
  await T('git_commit : message obligatoire, ignore .kairo et node_modules, identité de secours',async()=>{
   await rejects(run('git_commit',{message:' '}),/message/);
   const r=await run('git_commit',{message:'premier commit'});assert.match(r,/premier commit/);
   const files=g('ls-files').stdout;assert.match(files,/a\.js/);assert.doesNotMatch(files,/node_modules|\.kairo/);
   assert.match(await run('git_commit',{message:'rien'}),/Rien à valider/)});
  await T('git_commit : paths hors du projet refusés',async()=>{await rejects(run('git_commit',{message:'x',paths:['../../etc/passwd']}),/hors du projet/)});
  await T('git_branch : liste, création, suppression, noms invalides',async()=>{
   await run('git_branch',{action:'create',name:'feature/x'});assert.match(await run('git_branch'),/feature\/x/);
   await rejects(run('git_branch',{action:'create',name:'--force'}),/invalide/);await rejects(run('git_branch',{action:'create',name:'a..b'}),/invalide/);
   await run('git_branch',{action:'delete',name:'feature/x'});assert.doesNotMatch(await run('git_branch'),/feature\/x/);
   await rejects(run('git_branch',{action:'zzz',name:'q'}),/inconnue/)});
  await T('git_checkout : création puis retour',async()=>{
   const r=await run('git_checkout',{branch:'dev',create:true});assert.match(r,/dev/);
   assert.match(g('branch','--show-current').stdout,/dev/);await run('git_checkout',{branch:g('branch').stdout.includes('master')?'master':'main'})});
  await T('git_stash : push, list, pop',async()=>{
   fs.writeFileSync(path.join(root,'a.js'),'let a=2;\n');
   await run('git_stash',{action:'push',message:'test'});assert.equal(fs.readFileSync(path.join(root,'a.js'),'utf8'),'let a=1;\n');
   assert.match(await run('git_stash',{action:'list'}),/test/);await run('git_stash',{action:'pop'});assert.equal(fs.readFileSync(path.join(root,'a.js'),'utf8'),'let a=2;\n')});
  await T('git_restore : annule les modifications, chemin obligatoire',async()=>{
   await rejects(run('git_restore',{}),/chemin manquant/);await run('git_restore',{path:'a.js'});assert.equal(fs.readFileSync(path.join(root,'a.js'),'utf8'),'let a=1;\n')});
 }else console.log('  (git absent : tests git ignorés)');
 await T('lint/format/type : message clair quand aucun outil n’est installé',async()=>{
  const e=fs.mkdtempSync(path.join(os.tmpdir(),'astra-empty-')),c2={root:e,emit(){},created:new Set()};
  assert.match(await tools.lint_code.run({},c2),/Aucun linter|aucun problème|Ruff/i);
  assert.match(await tools.format_code.run({},c2),/Aucun formateur|Ruff|Black/i);
  assert.match(await tools.type_check.run({},c2),/Aucun vérificateur/)});
 await T('deps_install : noms de paquets validés, projet sans manifeste refusé',async()=>{
  assert.equal(dev.pkgSpec('@types/node@20.1.0'),'@types/node@20.1.0');assert.equal(dev.pkgSpec('requests>=2.0'),'requests>=2.0');
  for(const bad of ['--global','a;rm -rf /','a b','$(x)','','-g','a&&b'])assert.throws(()=>dev.pkgSpec(bad),/invalide/);
  const e=fs.mkdtempSync(path.join(os.tmpdir(),'astra-empty-'));
  await rejects(tools.deps_install.run({},{root:e,emit(){}}),/Aucun package\.json/)});
 await T('deps_outdated / deps_audit : résumés lisibles',()=>{
  const o=dev.summarizeOutdated('npm',JSON.stringify({lodash:{current:'4.0.0',wanted:'4.17.21',latest:'4.17.21'},vite:{current:'5.0.0',wanted:'5.4.0',latest:'6.0.0',type:'devDependencies'}}));
  assert.match(o,/2 paquet/);assert.match(o,/lodash : 4\.0\.0 → 4\.17\.21/);assert.match(o,/\[dev\]/);
  assert.equal(dev.summarizeOutdated('npm','{}'),'Tout est à jour.');
  assert.match(dev.summarizeOutdated('pip',JSON.stringify([{name:'requests',version:'2.0',latest_version:'2.32'}])),/requests : 2\.0 → 2\.32/);
  const a=dev.summarizeAudit(JSON.stringify({metadata:{vulnerabilities:{critical:1,high:0,moderate:1,low:0,total:2}},vulnerabilities:{minimist:{severity:'critical',fixAvailable:true},ws:{severity:'moderate',fixAvailable:{name:'ws',version:'8.17.1'}}}}));
  assert.match(a,/2 faille\(s\) : 1 critical, 1 moderate/);assert.match(a,/\[critical\] minimist/);assert.match(a,/ws@8\.17\.1/);
  assert.match(dev.summarizeAudit(JSON.stringify({metadata:{vulnerabilities:{total:0}}})),/Aucune faille/)});
 await T('web_search : analyse des résultats DuckDuckGo et SearXNG (sans réseau)',()=>{
  const html='<div class="result"><h2><a rel="nofollow" class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fnodejs.org%2Fapi%2Ffs.html&amp;rut=abc">Node.js <b>fs</b> API</a></h2><a class="result__snippet" href="x">Le module <b>fs</b> permet &amp; plus</a></div>'+
   '<div class="result"><a class="result__a" href="https://example.com/b">Autre &quot;page&quot;</a><a class="result__snippet">Deuxième extrait</a></div><a class="result__a" href="javascript:alert(1)">piège</a>';
  const r=dev.parseDuckDuckGo(html);assert.equal(r.length,2);
  assert.deepEqual(r[0],{title:'Node.js fs API',url:'https://nodejs.org/api/fs.html',snippet:'Le module fs permet & plus'});
  assert.equal(r[1].title,'Autre "page"');assert.equal(r[1].snippet,'Deuxième extrait');
  assert.equal(dev.parseSearx(JSON.stringify({results:[{title:'T',url:'https://a.b',content:'C'},{title:'x',url:'ftp://no'}]})).length,1);
  assert.deepEqual(dev.parseDuckDuckGo('<html>rien</html>'),[])});
 await T('web_search : requêtes invalides refusées',async()=>{
  await rejects(run('web_search',{query:'  '}),/vide/);await rejects(run('web_search',{query:'x'.repeat(301)}),/trop longue/);
  await rejects(tools.web_search.run({query:'a'},{root,settings:{searchUrl:'ftp://x'}}),/searchUrl invalide/)});
 console.log('\n'+ok+' contrôles réussis');
})().catch(e=>{console.error('✗',e.message);process.exit(1)});
