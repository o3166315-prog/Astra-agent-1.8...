// Tests des outils V5.2 (node tests/extratools.test.js) : vrais fichiers, vraies permissions, aucun modèle.
const assert = require('node:assert/strict'), fs = require('fs'), os = require('os'), path = require('path'), { spawnSync } = require('child_process');
const { tools } = require('../server/tools'), perms = require('../server/perms'), { META, parseCsv } = require('../server/extratools');
const root = fs.mkdtempSync(path.join(os.tmpdir(), 'kairo-xt-')), ctx = { root, emit() {}, created: new Set() };
const run = (n, a) => tools[n].run(a || {}, ctx), txt = r => String(r && r.text !== undefined ? r.text : r), rd = f => fs.readFileSync(path.join(root, f), 'utf8');
const rejects = async (p, re) => { try { await p; } catch (e) { assert.match(e.message, re); return; } assert.fail('aurait dû échouer'); };
const lvl = (n, a) => perms.classifyTool(n, a, { root, created: new Set() }).level;
let ok = 0; const T = async (n, f) => { await f(); ok++; console.log('  ✓', n); };
const W = (f, c) => { fs.mkdirSync(path.dirname(path.join(root, f)), { recursive: true }); fs.writeFileSync(path.join(root, f), c); };

(async () => {
  W('src/app.js', '// TODO: nettoyer\nclass Moteur {\n  demarrer() {\n    return 1;\n  }\n}\nfunction calcule(a, b) { return a + b; }\nconst double = (x) => x * 2;\nexport async function charge() {}\n');
  W('src/util.py', 'import os\n# FIXME: gérer les erreurs\ndef lire(p):\n    return p\nclass Cache:\n    pass\n');
  W('data/notes.csv', 'nom,age,ville\n"Dupont, Jean",42,Paris\nMarie,31,Lyon\n');
  W('config.json', '{"b":2,"a":{"z":1,"y":[1,2]}}');
  W('README.md', '# Titre\n\ntexte\n\n## Section\n');

  await T('search_regex : motif, glob, contexte, limite', async () => {
    const r = txt(await run('search_regex', { pattern: 'function\\s+\\w+', glob: '*.js' }));
    assert.match(r, /src[\\/]app\.js:7: function calcule/); assert.doesNotMatch(r, /util\.py/);
    assert.match(txt(await run('search_regex', { pattern: 'demarrer', context: 1 })), /app\.js:2- class Moteur/);
    assert.equal(txt(await run('search_regex', { pattern: 'introuvable_xyz' })), 'Aucune correspondance');
    await rejects(run('search_regex', { pattern: '(' }), /invalide/);
    await rejects(run('search_regex', { pattern: 'a'.repeat(201) }), /trop long/);
    assert.match(txt(await run('search_regex', { pattern: '.', max: 2 })), /limite atteinte/);
  });
  await T('tree : arbre, profondeur, tailles', async () => {
    const r = txt(await run('tree', { depth: 2, sizes: true }));
    assert.match(r, /├── |└── /); assert.match(r, /src\//); assert.match(r, /app\.js\s+\(/);
    assert.doesNotMatch(txt(await run('tree', { depth: 1 })), /app\.js/);
    await rejects(run('tree', { path: 'nope' }), /inexistant/);
  });
  await T('code_stats : langages et plus gros fichiers', async () => {
    const r = txt(await run('code_stats'));
    assert.match(r, /\.js\s+1 fichiers/); assert.match(r, /\.py/); assert.match(r, /Plus gros/);
  });
  await T('find_todos : TODO et FIXME, README ignoré', async () => {
    const r = txt(await run('find_todos'));
    assert.match(r, /\[TODO\] nettoyer/); assert.match(r, /\[FIXME\] gérer les erreurs/);
    assert.match(txt(await run('find_todos', { tags: 'FIXME' })), /1 marqueur/);
  });
  await T('outline_code : js, python, markdown', async () => {
    const js = txt(await run('outline_code', { path: 'src/app.js' }));
    assert.match(js, /class Moteur/); assert.match(js, /demarrer\(\)/); assert.match(js, /function calcule/); assert.match(js, /const double/); assert.match(js, /export async function charge/);
    assert.doesNotMatch(js, /return 1/);
    const py = txt(await run('outline_code', { path: 'src/util.py' })); assert.match(py, /def lire/); assert.match(py, /class Cache/);
    assert.match(txt(await run('outline_code', { path: 'README.md' })), /## Section/);
    assert.match(txt(await run('outline_code', { path: 'config.json' })), /non pris en charge/);
    await rejects(run('outline_code', { path: 'absent.js' }), /inexistant/);
  });
  await T('csv_info : guillemets, séparateur, types', async () => {
    assert.deepEqual(parseCsv('a,"b,c"\n1,2\n', ','), [['a', 'b,c'], ['1', '2']]);
    const r = txt(await run('csv_info', { path: 'data/notes.csv' }));
    assert.match(r, /2 ligne\(s\) · 3 colonne\(s\)/); assert.match(r, /age : entier/); assert.match(r, /Dupont, Jean/);
  });
  await T('hash_text / encode_decode / uuid_generate', async () => {
    assert.equal(txt(await run('hash_text', { text: 'abc' })), 'sha256 : ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad');
    assert.match(txt(await run('hash_text', { text: 'abc', algo: 'md5' })), /900150983cd24fb0d6963f7d28e17f72/);
    assert.match(txt(await run('hash_text', { path: 'config.json' })), /^sha256 : [0-9a-f]{64}$/);
    await rejects(run('hash_text', { text: 'x', algo: 'crc' }), /inconnu/);
    assert.equal(txt(await run('encode_decode', { text: 'Kairo é', op: 'base64-encode' })), Buffer.from('Kairo é').toString('base64'));
    assert.equal(txt(await run('encode_decode', { text: 'S2Fpcm8gw6k=', op: 'base64-decode' })), 'Kairo é');
    assert.equal(txt(await run('encode_decode', { text: 'a b&c', op: 'url-encode' })), 'a%20b%26c');
    assert.equal(txt(await run('encode_decode', { text: '4b61', op: 'hex-decode' })), 'Ka');
    assert.equal(txt(await run('encode_decode', { text: 'a"b\nc', op: 'json-escape' })), 'a\\"b\\nc');
    await rejects(run('encode_decode', { text: 'zz', op: 'hex-decode' }), /invalide/);
    await rejects(run('encode_decode', { text: 'x', op: 'rot13' }), /op inconnue/);
    const ids = txt(await run('uuid_generate', { count: 3 })).split('\n'); assert.equal(ids.length, 3); assert.match(ids[0], /^[0-9a-f]{8}-[0-9a-f]{4}-4/);
    assert.equal(txt(await run('uuid_generate', { count: 99 })).split('\n').length, 20);
  });
  await T('regex_test : groupes, indices, motifs vides', async () => {
    const r = txt(await run('regex_test', { pattern: '(\\d+)-(\\w+)', text: 'a 12-ab et 7-z' }));
    assert.match(r, /2 correspondance/); assert.match(r, /groupes : "12", "ab"/);
    assert.match(txt(await run('regex_test', { pattern: 'x*', text: 'ab' })), /correspondance/);
    assert.equal(txt(await run('regex_test', { pattern: 'zzz', text: 'ab' })), 'Aucune correspondance');
    await rejects(run('regex_test', { pattern: '[', text: 'a' }), /invalide/);
  });
  await T('date_calc : ajouts, écart, dates invalides', async () => {
    assert.match(txt(await run('date_calc', { date: '2026-10-31', add_days: 1 })), /dimanche 2026-11-01/);
    assert.match(txt(await run('date_calc', { date: '2026-01-31', add_months: 1 })), /2026-03-03/);
    assert.match(txt(await run('date_calc', { date: '2026-10-31', until: '2026-12-25' })), /55 jour\(s\)/);
    assert.match(txt(await run('date_calc')), /^Date : /);
    await rejects(run('date_calc', { date: 'pas-une-date' }), /invalide/);
  });
  await T('format_json : indentation, tri, diff, sauvegarde, déjà formaté', async () => {
    const r = await run('format_json', { path: 'config.json', sort: true });
    assert.match(r.text, /Formaté/); assert.ok(r.diff && r.changeId);
    assert.deepEqual(Object.keys(JSON.parse(rd('config.json'))), ['a', 'b']); assert.match(rd('config.json'), /\n  "a": \{/);
    assert.match(txt(await run('format_json', { path: 'config.json', sort: true })), /déjà formaté/);
    W('bad.json', '{oops'); await rejects(run('format_json', { path: 'bad.json' }), /JSON invalide/);
    await rejects(run('format_json', { path: '.kairo/x.json' }), /interne/);
  });

  const hasGit = !spawnSync('git', ['--version']).error;
  if (hasGit) {
    await T('git_* : hors dépôt, puis status / log / diff', async () => {
      await rejects(run('git_status'), /pas un dépôt/);
      const g = (...a) => spawnSync('git', ['-c', 'user.name=t', '-c', 'user.email=t@t', ...a], { cwd: root, encoding: 'utf8' });
      g('init', '-q'); g('add', '-A'); g('commit', '-q', '-m', 'premier commit');
      assert.match(txt(await run('git_status')), /^## /); assert.match(txt(await run('git_log')), /premier commit/);
      assert.equal(txt(await run('git_diff')), 'Aucune différence');
      fs.appendFileSync(path.join(root, 'README.md'), 'ligne ajoutée\n');
      assert.match(txt(await run('git_status')), /M README\.md/); assert.match(txt(await run('git_diff', { path: 'README.md' })), /\+ligne ajoutée/);
      await rejects(run('git_log', { path: '../..' }), /hors du projet/);
    });
  } else console.log('  - git absent : tests git ignorés');

  console.log('\nPermissions');
  await T('lecture seule = SAFE dans le projet, hors projet = confirmation', async () => {
    for (const n of ['search_regex', 'tree', 'code_stats', 'find_todos']) assert.equal(lvl(n, {}), 'SAFE', n);
    assert.equal(lvl('outline_code', { path: 'src/app.js' }), 'SAFE'); assert.equal(lvl('csv_info', { path: 'data/notes.csv' }), 'SAFE');
    assert.notEqual(lvl('tree', { path: '/etc' }), 'SAFE'); assert.notEqual(lvl('outline_code', { path: '/etc/passwd' }), 'SAFE');
  });
  await T('utilitaires purs et git en lecture = SAFE', async () => {
    for (const n of ['git_status', 'git_log', 'git_diff', 'encode_decode', 'uuid_generate', 'regex_test', 'date_calc']) assert.equal(lvl(n, {}), 'SAFE', n);
    assert.equal(lvl('hash_text', { text: 'x' }), 'SAFE'); assert.equal(lvl('hash_text', { path: 'config.json' }), 'SAFE'); assert.notEqual(lvl('hash_text', { path: '/etc/passwd' }), 'SAFE');
  });
  await T('format_json : écriture classée comme write_file', async () => {
    assert.equal(lvl('format_json', { path: 'config.json' }), lvl('write_file', { path: 'config.json' }));
    assert.notEqual(lvl('format_json', { path: '/etc/x.json' }), 'SAFE');
  });
  await T('catalogue : chaque outil a une description, META ne cite que des outils existants', async () => {
    for (const [n, t] of Object.entries(tools)) assert.ok(typeof t.desc === 'string' && t.desc.length > 10 || n.startsWith('gui_') || t.perm, 'description manquante : ' + n);
    for (const n of Object.keys(META)) if (!['screenshot', 'gui_click', 'gui_type', 'gui_key'].includes(n)) assert.ok(tools[n], 'META orphelin : ' + n);
  });

  console.log(`\n${ok} tests OK`);
})().catch(e => { console.error('✗', e.message); process.exit(1); });
