'use strict';
const assert=require('assert'),fs=require('fs'),os=require('os'),path=require('path');
const {manager}=require('../server/time-machine');
const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'astra-tm-')),root=path.join(tmp,'project'),data=path.join(tmp,'data');fs.mkdirSync(root);fs.mkdirSync(data);
try{
 fs.writeFileSync(path.join(root,'hello.txt'),'before');fs.writeFileSync(path.join(root,'.env'),'SECRET=do-not-save');fs.mkdirSync(path.join(root,'node_modules'));fs.writeFileSync(path.join(root,'node_modules','dep.js'),'ignored');
 const tm=manager(data),snap=tm.snapshot('p1',root,'test');assert.equal(snap.fileCount,1);assert.equal(tm.list('p1').length,1);
 fs.writeFileSync(path.join(root,'hello.txt'),'after');fs.writeFileSync(path.join(root,'new.txt'),'new');
 assert.throws(()=>tm.restore('p1',root,snap.id,{confirm:false}),/Confirmation/);
 const r=tm.restore('p1',root,snap.id,{confirm:true});assert.equal(fs.readFileSync(path.join(root,'hello.txt'),'utf8'),'before');assert.equal(fs.existsSync(path.join(root,'new.txt')),false);assert.equal(r.quarantined,1);assert.equal(fs.existsSync(path.join(root,'.env')),true);assert.equal(fs.existsSync(path.join(root,'node_modules','dep.js')),true);assert.ok(r.backup);
 assert.equal(tm.remove('p1',snap.id),true);assert.equal(tm.list('p1').length,1); // automatic pre-restore backup remains
 console.log('✓ Astra Time Machine : snapshots, exclusions, confirmation, restauration et quarantaine');
}finally{fs.rmSync(tmp,{recursive:true,force:true})}
