# Kairo V5.0.0 — Meta AI · Muse

## Meta Model API
- Nouveau provider `meta` sur `https://api.meta.ai/v1`.
- Authentification Bearer avec la clé `MODEL_API_KEY` enregistrée dans les paramètres locaux.
- Découverte dynamique des modèles via `GET /v1/models`.
- Chat via l'endpoint OpenAI-compatible `/v1/chat/completions`, compatible avec la boucle d'agent existante.
- Les modèles Muse détectés comme multimodaux peuvent recevoir les images ; Vision Lite reste le repli.
- Meta AI · Muse apparaît en premier dans le sélecteur et bénéficie d'un encart dédié dans Paramètres.

## Identité
- Nouvelle mascotte vectorielle originale Kairo, intégrée à la barre latérale et à l'en-tête de l'agent.

## Limites connues
- Kairo utilise actuellement Chat Completions. Les fonctions propres à Responses API (reprise du raisonnement, recherche intégrée et autres fonctions agentiques Meta) ne sont pas encore intégrées.
- Les modèles et leur disponibilité dépendent du compte Meta Model API et de ses autorisations.
