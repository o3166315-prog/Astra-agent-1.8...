// Astra Command Center (backend) : agrège missions, ressources, diagnostic et rapports. Aucune donnée simulée :
// ce qui n'est pas mesurable sur cette machine est déclaré « non disponible ».
const fs = require('fs'), os = require('os'), path = require('path'), http = require('http');
const { execFile } = require('child_process');
const S = require('./store');
const G = require('./comm-graph');

const TERMINAL = new Set(['ready_for_review', 'completed_with_errors', 'completed_with_conflicts', 'integrated', 'failed']);
const ACTIVE_STATES = new Set(['preparing', 'planning', 'reviewing']);

/* ── Missions ─────────────────────────────────────────────────────────────────────────────── */
function progressOf(m) {
  const w = m.workers || [], total = w.length || 1, done = w.filter(x => ['completed', 'failed', 'stopped'].includes(x.status)).length;
  if (TERMINAL.has(m.status)) return 100;
  if (m.status === 'preparing') return 3;
  if (m.status === 'planning') return 10;
  if (m.status === 'reviewing') return 90;
  return Math.min(89, Math.round(10 + 80 * done / total));
}
function summarizeMission(m, o) {
  o = o || {}; const now = o.now || Date.now();
  const start = Date.parse(m.createdAt) || 0, end = TERMINAL.has(m.status) ? (Date.parse(m.updatedAt) || now) : now;
  const live = !!o.live;
  const status = m.status === 'integrated' ? 'completed' : TERMINAL.has(m.status) ? (m.status === 'failed' ? 'failed' : 'completed') : (live ? (w => w.some(x => x.status === 'paused' || x.status === 'pausing') && !w.some(x => x.status === 'working') ? 'paused' : 'running')(m.workers || []) : 'interrupted');
  return {
    id: m.id, project: o.project || m.project, projectName: o.projectName || '', title: m.title || m.id, rawStatus: m.status, status,
    live, progress: progressOf(m), durationMs: start ? Math.max(0, end - start) : 0, createdAt: m.createdAt, updatedAt: m.updatedAt,
    agents: (m.workers || []).map(w => ({ id: w.id, name: w.name, status: w.status, provider: w.provider, model: w.model })),
    model: m.coordinator ? m.coordinator.provider + '/' + m.coordinator.model : '', changes: (m.changes || []).length, conflicts: (m.conflicts || []).length
  };
}
// Une mission « interrupted » = enregistrée comme encore en cours alors qu'aucun travail ne tourne (redémarrage d'Astra).
function listMissions(projects, activeIds, now) {
  const out = [];
  for (const p of projects || []) {
    const list = S.read('swarm-' + String(p.id).replace(/[^\w-]/g, '') + '.json', []);
    for (const m of list) out.push(summarizeMission(m, { project: p.id, projectName: p.name, live: activeIds.has(m.id), now }));
  }
  return out.sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
}
function findMission(projects, id) {
  for (const p of projects || []) {
    const list = S.read('swarm-' + String(p.id).replace(/[^\w-]/g, '') + '.json', []), m = list.find(x => x.id === id);
    if (m) return { mission: m, project: p };
  }
  return null;
}

/* ── Rapport de mission (Markdown) ───────────────────────────────────────────────────────── */
function missionReport(m, projectName) {
  const g = G.buildGraph(m), sum = summarizeMission(m, { live: false });
  const L = [];
  L.push('# Rapport de mission — ' + (m.title || m.id), '');
  L.push('- **Projet** : ' + (projectName || m.project || '—'), '- **Identifiant** : `' + m.id + '`', '- **Statut** : ' + m.status, '- **Durée** : ' + G.fmtDuration(sum.durationMs), '- **Créée** : ' + (m.createdAt || '—'), '- **Coordinateur** : ' + (m.coordinator ? m.coordinator.provider + ' / ' + m.coordinator.model : '—'), '');
  L.push('## Diagnostic', '', g.diagnosis, '');
  L.push('## Agents', '', '| Agent | Rôle | Modèle | Statut | Tâche |', '| --- | --- | --- | --- | --- |');
  for (const w of m.workers || []) L.push('| ' + [w.name, w.role, (w.provider || '') + ' / ' + (w.model || ''), w.status, String(w.task || '').replace(/\|/g, '/').replace(/\n/g, ' ').slice(0, 200)].join(' | ') + ' |');
  L.push('');
  if ((m.plan || []).length) { L.push('## Plan', ''); m.plan.forEach((p, i) => L.push((i + 1) + '. ' + p)); L.push(''); }
  L.push('## Résultats des agents', '');
  for (const w of m.workers || []) L.push('### ' + (w.name || w.id), '', String(w.result || '(aucun rapport)').slice(0, 1800), '');
  L.push('## Changements proposés', '');
  if ((m.changes || []).length) for (const c of m.changes) L.push('- `' + c.path + '` — ' + c.type + ' (agent ' + c.workerId + ', ' + (c.size || 0) + ' octets)'); else L.push('Aucun changement détecté.');
  if ((m.conflicts || []).length) L.push('', '**Conflits** : ' + m.conflicts.join(', '));
  if (m.integration) L.push('', '**Fusion** : ' + (m.integration.applied || []).length + ' fichier(s) appliqué(s), ' + (m.integration.conflicts || []).length + ' non fusionné(s).');
  L.push('', '## Rapport du reviewer', '', String(m.review || '(en attente ou indisponible)'), '');
  if (g.alerts.length) { L.push('## Alertes', ''); for (const a of g.alerts) L.push('- [' + a.level + '] ' + a.text); L.push(''); }
  L.push('## Chronologie des échanges', '', 'Échanges réellement enregistrés (aucun message reconstitué).', '');
  for (const x of g.messages) L.push('- ' + new Date(x.timestamp).toISOString().slice(11, 19) + ' · ' + x.type + ' · ' + x.from + ' → ' + x.to + ' · ' + x.status);
  L.push('', '_Rapport généré par Astra Command Center._', '');
  return L.join('\n');
}

/* ── Ressources du PC ─────────────────────────────────────────────────────────────────────── */
let lastCpu = null, cache = { res: null, at: 0 }, gpuCache = { v: null, at: 0 };
const cpuTimes = () => os.cpus().reduce((a, c) => { const t = c.times; a.idle += t.idle; a.total += t.user + t.nice + t.sys + t.idle + t.irq; return a; }, { idle: 0, total: 0 });
async function cpuPercent() {
  const now = cpuTimes();
  if (!lastCpu) { await new Promise(r => setTimeout(r, 150)); lastCpu = now; const n2 = cpuTimes(); const d = { idle: n2.idle - now.idle, total: n2.total - now.total }; lastCpu = n2; return d.total ? Math.round(100 * (1 - d.idle / d.total)) : 0; }
  const d = { idle: now.idle - lastCpu.idle, total: now.total - lastCpu.total }; lastCpu = now;
  return d.total ? Math.round(100 * (1 - d.idle / d.total)) : null;
}
const getJson = (url, ms) => new Promise(res => { try { const u = new URL(url); const r = http.get(u, { timeout: ms }, resp => { let b = ''; resp.on('data', d => b += d); resp.on('end', () => { try { res(JSON.parse(b)); } catch { res(null); } }); }); r.on('timeout', () => { r.destroy(); res(null); }); r.on('error', () => res(null)); } catch { res(null); } });
const gpu = () => new Promise(res => {
  if (gpuCache.at && Date.now() - gpuCache.at < 15000) return res(gpuCache.v);
  execFile('nvidia-smi', ['--query-gpu=name,utilization.gpu,memory.used,memory.total', '--format=csv,noheader,nounits'], { timeout: 1500, windowsHide: true }, (e, so) => {
    let v = { available: false, reason: 'nvidia-smi introuvable ou GPU non pris en charge' };
    if (!e && so) { const p = String(so).trim().split('\n')[0].split(',').map(x => x.trim()); if (p.length >= 4) v = { available: true, name: p[0], utilization: +p[1], memUsedMb: +p[2], memTotalMb: +p[3] }; }
    gpuCache = { v, at: Date.now() }; res(v);
  });
});
async function resources({ settings, monitor, dataDir, force }) {
  if (!force && cache.res && Date.now() - cache.at < 2500) return cache.res;
  const total = os.totalmem(), free = os.freemem(), mu = process.memoryUsage();
  let disk = null; try { if (fs.statfsSync) { const s = fs.statfsSync(dataDir || '.'); disk = { totalBytes: s.blocks * s.bsize, freeBytes: s.bavail * s.bsize }; } } catch {}
  const ollamaUrl = (settings && settings.ollama && settings.ollama.url) || 'http://localhost:11434';
  const [cpu, g, ps] = await Promise.all([cpuPercent(), gpu(), getJson(ollamaUrl + '/api/ps', 800)]);
  const hour = monitor ? monitor._raw().filter(r => Date.now() - Date.parse(r.at) < 3600000) : [];
  const res = {
    at: new Date().toISOString(), cpu: { percent: cpu, cores: os.cpus().length, model: (os.cpus()[0] || {}).model || '' },
    ram: { totalBytes: total, usedBytes: total - free, percent: Math.round(100 * (total - free) / total) },
    gpu: g, disk,
    network: { note: 'Débit réseau non mesurable sans outil système.', modelRequestsLastHour: hour.length, failuresLastHour: hour.filter(r => !r.ok).length, sentCharsLastHour: hour.reduce((a, r) => a + r.inChars, 0), receivedCharsLastHour: hour.reduce((a, r) => a + r.outChars, 0) },
    astra: { pid: process.pid, rssBytes: mu.rss, heapUsedBytes: mu.heapUsed, uptimeSec: Math.round(process.uptime()), node: process.version, platform: process.platform },
    localModels: ps ? { reachable: true, running: (ps.models || []).map(m => ({ name: m.name || m.model, sizeBytes: m.size || 0, vramBytes: m.size_vram || 0 })) } : { reachable: false },
    scope: 'Ressources de CE PC. Les modèles cloud consomment les ressources du fournisseur, pas les vôtres.'
  };
  cache = { res, at: Date.now() }; return res;
}

/* ── Diagnostic ───────────────────────────────────────────────────────────────────────────── */
function dirSize(root, limit) {
  let total = 0, n = 0; const stack = [root];
  while (stack.length && n < (limit || 30000)) {
    const d = stack.pop(); let items = []; try { items = fs.readdirSync(d, { withFileTypes: true }); } catch { continue; }
    for (const it of items) { n++; const p = path.join(d, it.name); if (it.isSymbolicLink()) continue; if (it.isDirectory()) stack.push(p); else try { total += fs.statSync(p).size; } catch {} }
  }
  return { bytes: total, truncated: n >= (limit || 30000) };
}
async function diagnostics({ settings, providers, projects, dataDir, port, caps }) {
  const checks = [], add = (id, label, status, detail, fix) => checks.push({ id, label, status, detail: detail || '', fix: fix || '' });
  const major = +process.versions.node.split('.')[0];
  add('node', 'Version de Node.js', major >= 18 ? 'ok' : 'fail', process.version, major >= 18 ? '' : 'Installe Node.js 18 ou plus récent.');
  try { const f = path.join(dataDir, '.diag-' + process.pid); fs.writeFileSync(f, 'x'); fs.unlinkSync(f); add('data', 'Dossier de données inscriptible', 'ok', dataDir); }
  catch (e) { add('data', 'Dossier de données inscriptible', 'fail', e.message, 'Vérifie les droits sur le dossier data/.'); }
  try { if (fs.statfsSync) { const s = fs.statfsSync(dataDir), free = s.bavail * s.bsize; add('disk', 'Espace disque libre', free > 2e9 ? 'ok' : free > 5e8 ? 'warn' : 'fail', (free / 1e9).toFixed(1) + ' Go libres', free > 2e9 ? '' : 'Libère de l’espace : les copies Swarm peuvent atteindre plusieurs centaines de Mo.'); } } catch {}
  const withKey = Object.keys(providers).filter(k => settings[k] && settings[k].key);
  add('providers', 'Fournisseurs avec clé API', withKey.length ? 'ok' : 'warn', withKey.length ? withKey.map(k => providers[k].label).join(', ') : 'aucun', withKey.length ? '' : 'Ajoute une clé dans Paramètres → Providers (ou utilise Ollama en local).');
  add('meta', 'Demo Mode : clé Meta Model API', settings.meta && settings.meta.key ? 'ok' : 'info', settings.meta && settings.meta.key ? 'clé enregistrée' : 'absente (nécessaire seulement pour le Demo Mode)');
  const ollamaUrl = (settings.ollama && settings.ollama.url) || 'http://localhost:11434', tags = await getJson(ollamaUrl + '/api/tags', 1200);
  add('ollama', 'Ollama (modèles locaux)', tags ? 'ok' : 'info', tags ? (tags.models || []).length + ' modèle(s) installé(s)' : 'non joignable sur ' + ollamaUrl, tags ? '' : 'Lance « ollama serve » si tu veux utiliser des modèles locaux.');
  const bad = (projects || []).filter(p => p.root && !fs.existsSync(p.root));
  add('projects', 'Dossiers des projets', bad.length ? 'warn' : 'ok', bad.length ? bad.map(p => p.name + ' → ' + p.root).join(' ; ') : (projects || []).length + ' projet(s) accessible(s)', bad.length ? 'Un dossier a été déplacé ou supprimé : rouvre le projet depuis Fichier → Ouvrir un dossier.' : '');
  const sw = path.join(dataDir, 'swarm-workspaces');
  if (fs.existsSync(sw)) { const s = dirSize(sw, 20000); add('swarmcopies', 'Copies de travail Swarm', s.bytes > 1e9 ? 'warn' : 'ok', (s.bytes / 1e6).toFixed(0) + ' Mo' + (s.truncated ? '+' : ''), s.bytes > 1e9 ? 'Supprime les anciens dossiers de data/swarm-workspaces/ (les missions déjà fusionnées n’en ont plus besoin).' : ''); }
  try { const c = await caps(); const miss = c.filter(t => !t.available).map(t => t.name); add('tools', 'Outils de développement détectés', 'info', c.filter(t => t.available).map(t => t.name).join(', ') || 'aucun', miss.length ? 'Non détectés : ' + miss.slice(0, 8).join(', ') : ''); } catch {}
  add('network', 'Écoute locale', 'ok', '127.0.0.1:' + port + ' uniquement, jeton obligatoire pour /api');
  const worst = checks.some(c => c.status === 'fail') ? 'fail' : checks.some(c => c.status === 'warn') ? 'warn' : 'ok';
  return { at: new Date().toISOString(), status: worst, checks };
}

module.exports = { listMissions, findMission, summarizeMission, missionReport, resources, diagnostics, progressOf, TERMINAL, ACTIVE_STATES };
