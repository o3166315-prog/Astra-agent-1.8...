const http=require('http'),fs=require('fs'),path=require('path'),{execFile}=require('child_process');
const E=require('./env'),imagecodec=require('./imagecodec'),intent=require('./intent'),caps=require('./caps'),S=require('./store'),{providers}=require('./providers'),agent=require('./agent'),SW=require('./swarm'),{McpServer}=require('./mcp'),{walk,safe}=require('./tools');
const pathGuard=require('./path-guard');
const TEST=require('./auto-testing'),HEAL=require('./self-healing'),REC=require('./recovery');
const PORT=process.env.PORT||3000,PUB=path.join(__dirname,'..','public');
const VERSION=require('../package.json').version;
const TOKEN=process.env.ASTRA_TOKEN||require('crypto').randomBytes(24).toString('hex');
const ALLOWED_HOSTS=new Set(['localhost','127.0.0.1']);
const hostOf=h=>String(h||'').toLowerCase().replace(/:\d+$/,'');
const cookieOf=(req,n)=>{const m=String(req.headers.cookie||'').split(';').map(x=>x.trim()).find(x=>x.startsWith(n+'='));return m?m.slice(n.length+1):''};
const tokenOk=req=>{const t=String(req.headers['x-astra-token']||cookieOf(req,'astra_token')||'');const a=Buffer.from(t),b=Buffer.from(TOKEN);return a.length===b.length&&require('crypto').timingSafeEqual(a,b)};
// Garde : hôte autorisé (anti DNS-rebinding), origine identique, jeton pour /api
const guard=(req,p)=>{
  if(!ALLOWED_HOSTS.has(hostOf(req.headers.host)))return 'Hôte non autorisé.';
  const o=req.headers.origin;if(o&&o!=='http://'+req.headers.host&&o!=='https://'+req.headers.host)return 'Origine non autorisée.';
  if(p.startsWith('/api/')&&!tokenOk(req))return 'Jeton manquant ou invalide : recharge la page Astra Agent.';
  return '';
};
const MIME={'.html':'text/html','.js':'text/javascript','.css':'text/css','.svg':'image/svg+xml','.ttf':'font/ttf','.otf':'font/otf'};
let settings=S.read('settings.json',{}),projects=S.read('projects.json',[]);
const mcp={},pend={},loopPend={},createdMap={},swarmJobs={};const createdFor=pid=>createdMap[pid]||(createdMap[pid]=new Set());
const getProject=id=>projects.find(x=>x.id===cid(id));
const projectRoot=id=>{const pr=getProject(id);if(!pr)throw new Error('Projet introuvable : '+id);return pathGuard.canonicalProjectRoot(pr.root?String(pr.root):S.projDir(pr.id))};
const runPicker=kind=>new Promise((resolve,reject)=>{if(process.platform!=='win32')return reject(new Error('Le sélecteur système est disponible sur Windows.'));const file=kind==='file';const script=file?"Add-Type -AssemblyName System.Windows.Forms; $d=New-Object System.Windows.Forms.OpenFileDialog; $d.Title='Ouvrir un fichier dans Astra Agent'; $d.Multiselect=$false; if($d.ShowDialog() -eq 'OK'){[Console]::Out.Write($d.FileName)}":"Add-Type -AssemblyName System.Windows.Forms; $d=New-Object System.Windows.Forms.FolderBrowserDialog; $d.Description='Choisir le dossier à ouvrir dans Astra Agent'; $d.ShowNewFolderButton=$true; if($d.ShowDialog() -eq 'OK'){[Console]::Out.Write($d.SelectedPath)}";execFile('powershell.exe',['-NoProfile','-NonInteractive','-STA','-Command',script],{encoding:'utf8',timeout:120000,windowsHide:false},(e,so,se)=>{if(e)return reject(new Error((se||e.message||'Échec du sélecteur Windows').toString().trim()));resolve(String(so||'').trim())})});
const mem=id=>S.read('mem-'+id+'.json',{conversation:[],project:[],actions:[]});
const prefs=()=>S.read('prefs.json',[]);
const AUTO=require('./automode');
const cid=s=>String(s||'').replace(/[^\w-]/g,''),lst=p=>S.read('convs-'+p+'.json',[]),cv=(p,c)=>S.read('conv-'+p+'-'+c+'.json',{history:[],log:[]}),cw=(p,c,v)=>S.write('conv-'+p+'-'+c+'.json',v),EPH=new Map();
const Intel=require('./intelligence'),ACT=require('./activity').create(),CC=require('./command-center'),COMM=require('./comm-graph');
const TimeMachine=require('./time-machine').manager(S.dataDir);
const Council=require('./council').create({providers,getSettings:()=>settings,save:item=>{const list=S.read('council-'+cid(item.project||'global')+'.json',[]);list.unshift(item);S.write('council-'+cid(item.project||'global')+'.json',list.slice(0,20));}});
const INT=Intel.create({providers,getSettings:()=>settings});
INT.monitor.on((type,d)=>{
 if(type==='call'&&!d.ok)ACT.reportError({origin:'Modèle '+d.provider+'/'+d.model,message:d.error||'Appel échoué',context:'durée '+d.ms+' ms'});
 else if(type==='selection')ACT.log('model','Routage : '+(d.chosen||d.recommended)+' ('+d.by+') pour une tâche '+d.task,{model:d.chosen||d.recommended});
 else if(type==='incident')ACT.log('model','Reprise : '+d.summary,{level:'warn',notify:true});
});
// Activité en direct d'une mission Swarm : uniquement des événements réellement émis par le backend.
const swarmAct=(mission,type,data)=>{
 const nm=wid=>(mission.workers.find(w=>w.id===wid)||{}).name||wid,m=mission.id;
 if(type==='mission')ACT.log('swarm','Mission créée : '+mission.title,{mission:m});
 else if(type==='plan')ACT.log('swarm','Plan réparti entre '+(data.workers||[]).length+' agent(s)'+(data.fallback?' — plan de secours : '+data.fallback:''),{mission:m,level:data.fallback?'warn':'info',notify:!!data.fallback});
 else if(type==='worker'){const lbl={working:'démarré',completed:'terminé',failed:'en échec',stopped:'arrêté',paused:'en pause',pausing:'pause demandée',stopping:'arrêt demandé'}[data.status];
  if(lbl)ACT.log('swarm','Agent '+nm(data.workerId)+' '+lbl,{mission:m,agent:data.workerId,level:data.status==='failed'?'error':'info',notify:data.status==='failed'||data.status==='paused'});
  if(data.status==='failed')ACT.reportError({origin:'Swarm · '+nm(data.workerId),message:data.result||data.lastAction||'Échec de l’agent',context:'mission '+m})}
 else if(type==='worker-event'&&data.event&&data.event.type==='error')ACT.log('swarm','Erreur '+nm(data.workerId)+' : '+data.event.message,{mission:m,agent:data.workerId,level:'error'});
 else if(type==='review-start')ACT.log('swarm','Revue indépendante démarrée',{mission:m});
 else if(type==='complete')ACT.log('swarm','Mission terminée · '+((data.conflicts||[]).length?(data.conflicts.length+' conflit(s)'):'sans conflit'),{mission:m,level:(data.conflicts||[]).length?'warn':'info',notify:true});
 else if(type==='error'){ACT.log('swarm','Mission en erreur : '+data.text,{mission:m,level:'error',notify:true});ACT.reportError({origin:'Swarm',message:data.text,context:'mission '+m})}
 else if(type==='fallback')ACT.log('model','Coordinateur : '+data.text,{mission:m,level:'warn'});
};
// Pause / reprise / arrêt d'un agent (partagé entre Live Monitor et Command Center).
const applyWorkerAction=(job,worker,action)=>{
 const done=()=>{job.updatedAt=new Date().toISOString();job.persist();job.push('worker',{workerId:worker.id,status:worker.status,lastAction:worker.lastAction});return true};
 if(action==='pause'&&worker.status==='working'){worker.paused=true;worker.status='pausing';worker.lastAction='Pause demandée — attente du prochain point de contrôle';return done()}
 if(action==='resume'&&worker.paused){worker.paused=false;worker.status='working';worker.lastAction='Reprise';return done()}
 if(action==='stop'&&worker.controller){worker.controller.abort();worker.paused=false;worker.status='stopping';worker.lastAction='Arrêt demandé';return done()}
 return false;
};
const activeIds=()=>new Set(Object.keys(swarmJobs));
for(const c of settings.mcp||[])mcp[c.name]=new McpServer(c);
class HttpInputError extends Error{constructor(message,statusCode=400){super(message);this.statusCode=statusCode;}}
const body=r=>new Promise((resolve,reject)=>{let chunks=[],size=0,tooLarge=false;const limit=12*1024*1024;r.on('data',chunk=>{size+=chunk.length;if(size>limit){tooLarge=true;chunks=[];return}if(!tooLarge)chunks.push(chunk)});r.on('error',reject);r.on('end',()=>{if(tooLarge)return reject(new HttpInputError('Corps JSON trop volumineux (limite 12 Mo).',413));const raw=Buffer.concat(chunks).toString('utf8').trim();if(!raw)return resolve({});let value;try{value=JSON.parse(raw)}catch(e){return reject(new HttpInputError('JSON invalide : '+e.message,400))}if(!value||typeof value!=='object'||Array.isArray(value))return reject(new HttpInputError('Le corps doit être un objet JSON.',400));resolve(value)})});
const send=(res,o,c=200)=>{if(res.headersSent){if(!res.writableEnded)res.end();return}res.writeHead(c,{'content-type':'application/json'});res.end(JSON.stringify(o))};
http.createServer(async(req,res)=>{
 const u=new URL(req.url,'http://x'),p=u.pathname;
 try{
 const deny=guard(req,p);if(deny)return send(res,{error:deny},403);
 if(!p.startsWith('/api/')){const f=path.resolve(PUB,'.'+(p==='/'?'/index.html':decodeURIComponent(p)));if(!f.startsWith(PUB+path.sep)||!fs.existsSync(f)||!fs.statSync(f).isFile()){res.writeHead(404);return res.end('404')}
  const h={'content-type':MIME[path.extname(f)]||'application/octet-stream','x-content-type-options':'nosniff','referrer-policy':'no-referrer'};
  if(path.basename(f)==='index.html')h['set-cookie']='astra_token='+TOKEN+'; HttpOnly; SameSite=Strict; Path=/';
  res.writeHead(200,h);return fs.createReadStream(f).pipe(res)}
 if(p==='/api/state')return send(res,{swarmAgents:settings.swarmAgents||[],vision:settings.vision||null,visionMode:settings.visionMode||'auto',image:{mode:settings.imageMode||'auto',size:settings.imageSize||'auto',encoding:settings.imageEncoding||'auto',normalize:settings.imageNormalize||'int',matrix:!!settings.imageMatrix},voice:settings.voice||{provider:'',model:'',voiceURI:'',lang:'fr-FR',rate:1,autoSpeak:true},autoTestAfterChanges:!!settings.autoTestAfterChanges,ui:settings.ui||null,profile:settings.profile||null,projects,providers:Object.fromEntries(Object.entries(providers).map(([k,v])=>[k,v.label])),settings:Object.fromEntries(Object.keys(providers).map(k=>[k,{hasKey:!!settings[k]?.key,url:settings[k]?.url||'',ctx:settings[k]?.ctx||''}]))});
 if(p==='/api/models'){const k=u.searchParams.get('p');if(!providers[k])return send(res,{models:[],error:'Fournisseur inconnu.'},400);try{return send(res,{models:await providers[k].models(settings[k]||{})})}catch(e){return send(res,{models:[],error:e.message})}}
 if(p==='/api/settings'){if(req.method!=='POST')return send(res,{error:'POST requis.'},405);const b=await body(req);if(!providers[b.provider])return send(res,{error:'Fournisseur inconnu.'},400);settings[b.provider]={...settings[b.provider],...(typeof b.key==='string'&&b.key?{key:b.key}:{}),...(typeof b.url==='string'&&b.url.trim()?{url:b.url.trim()}:b.clearUrl===true?{url:''}:{}),...(b.ctx?{ctx:Math.max(2048,Math.min(32768,+b.ctx||8192))}:{})};S.write('settings.json',settings);return send(res,{ok:true})}
 if(p==='/api/voice-settings'){if(req.method!=='POST')return send(res,{error:'POST requis.'},405);const b=await body(req),provider=String(b.provider||'');if(provider&&!providers[provider])return send(res,{error:'Fournisseur vocal inconnu.'},400);settings.voice={provider,model:String(b.model||'').slice(0,120),voiceURI:String(b.voiceURI||'').slice(0,240),lang:/^[a-z]{2,3}(-[A-Z]{2})?$/.test(String(b.lang||''))?String(b.lang):'fr-FR',rate:Math.max(0.7,Math.min(1.4,+b.rate||1)),autoSpeak:b.autoSpeak!==false};S.write('settings.json',settings);return send(res,{ok:true,voice:settings.voice})}
 if(p==='/api/self-healing'){if(req.method!=='GET')return send(res,{error:'GET requis.'},405);const pid=cid(u.searchParams.get('project')),root=projectRoot(pid);return send(res,{scan:HEAL.scanProject(root),errors:ACT.listErrors({status:'open'}).slice(0,30)})}
 if(p==='/api/self-healing/diagnose'){if(req.method!=='POST')return send(res,{error:'POST requis.'},405);const b=await body(req),pid=cid(b.project),root=projectRoot(pid),provider=String(b.provider||''),model=String(b.model||'');if(!providers[provider]||!model)return send(res,{error:'Choisis un fournisseur et un modèle IA.'},400);const scan=HEAL.scanProject(root),errors=ACT.listErrors({status:'open'}),projectName=(getProject(pid)||{}).name||'Projet Astra',prompt=HEAL.buildPrompt({projectName,scan,errors});try{const answer=await providers[provider].chat(settings[provider]||{},model,[{role:'system',content:'Tu es un ingénieur logiciel chargé du diagnostic en lecture seule. Ne modifie aucun fichier et ne prétends pas avoir exécuté des tests.'},{role:'user',content:prompt}],{plain:true});return send(res,{ok:true,answer:String(answer||''),scan,provider,model})}catch(e){ACT.reportError({origin:'Self-Healing · '+provider,message:e.message,context:'Diagnostic du projet '+projectName});return send(res,{error:e.message,scan},502)}}
 if(p==='/api/testing'){if(req.method!=='GET')return send(res,{error:'GET requis.'},405);const pid=cid(u.searchParams.get('project')),root=projectRoot(pid);return send(res,{command:TEST.detectTest(root),reports:TEST.reports(pid),autoAfterChanges:!!settings.autoTestAfterChanges})}
 if(p==='/api/testing/settings'){if(req.method!=='POST')return send(res,{error:'POST requis.'},405);const b=await body(req);settings.autoTestAfterChanges=!!b.autoAfterChanges;S.write('settings.json',settings);return send(res,{ok:true,autoAfterChanges:settings.autoTestAfterChanges})}
 if(p==='/api/testing/run'){if(req.method!=='POST')return send(res,{error:'POST requis.'},405);const b=await body(req),pid=cid(b.project);if(b.confirm!==true)return send(res,{error:'Confirmation requise avant le lancement des tests.'},409);try{const report=await TEST.run({root:projectRoot(pid),project:pid,timeoutMs:Math.min(300000,Math.max(5000,+b.timeoutMs||300000))});ACT.log('testing','Tests du projet : '+report.status,{level:report.status==='passed'?'info':report.status==='no-tests'?'warn':'error',notify:report.status==='failed'||report.status==='timeout'});return send(res,{report,reports:TEST.reports(pid)})}catch(e){ACT.reportError({origin:'Auto Testing',message:e.message,context:'Projet '+pid});return send(res,{error:e.message},500)}}
 if(p==='/api/recovery'){if(req.method==='GET'){const pid=cid(u.searchParams.get('project'));if(!getProject(pid))return send(res,{error:'Projet introuvable.'},404);return send(res,{missions:REC.listMissions(pid),snapshots:REC.listSnapshots(pid)})}if(req.method!=='POST')return send(res,{error:'POST requis.'},405);const b=await body(req),pid=cid(b.project),root=projectRoot(pid);try{if(b.op==='snapshot')return send(res,{snapshot:REC.snapshotProject(root,pid,b.reason||'snapshot manuel')});if(b.op==='restore-snapshot'){if(b.confirm!==true)return send(res,{error:'Confirmation obligatoire pour restaurer un projet.'},409);return send(res,REC.restoreSnapshot(root,pid,b.snapshotId))}if(b.op==='restore-conversation'){const m=REC.getMission(pid,String(b.missionId||''));if(!m)return send(res,{error:'Mission de récupération introuvable.'},404);if(!m.conversation)return send(res,{error:'Aucune conversation associée à cette mission.'},400);const id=cid(m.conversation);cw(pid,id,{history:m.history||[],log:m.log||[]});return send(res,{ok:true,conversation:id,title:m.title,status:m.status})}return send(res,{error:'Opération inconnue.'},400)}catch(e){return send(res,{error:e.message},400)}}
 if(p==='/api/recovery/export'){const pid=cid(u.searchParams.get('project')),root=projectRoot(pid),pr=getProject(pid),name=String(pr?.name||'Astra-project').replace(/[^\w.-]/g,'_').slice(0,60)||'Astra-project',zip=REC.zipProject(root);res.writeHead(200,{'content-type':'application/zip','content-disposition':'attachment; filename="'+name+'.zip"','content-length':zip.length,'x-content-type-options':'nosniff'});return res.end(zip)}
 if(p==='/api/swarm-config'){if(req.method==='GET')return send(res,{agents:settings.swarmAgents||[]});const b=await body(req);if(!Array.isArray(b.agents)||b.agents.length<2||b.agents.length>4)return send(res,{error:'Astra Swarm accepte de 2 à 4 agents.'},400);const clean=b.agents.map((a,i)=>{a=a||{};return{id:'a'+(i+1),name:String(a.name||'Agent '+(i+1)).slice(0,32),role:String(a.role||'Spécialiste').slice(0,60),provider:String(a.provider||''),model:String(a.model||'').slice(0,120)}});if(clean.some(a=>!providers[a.provider]||!a.model.trim()))return send(res,{error:'Chaque agent doit avoir un fournisseur et un modèle valides.'},400);settings.swarmAgents=clean;S.write('settings.json',settings);return send(res,{ok:true,agents:clean})}
 if(p==='/api/swarm-missions'){const pid=cid(u.searchParams.get('project'));const list=S.read('swarm-'+pid+'.json',[]);return send(res,list.slice(0,12).map(SW.safeMission))}
 if(p==='/api/swarm-replay'){const pid=cid(u.searchParams.get('project')),mid=cid(u.searchParams.get('id'));const list=S.read('swarm-'+pid+'.json',[]),mission=list.find(x=>x.id===mid);if(!mission)return send(res,{error:'Mission introuvable.'},404);return send(res,{id:mission.id,title:mission.title,status:mission.status,timeline:SW.replayTimeline(mission)})}
 if(p==='/api/swarm-control'){const b=await body(req),job=swarmJobs[cid(b.id)];if(!job)return send(res,{error:'Mission active introuvable.'},404);const worker=job.workers.find(w=>w.id===b.workerId);if(!worker)return send(res,{error:'Agent introuvable.'},404);if(applyWorkerAction(job,worker,b.action))return send(res,{ok:true});return send(res,{error:'Action impossible pour cet agent.'},400)}
 if(p==='/api/swarm-merge'){const b=await body(req),pid=cid(b.project),list=S.read('swarm-'+pid+'.json',[]),mission=list.find(x=>x.id===cid(b.id));if(!mission)return send(res,{error:'Mission introuvable.'},404);if(mission.integration?.applied?.length)return send(res,{error:'Cette mission contient déjà des changements fusionnés.'},409);try{const result=SW.mergeChanges(projectRoot(pid),mission);mission.integration={...result,at:new Date().toISOString()};mission.status=result.conflicts.length?'completed_with_conflicts':(result.applied.length?'integrated':'review');mission.updatedAt=mission.integration.at;S.write('swarm-'+pid+'.json',list);return send(res,{ok:true,result,mission:SW.safeMission(mission)})}catch(e){return send(res,{error:e.message},400)}}
 // ── Communication Graph · Command Center · Model Intelligence (1.5.5) ──
 if(p==='/api/comm-graph'){const pid=cid(u.searchParams.get('project')),list=S.read('swarm-'+pid+'.json',[]),id=cid(u.searchParams.get('id')),m=id?list.find(x=>x.id===id):list[0];if(!m)return send(res,{error:'Aucune mission enregistrée pour ce projet.'},404);return send(res,{mission:{id:m.id,title:m.title,status:m.status,live:!!swarmJobs[m.id]},graph:COMM.buildGraph(m)})}
 if(p==='/api/cc/overview'){const jobs=Object.values(swarmJobs),ws=jobs.flatMap(j=>j.workers),missions=CC.listMissions(projects,activeIds(),Date.now()),day=Date.now()-864e5;
  const configured=Object.keys(providers).filter(k=>k==='ollama'||k==='local'?!!(settings[k]&&settings[k].url):!!(settings[k]&&settings[k].key));
  return send(res,{version:VERSION,agents:{active:ws.filter(w=>w.status==='working').length,waiting:ws.filter(w=>['queued','assigned','paused','pausing'].includes(w.status)).length,total:ws.length},missions:{active:jobs.length,recent:missions.filter(x=>!x.live&&Date.parse(x.updatedAt)>day).length,total:missions.length},models:{count:configured.length,providers:configured.map(k=>({id:k,label:providers[k].label}))},errors:{open:ACT.openCount()},intelligence:{mode:INT.config().mode}})}
 if(p==='/api/cc/missions')return send(res,{missions:CC.listMissions(projects,activeIds(),Date.now())});
 if(p==='/api/cc/mission-control'){if(req.method!=='POST')return send(res,{error:'POST requis.'},405);const b=await body(req),job=swarmJobs[cid(b.id)];if(!job)return send(res,{error:'Mission active introuvable (elle est peut-être déjà terminée).'},404);
  const act=b.action==='cancel'?'stop':b.action;if(!['pause','resume','stop'].includes(act))return send(res,{error:'Action inconnue.'},400);
  if(b.action==='cancel'&&b.confirm!==true)return send(res,{needConfirm:true,reason:'Annuler la mission arrête tous les agents au prochain point sûr. Les copies isolées sont conservées, mais le travail en cours est perdu.'},409);
  let n=0;for(const w of job.workers)if(applyWorkerAction(job,w,act))n++;
  if(!n)return send(res,{error:'Aucun agent concerné par cette action.'},400);
  ACT.log('swarm','Mission '+({pause:'mise en pause',resume:'reprise',stop:'annulée'}[act])+' depuis le Command Center ('+n+' agent(s))',{mission:job.id,level:act==='stop'?'warn':'info'});return send(res,{ok:true,affected:n})}
 if(p==='/api/cc/mission-report'){const f=CC.findMission(projects,cid(u.searchParams.get('id')));if(!f)return send(res,{error:'Mission introuvable.'},404);const name='astra-mission-'+f.mission.id;
  if(u.searchParams.get('format')==='json')return send(res,{filename:name+'.json',text:JSON.stringify({mission:SW.safeMission(f.mission),graph:COMM.toExport(COMM.buildGraph(f.mission))},null,2)});
  return send(res,{filename:name+'.md',text:CC.missionReport(f.mission,f.project.name)})}
 if(p==='/api/cc/resources')return send(res,await CC.resources({settings,monitor:INT.monitor,dataDir:S.dataDir,force:u.searchParams.get('force')==='1'}));
 if(p==='/api/cc/diagnostics')return send(res,await CC.diagnostics({settings,providers,projects,dataDir:S.dataDir,port:PORT,caps:()=>caps.detect()}));
 if(p==='/api/cc/activity'){const q=u.searchParams;return send(res,ACT.list({since:q.get('since'),source:q.get('source'),level:q.get('level'),mission:q.get('mission'),agent:q.get('agent'),model:q.get('model'),q:q.get('q'),limit:q.get('limit')}))}
 if(p==='/api/cc/errors'){if(req.method==='POST'){const b=await body(req),e=ACT.setStatus(String(b.id||''),String(b.status||''));return e?send(res,{ok:true,error:undefined,item:e}):send(res,{error:'Erreur introuvable ou statut invalide.'},404)}return send(res,{errors:ACT.listErrors({status:u.searchParams.get('status')||undefined}),open:ACT.openCount()})}
 if(p==='/api/cc/workspaces'){const all=CC.listMissions(projects,activeIds(),Date.now());return send(res,{workspaces:projects.map(pr=>{const ms=all.filter(m=>m.project===pr.id);let exists=true;try{exists=pr.root?fs.existsSync(pr.root):true}catch{}return{id:pr.id,name:pr.name,root:pr.root||'',storage:pr.root?'dossier local':'stockage Astra',exists,missions:ms.length,active:ms.filter(m=>m.live).length,last:ms[0]?{id:ms[0].id,title:ms[0].title,status:ms[0].status,at:ms[0].updatedAt}:null}})})}
 if(p==='/api/intelligence'){if(req.method==='POST')return send(res,{error:'Utilise /api/intelligence/settings pour modifier les réglages.'},405);return send(res,await INT.snapshot(u.searchParams.get('refresh')==='1'))}
 if(p==='/api/intelligence/settings'){if(req.method!=='POST')return send(res,{error:'POST requis.'},405);const b=await body(req);settings.intelligence=Intel.sanitize(b||{},settings.intelligence);S.write('settings.json',settings);INT.registry.invalidate();return send(res,{ok:true,config:INT.config()})}
 if(p==='/api/intelligence/analyze'){if(req.method!=='POST')return send(res,{error:'POST requis.'},405);const b=await body(req);return send(res,{task:INT.analyzer.analyze({text:String(b.message||'').slice(0,20000),files:Array.isArray(b.files)?b.files.slice(0,50):[],images:b.images|0,priority:b.priority})})}
 if(p==='/api/intelligence/route'){if(req.method!=='POST')return send(res,{error:'POST requis.'},405);const b=await body(req);return send(res,await INT.route({text:String(b.message||'').slice(0,20000),files:Array.isArray(b.files)?b.files.slice(0,50):[],images:b.images|0,priority:b.priority},b.provider&&b.model?{provider:String(b.provider),model:String(b.model)}:null))}
 if(p==='/api/intelligence/benchmark'){if(req.method!=='POST')return send(res,{error:'POST requis.'},405);const b=await body(req),ids=(Array.isArray(b.models)?b.models:[]).map(String).slice(0,6);if(!ids.length)return send(res,{error:'Choisis au moins un modèle.'},400);
  const total=ids.length*INT.bench.TASKS.length;if(b.confirm!==true)return send(res,{needConfirm:true,requests:total,reason:'Le benchmark envoie '+total+' requêtes réelles ('+INT.bench.TASKS.length+' par modèle). Les modèles cloud peuvent être facturés par ton fournisseur.'},409);
  res.writeHead(200,{'content-type':'text/event-stream','cache-control':'no-cache','connection':'keep-alive'});const ac=new AbortController();res.on('close',()=>ac.abort());
  const ev=(type,d)=>{if(!res.writableEnded&&!res.destroyed)res.write('data: '+JSON.stringify({type,...d})+'\n\n')};
  try{ACT.log('model','Benchmark lancé : '+ids.join(', '));const r=await INT.runBenchmark(ids,{signal:ac.signal,onProgress:(e,row)=>ev('progress',{model:e.id,task:row.taskId,title:row.title,ok:row.ok,score:row.score,ms:row.ms,error:row.error})});ev('done',{results:r});ACT.log('model','Benchmark terminé')}catch(e){ev('error',{text:e.message});ACT.reportError({origin:'Benchmark',message:e.message})}
  return res.end()}
 if(p==='/api/council'){
  if(req.method!=='POST')return send(res,{error:'POST requis.'},405);
  const b=await body(req),pid=cid(b.project);if(!getProject(pid))return send(res,{error:'Projet introuvable.'},404);
  const ac=new AbortController();res.on('close',()=>ac.abort());
  try{const result=await Council.run({message:b.message,agents:b.agents,coordinator:b.coordinator,signal:ac.signal});result.project=pid;const list=S.read('council-'+pid+'.json',[]);list.unshift(result);S.write('council-'+pid+'.json',list.slice(0,20));return send(res,{ok:true,result});}
  catch(e){return send(res,{error:e.message},400)}
 }
 if(p==='/api/council-history'){const pid=cid(u.searchParams.get('project'));return send(res,S.read('council-'+pid+'.json',[]).map(x=>({id:x.id,at:x.at,message:x.message,final:x.final,members:(x.members||[]).map(m=>({name:m.name,provider:m.provider,model:m.model,answer:m.answer}))})).slice(0,20))}
 if(p==='/api/time-machine'){
  if(req.method!=='GET'&&req.method!=='POST')return send(res,{error:'GET ou POST requis.'},405);
  const b=req.method==='POST'?await body(req):null,pid=cid(req.method==='POST'?b.project:u.searchParams.get('project'));if(!getProject(pid))return send(res,{error:'Projet introuvable.'},404);
  if(req.method==='GET')return send(res,{snapshots:TimeMachine.list(pid)});
  const root=projectRoot(pid);
  try{
   if(b.action==='snapshot')return send(res,{ok:true,snapshot:TimeMachine.snapshot(pid,root,b.label||'Checkpoint manuel')});
   if(b.action==='restore'){if(b.confirm!==true)return send(res,{needConfirm:true,error:'Confirme explicitement la restauration.'},409);return send(res,TimeMachine.restore(pid,root,String(b.id||''),{confirm:true}));}
   if(b.action==='delete'){if(!TimeMachine.remove(pid,String(b.id||'')))return send(res,{error:'Snapshot introuvable.'},404);return send(res,{ok:true});}
   return send(res,{error:'Action inconnue.'},400);
  }catch(e){return send(res,{error:e.message},400)}
 }
 if(p==='/api/intelligence/ask'){if(req.method!=='POST')return send(res,{error:'POST requis.'},405);const b=await body(req),msg=String(b.message||'').trim().slice(0,8000);if(!msg)return send(res,{error:'Écris une question.'},400);
  const cfg=INT.config(),rt=await INT.route({text:msg}),picked=b.choose?rt.ranking.find(x=>x.id===String(b.choose)):null,first=picked?{provider:picked.provider,model:picked.model,id:picked.id}:rt.chosen;
  if(!first)return send(res,{needsUserChoice:true,route:rt,error:rt.recommended?'Mode hybride : choisis le modèle (la recommandation est proposée).':rt.explanation},409);
  const cands=[first,...(cfg.fallback?await INT.candidates({text:msg},first.id,2):[])];
  try{const r=await INT.fallback.runWithFallback(cands,c=>providers[c.provider].chat(settings[c.provider]||{},c.model,[{role:'user',content:msg}],{plain:true}),{idempotent:true,onAttempt:a=>{if(!a.ok)INT.monitor.logIncident({summary:a.id+' a échoué ('+a.kind+')',attempts:1})}});
   return send(res,{answer:String(r.result||''),used:r.used,fellBack:r.fellBack,attempts:r.attempts,explanation:rt.explanation})}
  catch(e){return send(res,{error:e.message,attempts:e.attempts||[]},502)}}
 if(p==='/api/projects/create'){
  const b=await body(req);const name=String(b.name||'').trim();
  if(!name)return send(res,{error:'Nom du projet requis.'},400);
  if(/[\\/:*?"<>|]/.test(name)||name==='.'||name==='..')return send(res,{error:'Nom de projet invalide.'},400);
  const home=process.env.USERPROFILE||process.env.HOME||process.cwd();
  const desktop=path.join(home,'Desktop');
  const parent=fs.existsSync(desktop)&&fs.statSync(desktop).isDirectory()?desktop:home;
  const rr=path.resolve(parent,name);
  if(fs.existsSync(rr))return send(res,{error:'Un dossier portant ce nom existe déjà sur le Desktop.'},400);
  fs.mkdirSync(rr,{recursive:true});
  const checkedRoot=pathGuard.canonicalProjectRoot(rr);
  const pr={id:Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,6),name,root:checkedRoot};
  projects.push(pr);S.write('projects.json',projects);return send(res,pr)
 }
 if(p==='/api/projects'){if(req.method!=='POST')return send(res,{error:'POST requis.'},405);const b=await body(req);const rawRoot=String(b.root||'').trim();if(rawRoot){let rr;try{rr=pathGuard.canonicalProjectRoot(rawRoot)}catch(e){return send(res,{error:e.message},400)}const existing=projects.find(x=>x.root&&pathGuard.samePath(path.resolve(x.root),rr));if(existing)return send(res,{...existing,reused:true});const pr={id:Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,6),name:b.name||path.basename(rr)||'Projet local',root:rr};projects.push(pr);S.write('projects.json',projects);return send(res,pr)}const pr={id:Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,6),name:b.name||'Nouveau projet'};projects.push(pr);S.write('projects.json',projects);S.projDir(pr.id);return send(res,pr)}
 if(p==='/api/local-picker'){try{const kind=u.searchParams.get('kind')==='file'?'file':'folder';const selected=await runPicker(kind);return send(res,{path:selected,cancelled:!selected})}catch(e){return send(res,{error:e.message},400)}}
 if(p==='/api/files'){const f=u.searchParams.get('f');
  if(req.method==='GET'){const r=projectRoot(cid(u.searchParams.get('id')));if(f){try{return send(res,{text:fs.readFileSync(safe(r,f),'utf8')})}catch(e){return send(res,{text:'Erreur : '+e.message})}}return send(res,{files:walk(r,r)})}
  const b=await body(req),r=projectRoot(cid(b.project));try{if(b.op==='save'){const q=safe(r,b.path);if(path.basename(q)==='.kairo'||q.includes(path.sep+'.kairo'+path.sep))throw new Error('Zone interne refusée');fs.mkdirSync(path.dirname(q),{recursive:true});const before=fs.existsSync(q)?fs.readFileSync(q,'utf8'):'';fs.writeFileSync(q,String(b.text??''));return send(res,{ok:true,change:require('./tools').briefDiff(b.path,before,String(b.text??''))})}
   if(b.op==='mkdir'){const q=safe(r,b.path);fs.mkdirSync(q,{recursive:true});return send(res,{ok:true})}
   if(b.op==='rename'||b.op==='move'){const from=safe(r,b.path),to=safe(r,b.to);if(from===r||to===r)throw new Error('Opération racine refusée');fs.mkdirSync(path.dirname(to),{recursive:true});fs.renameSync(from,to);return send(res,{ok:true})}
   if(b.op==='delete'){const q=safe(r,b.path);if(q===r)throw new Error('Suppression du projet interdite');fs.rmSync(q,{recursive:true});return send(res,{ok:true})}
   return send(res,{error:'opération inconnue'},400)}catch(e){return send(res,{error:e.message},400)}}
 if(p==='/api/restore'){const b=await body(req),r=projectRoot(cid(b.project));try{const id=path.basename(String(b.changeId||''));if(!/^[a-z0-9-]+$/.test(id))throw new Error('changement invalide');const bp=safe(r,path.join('.kairo','backups',id+'.json'));const rec=JSON.parse(fs.readFileSync(bp,'utf8'));const q=safe(r,rec.path);if(rec.existedBefore===false){if(fs.existsSync(q))fs.rmSync(q,{recursive:true});}else{fs.mkdirSync(path.dirname(q),{recursive:true});fs.writeFileSync(q,rec.before);}return send(res,{ok:true,path:rec.path})}catch(e){return send(res,{error:e.message},400)}}
 if(p==='/api/memory'){const id=cid(u.searchParams.get('id'));
  if(req.method==='GET')return send(res,{...mem(id),conversation:cv(cid(id),cid(u.searchParams.get('conv'))).history,prefs:prefs()});
  const b=await body(req);
  if(req.method==='POST'){if(b.kind==='prefs'){const a=prefs();a.push({text:b.text});S.write('prefs.json',a)}else{const m=mem(id);m[b.kind].push({text:b.text});S.write('mem-'+id+'.json',m)}}
  if(req.method==='DELETE'){if(b.kind==='conversation'){const c=cv(cid(id),cid(b.conv));c.history.splice(b.i,1);cw(cid(id),cid(b.conv),c)}else if(b.kind==='prefs'){const a=prefs();a.splice(b.i,1);S.write('prefs.json',a)}else{const m=mem(id);m[b.kind].splice(b.i,1);S.write('mem-'+id+'.json',m)}}
  return send(res,{ok:true})}
 if(p==='/api/mcp'){if(req.method==='GET')return send(res,Object.values(mcp).map(s=>s.info()));
  const b=await body(req);
  if(b.op==='add'){settings.mcp=[...(settings.mcp||[]),{name:b.name,command:b.command,args:(b.args||'').split(' ').filter(Boolean),env:Object.fromEntries((b.env||'').split('|').filter(x=>x.includes('=')).map(x=>[x.slice(0,x.indexOf('=')),x.slice(x.indexOf('=')+1)]))}];S.write('settings.json',settings);mcp[b.name]=new McpServer(settings.mcp.at(-1))}
  if(b.op==='start')await mcp[b.name]?.start();
  if(b.op==='stop')mcp[b.name]?.stop();
  if(b.op==='remove'){mcp[b.name]?.stop();delete mcp[b.name];settings.mcp=(settings.mcp||[]).filter(c=>c.name!==b.name);S.write('settings.json',settings)}
  return send(res,{ok:true})}
 if(p==='/api/exec'){if(req.method!=='POST')return send(res,{error:'POST requis.'},405);const b=await body(req),lines=[],root=projectRoot(b.project);
  const cls=require('./perms').classifyCommand(String(b.command||''),root,{});
  if(cls.level==='DANGER')return send(res,{error:'Commande bloquée (DANGER) : '+(cls.reason||'action jugée dangereuse')},403);
  if(cls.level==='CONFIRM'&&b.confirm!==true)return send(res,{needConfirm:true,reason:cls.reason||'confirmation requise',lines:[]},409);
  await require('./tools').tools.run_command.run({command:b.command},{root,emit:(_,d)=>lines.push(d)}).catch(()=>{});return send(res,{lines})}
 if(p==='/api/convs'){const pid=cid(u.searchParams.get('project'));if(req.method==='GET')return send(res,lst(pid));
  const b=await body(req);if(b.op==='forget'){EPH.delete(pid+':'+cid(b.id));return send(res,{ok:true})}let l=lst(pid);
  if(b.op==='delete'){l=l.filter(c=>c.id!==b.id);try{fs.unlinkSync(path.join(__dirname,'..','data','conv-'+pid+'-'+cid(b.id)+'.json'))}catch{}}
  else if(b.op==='rename'){const c=l.find(c=>c.id===b.id);if(c)c.title=String(b.title||c.title).slice(0,60)}
  else{const c={id:Date.now().toString(36),title:'Nouvelle discussion',ts:Date.now()};l.unshift(c);cw(pid,c.id,{history:[],log:[]});S.write('convs-'+pid+'.json',l);return send(res,c)}
  S.write('convs-'+pid+'.json',l);return send(res,{ok:true})}
 if(p==='/api/conv')return send(res,cv(cid(u.searchParams.get('project')),cid(u.searchParams.get('id'))));
 if(p==='/api/upload'){const b=await body(req),root=projectRoot(b.project),n=path.basename(b.name||'fichier'),target=safe(root,path.join('uploads',n)),d=safe(root,'uploads'),data=Buffer.from(String(b.data||''),'base64');if(data.length>8*1024*1024)return send(res,{error:'Fichier trop volumineux (limite 8 Mo).'},413);fs.mkdirSync(d,{recursive:true});fs.writeFileSync(target,data,{flag:'w'});return send(res,{path:'uploads/'+n,mime:String(b.mime||'application/octet-stream').slice(0,120)})}
 if(p==='/api/vision'){const b=await body(req);settings.vision=b.prov&&b.model?{prov:b.prov,model:b.model}:null;settings.visionMode=b.mode==='lite'?'lite':'auto';S.write('settings.json',settings);return send(res,{ok:true})}
 if(p==='/api/env'){const pid=cid(u.searchParams.get('project'));if(req.method==='GET')return send(res,{...await E.list(pid),auto:settings.autoShot||'important'});
  const b=await body(req),id=cid(b.project||pid);try{if(b.op==='start')await E.start(id,b.driver,projectRoot(id));else if(b.op==='stop')await E.stop(id);else if(b.op==='auto'){settings.autoShot=b.mode;S.write('settings.json',settings)}
   else if(b.op==='capture'){const e=E.get(id);if(!e)throw new Error('Aucun environnement actif');const s=await e.capture(b.url?{url:b.url}:{});return send(res,{shot:{name:s.name,url:s.url,w:s.w,h:s.h}})}}catch(e){return send(res,{error:e.message})}return send(res,{ok:true})}
 if(p==='/api/env/live'){const e=E.get(cid(u.searchParams.get('project')));if(!e){res.writeHead(409);return res.end('aucun environnement actif')}try{const b=await e.raw();res.writeHead(200,{'content-type':'image/png','cache-control':'no-store'});return res.end(b)}catch(er){res.writeHead(500);return res.end(er.message)}}
 if(p==='/api/shot'){const f=path.join(E.shots(cid(u.searchParams.get('project'))),path.basename(u.searchParams.get('name')||''));if(!fs.existsSync(f)||!f.endsWith('.png')){res.writeHead(404);return res.end()}res.writeHead(200,{'content-type':'image/png'});return fs.createReadStream(f).pipe(res)}
 if(p==='/api/caps')return send(res,{tools:await caps.detect(u.searchParams.get('force')==='1'),text:caps.describe(await caps.detect())});
 if(p==='/api/grants'){if(req.method==='GET')return send(res,{grants:settings.grants?.[cid(u.searchParams.get('project'))]||{}});const b=await body(req),g=b.grants||{};settings.grants={...settings.grants,[cid(b.project)]:{dev:!!g.dev,system:!!g.system,network:!!g.network}};S.write('settings.json',settings);return send(res,{ok:true})}
 if(p==='/api/profile'){if(req.method!=='POST')return send(res,{error:'POST requis.'},405);const b=await body(req);
  if(b.skip){settings.profile={...settings.profile,skipped:true}}
  else{const name=String(b.name??'').replace(/[^\p{L}\p{M}' .-]/gu,'').replace(/\s+/g,' ').trim().slice(0,40);settings.profile=name?{name}:{skipped:!!settings.profile?.skipped}}
  S.write('settings.json',settings);return send(res,{ok:true,profile:settings.profile})}
 if(p==='/api/ui'){const b=await body(req);if(['system','light','dark','night'].includes(b.theme)){settings.ui={...settings.ui,theme:b.theme};S.write('settings.json',settings)}return send(res,{ok:true,ui:settings.ui||{}})}
 if(p==='/api/image-settings'){const b=await body(req);settings.imageMode=b.mode==='numeric'?'numeric':'auto';settings.imageSize=['16','32','64','128'].includes(String(b.size))?+b.size:'auto';settings.imageEncoding=['palette','rle','hex12','hex','json'].includes(b.encoding)?b.encoding:'auto';settings.imageNormalize=b.normalize==='float'?'float':'int';settings.imageMatrix=!!b.matrix;S.write('settings.json',settings);return send(res,{ok:true})}
 if(p==='/api/tools'){const T=require('./tools').tools,M=require('./extratools').META,list=Object.entries(T).map(([name,t])=>{const m=M[name]||[name.startsWith('gui_')?'Écran':'Autres',t.perm||'CONFIRM'];return{name,desc:String(t.desc||'').split(/ args:/)[0],args:(String(t.desc||'').match(/ args:(.*)$/)||[])[1]||'',cat:m[0],level:m[1]}}).sort((x,y)=>x.cat.localeCompare(y.cat,'fr')||x.name.localeCompare(y.name));return send(res,{tools:list,version:require('../package.json').version})}
 if(p==='/api/image-convert'){const b=await body(req);try{let buf;if(b.data)buf=Buffer.from(String(b.data).replace(/^data:[^,]*,/,''),'base64');else buf=fs.readFileSync(safe(projectRoot(b.project),b.path));const r=await imagecodec.prepare(buf,{name:b.path||b.name||'image',size:b.size,encoding:b.encoding,normalize:b.normalize,matrix:!!b.matrix,alpha:b.alpha,lite:b.lite!==false,maxChars:b.maxChars||6000});return send(res,{ok:true,meta:r.meta,analysis:r.analysis,text:r.text,rep:r.rep,json:b.format==='json'?r.json():undefined})}catch(e){return send(res,{ok:false,code:e.code||'ERROR',error:e.message},e.code?422:500)}}
 if(p==='/api/approve'){const b=await body(req);const fn=pend[b.id];if(fn){delete pend[b.id];fn(!!b.ok)}return send(res,{ok:true})}
 if(p==='/api/loop'){const b=await body(req);const fn=loopPend[b.id];if(fn){delete loopPend[b.id];fn(b.decision==='skip'?'skip':'stop')}return send(res,{ok:true})}
  if(p==='/api/swarm/run'){
  const b=await body(req),pid=cid(b.project),root=projectRoot(pid);
  const rawAgents=Array.isArray(b.agents)?b.agents:settings.swarmAgents||[];
  if(rawAgents.length<2||rawAgents.length>4)return send(res,{error:'Configure entre 2 et 4 agents avant de lancer Astra Swarm.'},400);
  const agents=rawAgents.map((a,i)=>{a=a||{};return{id:'a'+(i+1),name:String(a.name||'Agent '+(i+1)).slice(0,32),role:String(a.role||'Spécialiste').slice(0,60),provider:String(a.provider||''),model:String(a.model||'').slice(0,120)}});
  if(!String(b.message||'').trim())return send(res,{error:'Décris la mission à réaliser.'},400);
  if(agents.some(a=>!providers[a.provider]||!a.model.trim()))return send(res,{error:'Chaque agent doit avoir un fournisseur et un modèle.'},400);
  const coordinator=(providers[b.coordinator?.provider]&&String(b.coordinator?.model||'').trim())?{provider:b.coordinator.provider,model:String(b.coordinator.model)}:{provider:agents[0].provider,model:agents[0].model};
  const id=Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,7),now=new Date().toISOString();
  res.writeHead(200,{'content-type':'text/event-stream','cache-control':'no-cache','connection':'keep-alive','x-accel-buffering':'no'});
  const sendEvent=(type,data={})=>{if(!res.writableEnded&&!res.destroyed)res.write('data: '+JSON.stringify({type,...data})+'\n\n')};
  const missionDir=path.join(S.dataDir,'swarm-workspaces',pid,id);
  const mission={id,project:pid,title:String(b.message).trim().slice(0,100),status:'preparing',createdAt:now,updatedAt:now,coordinator,plan:[],review:'',warnings:[],changes:[],events:[],workers:agents.map(a=>({...a,status:'queued',task:'',lastAction:'En attente',events:[],changes:[]})),baseline:{},workspaceRoot:missionDir};
  const persist=()=>{mission.updatedAt=new Date().toISOString();const list=S.read('swarm-'+pid+'.json',[]),copy={...mission,workers:mission.workers.map(({controller,paused,...w})=>w)};const old=list.findIndex(x=>x.id===id);if(old>=0)list[old]=copy;else list.unshift(copy);S.write('swarm-'+pid+'.json',list.slice(0,8))};
  const push=(type,data={})=>{const ev={at:new Date().toISOString(),type,...Object.fromEntries(Object.entries(data).filter(([k])=>k!=='mission'))};mission.events.push(ev);if(mission.events.length>300)mission.events.shift();try{swarmAct(mission,type,data)}catch{}sendEvent(type,data)};
  const job={...mission,push,persist};swarmJobs[id]=job;
  const parseObject=raw=>{const t=String(raw||'').replace(/```(?:json)?/gi,'');const a=t.indexOf('{'),z=t.lastIndexOf('}');if(a<0||z<a)return null;try{return JSON.parse(t.slice(a,z+1))}catch{return null}};
  const contextOf=baseline=>{
   const names=Object.keys(baseline),preferred=names.filter(x=>/^(README|package\.json|pyproject\.toml|Cargo\.toml|CMakeLists\.txt|\.\w+\.md)/i.test(x)||/^(src|server|app|public)\//i.test(x));
   let out='Project files:\n'+names.slice(0,180).join('\n');
   for(const file of [...preferred,...names].filter((x,i,a)=>a.indexOf(x)===i).slice(0,12))try{const text=fs.readFileSync(safe(root,file),'utf8');if(!text.includes('\0'))out+='\n\n--- '+file+' ---\n'+text.slice(0,3200)}catch{}
   return out.slice(0,26000);
  };
  const coordChat=async messages=>{
   const call=(prov,model)=>providers[prov].chat(settings[prov]||{},model,messages,{});
   if(b.requireCoordinator||!INT.config().fallback)return call(coordinator.provider,coordinator.model);
   try{return await call(coordinator.provider,coordinator.model)}catch(first){
    const cands=await INT.candidates({text:b.message},coordinator.provider+'/'+coordinator.model,3).catch(()=>[]);
    if(!cands.length)throw first;
    const r=await INT.fallback.runWithFallback(cands,c=>call(c.provider,c.model),{idempotent:true}).catch(e=>{throw Object.assign(first,{message:first.message+' (reprise impossible : '+e.message+')'})});
    const text='« '+coordinator.provider+'/'+coordinator.model+' » indisponible ('+String(first.message).slice(0,120)+') → repli sur '+r.used.id;
    INT.monitor.logIncident({summary:text,attempts:r.attempts.length});push('fallback',{text});return r.result;
   }
  };
  const runMission=async()=>{
   try{
    fs.mkdirSync(missionDir,{recursive:true});
    const staging=path.join(missionDir,'_source_snapshot');
    const snap=SW.copyWorkspace(root,staging);mission.baseline=snap.baseline;mission.warnings=snap.warnings;
    mission.copyStats={files:snap.count,bytes:snap.totalBytes};
    const ctx=contextOf(snap.baseline);
    for(const w of mission.workers){w.workspace=path.join(missionDir,w.id);fs.cpSync(staging,w.workspace,{recursive:true});}
    fs.rmSync(staging,{recursive:true,force:true});
    mission.status='planning';push('mission',{mission:SW.safeMission(mission),copyStats:mission.copyStats});
    const P=providers[coordinator.provider];let planData=null,planError='';
    try{
     const prompt='You are the coordinator of Astra Swarm. Decompose the user mission into exactly '+agents.length+' independent, non-overlapping development tasks. Use the assigned agents and their roles. Avoid assigning the same files to different agents where possible. Return ONLY JSON: {"plan":["..."],"tasks":[{"agentId":"a1","task":"..."}]}. Tasks must be concrete, scoped, and useful. Do not claim work is done.';
     const raw=await coordChat([{role:'system',content:prompt},{role:'user',content:'MISSION:\n'+b.message+'\n\nAGENTS:\n'+agents.map(a=>`${a.id}: ${a.name} — ${a.role}`).join('\n')+'\n\nPROJECT CONTEXT:\n'+ctx}]);
     planData=parseObject(raw);if(!planData||!Array.isArray(planData.tasks))throw new Error('Le coordinateur n’a pas renvoyé un plan JSON exploitable.');
    }catch(e){planError=e.message;}
    if(planError&&b.requireCoordinator)throw new Error('Coordinateur Meta AI indisponible : '+planError);
    const defaultTasks=[
     'Étudier l’architecture et réaliser la partie de fondation la plus pertinente pour la mission. Éviter de modifier les mêmes fichiers que les autres agents.',
     'Réaliser une partie fonctionnelle et autonome de la mission dans les fichiers du projet. Éviter les fichiers pris par les autres agents.',
     'Ajouter ou renforcer les tests, contrôler les cas limites et corriger les problèmes isolés liés à la mission.',
     'Examiner la cohérence globale, compléter la documentation ou les vérifications nécessaires sans écraser le travail des autres.'
    ];
    mission.plan=Array.isArray(planData?.plan)?planData.plan.slice(0,8).map(String):agents.map(a=>a.role);
    for(let i=0;i<mission.workers.length;i++){
     const w=mission.workers[i],assigned=planData?.tasks?.find(t=>String(t.agentId||'')===w.id)||planData?.tasks?.[i];
     w.task=String(assigned?.task||defaultTasks[i]||('Traiter la partie spécialisée « '+w.role+' » de la mission.')).slice(0,1800);
     w.status='assigned';w.lastAction='Tâche attribuée';
    }
    push('plan',{plan:mission.plan,workers:mission.workers.map(w=>({id:w.id,name:w.name,role:w.role,task:w.task})),...(planError?{fallback:planError}:{})});persist();
    const workerRuns=mission.workers.map(async w=>{
     const controller=new AbortController();w.controller=controller;w.paused=false;w.status='working';w.startedAt=new Date().toISOString();w.lastAction='Démarrage';
     push('worker',{workerId:w.id,status:w.status,lastAction:w.lastAction});persist();
     const addLog=(type,data={})=>{
      if(type==='error')w.lastError=String(data.text||'Erreur agent').slice(0,500);
      let message='';
      if(type==='status')message=String(data.s||'');
      else if(type==='tool')message='Outil : '+String(data.name||'action')+(data.args?.path?' · '+String(data.args.path):data.args?.command?' · '+String(data.args.command).slice(0,70):'');
      else if(type==='result')message=(data.ok?'Terminé : ':'Échec : ')+String(data.text||'').slice(0,220);
      else if(type==='say'||type==='decision'||type==='final'||type==='error')message=String(data.text||'').slice(0,260);
      else if(type==='plan')message='Plan interne mis à jour';
      else if(type==='diff')message='Fichier modifié : '+String(data.path||data.diff?.file||'');
      else if(type==='term')message=String(data.text||'').slice(0,180);
      if(!message)return;
      w.lastAction=message;const ev={at:new Date().toISOString(),type,message};w.events.push(ev);if(w.events.length>100)w.events.shift();if(w.events.length%6===0)persist();
      push('worker-event',{workerId:w.id,event:ev});
     };
     const waitIfPaused=()=>new Promise(resolve=>{const check=()=>{if(controller.signal.aborted||!w.paused)return resolve();if(w.status!=='paused'){w.status='paused';w.lastAction='En pause au point de contrôle';push('worker',{workerId:w.id,status:w.status,lastAction:w.lastAction});persist()}setTimeout(check,250)};check()});
     try{
      const final=await agent.run({prov:w.provider,model:w.model,settings,msg:'MISSION GLOBALE : '+b.message+'\n\nTON RÔLE : '+w.role+'\nTA SOUS-TÂCHE : '+w.task+'\n\nTu travailles dans une copie isolée du projet. Réalise uniquement ta sous-tâche, évite les modifications sans rapport et ne tente pas de communiquer directement avec le système hôte. Les fichiers seront comparés et un reviewer examinera les changements avant toute fusion dans le projet principal. Tu peux lire, créer et modifier les fichiers de cette copie et lancer des commandes de développement sûres. Les actions nécessitant des droits supplémentaires, le réseau, le système et les suppressions non sûres seront refusés. Réponds en français.',images:[],history:[],root:w.workspace,mem:{project:[],prefs:[]},mcp:[],emit:addLog,ask:async()=>false,askLoop:async()=>'stop',signal:controller.signal,env:null,autoShot:'off',grants:{},created:new Set(),drivers:[],waitIfPaused});
      if(final)w.result=String(final).slice(0,1800);
      w.status=controller.signal.aborted?'stopped':(!final&&w.lastError?'failed':'completed');
     }catch(e){w.status=controller.signal.aborted?'stopped':'failed';w.result=e.message;addLog('error',{text:e.message});}
     w.finishedAt=new Date().toISOString();w.paused=false;delete w.controller;
     w.changes=SW.collectChanges(w.workspace,mission.baseline,w.id);
     push('worker',{workerId:w.id,status:w.status,lastAction:w.lastAction,result:w.result||'',changes:w.changes.length});persist();
    });
    await Promise.all(workerRuns);
    mission.status='reviewing';push('review-start',{text:'Le reviewer indépendant examine les résultats et les conflits possibles.'});
    mission.changes=[];
    for(const w of mission.workers){const preview=SW.summarizeChanges(w.changes,w.workspace);w.changes=preview;mission.changes.push(...preview);}
    const reviewInput=mission.changes.slice(0,50).map(c=>({worker:c.workerId,path:c.path,type:c.type,preview:c.preview?.slice(0,500)||'(contenu non textuel)'}));
    try{
     const review=await coordChat([{role:'system',content:'Tu es le reviewer indépendant d’Astra Swarm. Évalue les modifications proposées sans exécuter ni modifier de fichiers. Repère les doublons, conflits, risques, manque de tests et incohérences. Réponds en français avec une conclusion et des recommandations précises. Ne dis pas que le code a été exécuté si tu ne l’as pas vérifié.'},{role:'user',content:'MISSION : '+b.message+'\n\nRÉSULTATS DES AGENTS :\n'+mission.workers.map(w=>w.name+' ('+w.status+') : '+(w.result||'aucun rapport')).join('\n')+'\n\nCHANGEMENTS PROPOSÉS :\n'+JSON.stringify(reviewInput).slice(0,24000)}]);
     mission.review=String(review||'Le reviewer n’a pas fourni de commentaire.').slice(0,7000);
    }catch(e){mission.review='Revue automatique indisponible : '+e.message+'. Les changements restent isolés et doivent être examinés manuellement.';if(b.requireCoordinator)throw new Error('Revue Meta AI indisponible : '+e.message);}
    const byPath=new Map();for(const c of mission.changes){if(!byPath.has(c.path))byPath.set(c.path,[]);byPath.get(c.path).push(c)}
    mission.conflicts=[...byPath.entries()].filter(([,xs])=>new Set(xs.map(x=>x.afterHash)).size>1).map(([file])=>file);
    mission.status=mission.workers.some(w=>w.status==='failed')?'completed_with_errors':'ready_for_review';
    push('complete',{mission:SW.safeMission(mission),conflicts:mission.conflicts||[]});persist();
   }catch(e){mission.status='failed';mission.review='Mission interrompue : '+e.message;push('error',{text:e.message});persist();}
   finally{delete swarmJobs[id];if(!res.writableEnded&&!res.destroyed)res.end();}
  };
  runMission().catch(e=>{push('error',{text:e.message});persist();if(!res.writableEnded&&!res.destroyed)res.end();delete swarmJobs[id]});
  return;
 }
 if(p==='/api/chat'){const b=await body(req);res.writeHead(200,{'content-type':'text/event-stream','cache-control':'no-cache'});
  const emit=(t,d)=>{if(!res.writableEnded&&!res.destroyed)res.write('data: '+JSON.stringify({t,...d})+'\n\n')};const ac=new AbortController();res.on('close',()=>ac.abort());
  if(INT.config().mode==='auto'){try{const rt=await INT.route({text:b.message,files:(b.files||[]).map(f=>({path:f.path,name:f.path}))});if(rt.recommended){b.provider=rt.recommended.provider;b.model=rt.recommended.model;emit('route',{id:rt.recommended.id,explanation:rt.explanation})}else emit('route',{error:rt.explanation+' Le modèle choisi dans l’en-tête est conservé.'})}catch(e){emit('route',{error:'Routage automatique indisponible : '+e.message+'. Le modèle choisi dans l’en-tête est conservé.'})}}
  const eph=!!b.ephemeral,pid=cid(b.project);let cvv=cid(b.conv);let l=eph?[]:lst(pid);
  if(eph){if(!/^tmp-/.test(cvv))cvv='tmp-'+Date.now().toString(36)+Math.random().toString(36).slice(2,5)}
  else if(!cvv||!l.find(c=>c.id===cvv)){cvv=Date.now().toString(36);l.unshift({id:cvv,title:'Nouvelle discussion',ts:Date.now()});S.write('convs-'+pid+'.json',l);emit('conv',{id:cvv})}
  const C=eph?(EPH.get(pid+':'+cvv)||{history:[],log:[]}):cv(pid,cvv),m=eph?(m0=>({...m0,project:[...(m0.project||[])],actions:[]}))(mem(pid)):mem(pid);m.prefs=prefs();let recoveryId=null;const actionStart=m.actions.length;
  const root=projectRoot(pid);let msg=b.message||'',images=[];
  const imgEvents=[];let seeN;const seeNative=async()=>seeN!==undefined?seeN:(seeN=await Promise.resolve(providers[b.provider]?.vision?.(settings[b.provider]||{},b.model)).catch(()=>false));
  const imgBudget=b.provider==='ollama'||b.provider==='local'?Math.round((settings[b.provider]?.ctx||8192)*0.22*3.2):16000;
  for(const f of b.files||[]){try{const buf=fs.readFileSync(safe(root,f.path));const sn=imagecodec.sniff(buf);if((f.mime||'').startsWith('image/')||sn){
    try{const r=await imagecodec.resolve({buf,name:f.path,mime:f.mime||sn?.mime},{canSee:await seeNative(),settings,mode:settings.imageMode||'auto',budget:imgBudget,describe:async im=>await providers[settings.vision.prov].chat(settings[settings.vision.prov]||{},settings.vision.model,[{role:'user',content:'Décris précisément cette image : contenu, couleurs, textes lisibles, disposition.',images:[{mime:im.mime,b64:im.buf.toString('base64')}]}],{plain:true,signal:ac.signal})});
     if(r.images)images.push(...r.images);if(r.text)msg+='\n\n'+r.text;const mt=r.info?.meta,an=r.info?.analysis;
     imgEvents.push({t:'image',name:f.path,mode:r.info?.mode||r.id,...(mt?{format:mt.format,ow:mt.original.width,oh:mt.original.height,aw:an.width,ah:an.height,encoding:an.encoding,colors:an.colors,chars:an.chars,tokens:an.approxTokens,via:mt.decodedVia,text:r.text}:{})})}
    catch(e){msg+='\n\n[Image « '+f.path+' » non exploitable : '+e.message+']';imgEvents.push({t:'image',name:f.path,mode:'erreur',error:e.message,code:e.code})}}
   else if(/\.(txt|md|json|gd|py|js|ts|cs|cfg|csv|html|css|tscn|yml|yaml|xml|log|sh|bat)$/i.test(f.path))msg+='\n\n[Contenu de '+f.path+']\n'+buf.toString('utf8').slice(0,6000)}catch{}}
  if((b.files||[]).length)msg+='\n\n[Fichiers joints dans le projet : '+b.files.map(f=>f.path).join(', ')+']';
  let cur='',ts=Date.now(),acc={think:0,work:0},steps=0,final=false;
  const bump=()=>{const d=Date.now()-ts;ts=Date.now();if(cur==='réfléchit')acc.think+=d;if(cur==='exécute')acc.work+=d};
  C.log.push({t:'user',text:b.message,files:(b.files||[]).map(f=>f.path)});for(const ev of imgEvents){C.log.push(ev);emit('image',ev)}
  const em=(t,d)=>{if(t==='progress'||t==='delta')return emit(t,d);if(t==='status'){bump();cur=d.s;return emit(t,d)}
   if(t==='tool')steps++;if(t==='tool'||t==='result')m.actions.push({t,...d,at:new Date().toISOString()});
   if(t==='final')final=true;C.log.push({t,...d});if(recoveryId)try{REC.checkpointMission(pid,recoveryId,{history:C.history,log:C.log})}catch{};emit(t,d)};
  C.history.push({role:'user',content:msg});
  // mode auto : tâche concrète -> agent, sinon discussion simple
  let mode=eph?'chat':b.mode;const TASK=/cr[ée]e|cr[ée]er|écri|génèr|génér|modifi|supprim|lance|exécut|install|fichier|dossier|script|captur|screenshot|corrig|ajout|compil|test/i;
  let autoWhy='';if(mode==='auto'){autoWhy=AUTO.needsAgent(b.message||'').agent?'tâche':''}
  if(mode==='auto')mode=(autoWhy||Object.values(mcp).some(s=>s.status==='running')||E.get(pid)||(C.mode==='agent'&&(b.message||'').length<30&&C.history.length>1))?'agent':'chat';
  C.mode=mode;if(mode==='agent'&&!eph){try{const snap=REC.snapshotProject(root,pid,'avant mission : '+String(b.message||'').slice(0,80));const rec=REC.beginMission({project:pid,conversation:cvv,title:b.message,snapshotId:snap.id,history:C.history,log:C.log});recoveryId=rec.id;ACT.log('recovery','Instantané créé avant mission '+rec.title,{level:'info'});}catch(e){ACT.reportError({origin:'Mission Recovery',message:e.message,context:'Snapshot avant mission'})}}emit('mode',{mode});
  const rm=/^\s*(?:souviens-toi|retiens|rappelle-toi|n'oublie pas)\s*(?:que|:)?\s*(.{3,300})/i.exec(b.message||''),okTxt=rm?(eph?"Discussion éphémère : je ne mémorise rien en dehors de cette conversation.":"C'est noté dans la mémoire du projet : « "+rm[1].trim()+" »."):'';
  // autorisations de session (dev libre / réseau) : jamais pour le système ni le destructif
  const DEVFREE=/(d[ée]veloppe|travaille|bosse)\s+(librement|en autonomie)|carte blanche|autonomie (totale|compl[èe]te)/i,NETOK=/autorise[- ]?(?:moi )?(?:le |l')?(?:r[ée]seau|acc[èe]s r[ée]seau|internet)/i,REVOKE=/(r[ée]voque|retire|annule)\s+(?:les |toutes les )?autorisations?/i;
  C.grants=C.grants||{};let gnote='';
  if(REVOKE.test(b.message||'')){C.grants={};gnote='Autorisations de session retirées.'}else{if(DEVFREE.test(b.message||'')){C.grants.dev=true;gnote='Développement libre activé pour cette discussion : fichiers, compilation, exécution et installation de dépendances sans confirmation. Réseau, système et actions destructives restent soumis à confirmation.'}if(NETOK.test(b.message||'')){C.grants.network=true;gnote=(gnote?gnote+' ':'')+'Accès réseau autorisé pour cette discussion.'}}
  if(gnote)em('say',{text:gnote});
  if(autoWhy&&mode==='agent')em('say',{text:'Mode Auto : cette demande est une tâche, je passe en mode Agent (je peux créer des fichiers, lancer des commandes et tester).'});
  const grants={...(settings.grants?.[pid]||{}),...C.grants},gate=mode==='agent'?intent.classify(b.message||''):{kind:'clear'},clarifyNow=!rm&&gate.kind==='clarify';
  try{const f=rm?(m.project.push({text:rm[1].trim()}),em('final',{text:okTxt}),okTxt):clarifyNow?(em('final',{text:gate.text,clarify:true}),gate.text):await (mode==='chat'?agent.chat:agent.run)({prov:b.provider,model:b.model,settings,msg,images,history:C.history.slice(0,-1),root,mem:m,mcp:Object.values(mcp).filter(s=>s.status==='running'),env:E.get(pid),autoShot:settings.autoShot||'important',grants,created:createdFor(pid),drivers:(await E.list(pid)).drivers,emit:em,ask:id=>new Promise(ok=>{pend[id]=ok;ac.signal.addEventListener('abort',()=>ok(false))}),askLoop:id=>new Promise(ok=>{loopPend[id]=ok;ac.signal.addEventListener('abort',()=>ok('stop'))}),signal:ac.signal});
   if(f)C.history.push({role:'assistant',content:f})}catch(e){em('error',{text:e.message})}
  bump();if(settings.autoTestAfterChanges&&mode==='agent'&&m.actions.slice(actionStart).some(a=>a.t==='tool'&&['write_file','edit_file','append_file','delete_file','replace_in_files','format_json','move_file','copy_file'].includes(a.name))){try{const report=await TEST.run({root,project:pid});em('testReport',{report});ACT.log('testing','Tests automatiques après modification : '+report.status,{level:report.status==='passed'?'info':'warn',notify:report.status!=='passed'})}catch(e){em('testReport',{report:{status:'error',output:e.message}})}}
  const sm={think:acc.think,work:acc.work,steps,final};C.log.push({t:'summary',...sm});emit('summary',sm);if(recoveryId)try{REC.finishMission(pid,recoveryId,ac.signal.aborted?'interrupted':final?'completed':'failed',{history:C.history,log:C.log})}catch{}
  if(eph){EPH.set(pid+':'+cvv,C);while(EPH.size>20)EPH.delete(EPH.keys().next().value)}
  else{cw(pid,cvv,C);delete m.prefs;S.write('mem-'+pid+'.json',m);
  const l2=lst(pid),it=l2.find(c=>c.id===cvv);if(it){if(it.title==='Nouvelle discussion')it.title=(b.message||'Fichier').slice(0,40);it.ts=Date.now();S.write('convs-'+pid+'.json',l2)}}
  emit('status',{s:'inactif'});return res.end()}
 send(res,{error:'not found'},404)}catch(e){const status=Number.isInteger(e.statusCode)?e.statusCode:500;if(status>=500)ACT.reportError({origin:'Serveur',message:e.message,context:req.method+' '+p});send(res,{error:e.message},status)}
}).listen(PORT,'127.0.0.1',()=>{ACT.log('system','Astra Agent '+VERSION+' démarré (127.0.0.1:'+PORT+')');console.log('Astra Agent '+VERSION+' : http://localhost:'+PORT+' (écoute locale uniquement)')});

for(const sg of ['SIGINT','SIGTERM'])process.on(sg,()=>{E.killAll();setTimeout(()=>process.exit(),300)});
