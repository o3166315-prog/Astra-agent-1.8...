// Outils d'environnement : captures réelles + actions GUI. Les permissions viennent du pilote (jamais de l'agent).
const num=v=>{v=Math.round(+v);if(!(v>=0&&v<=4000))throw new Error('coordonnée invalide');return v};
exports.envTools={
 screenshot:{perm:(a,c)=>c.env.driver.perm,desc:"Prend une VRAIE capture de l'environnement actif (page rendue ou écran). args:{url?} (url : fichier du projet ou http://localhost, pilote navigateur seulement)",run:async(a,c)=>{const s=await c.env.capture(a);return{text:'Capture '+s.w+'x'+s.h+' prise ('+c.env.driver.id+')',shot:s}}},
 gui_click:{perm:'CONFIRM',desc:"Clic gauche dans l'écran virtuel. args:{x,y}",run:async(a,c)=>{await c.env.input('click',{x:num(a.x),y:num(a.y)});return 'clic ('+a.x+','+a.y+')'}},
 gui_type:{perm:'CONFIRM',desc:'Tape du texte au clavier. args:{text}',run:async(a,c)=>{await c.env.input('type',{text:String(a.text||'').slice(0,500)});return 'texte saisi'}},
 gui_key:{perm:'CONFIRM',desc:'Appuie sur une touche (ex: Return, ctrl+s). args:{key}',run:async(a,c)=>{if(!/^[\w+\-]{1,30}$/.test(a.key||''))throw new Error('touche invalide');await c.env.input('key',{key:a.key});return 'touche '+a.key}}
};
