// API HTTP minimale sans dépendance : GET /health, GET /api/items, POST /api/items (données en mémoire).
const http = require('http');
function createServer() {
  const items = [];
  return http.createServer((req, res) => {
    const send = (code, data) => { res.writeHead(code, { 'content-type': 'application/json; charset=utf-8' }); res.end(JSON.stringify(data)); };
    if (req.method === 'GET' && req.url === '/health') return send(200, { ok: true });
    if (req.method === 'GET' && req.url === '/api/items') return send(200, items);
    if (req.method === 'POST' && req.url === '/api/items') {
      let body = '';
      req.on('data', d => { body += d; if (body.length > 1e6) req.destroy(); });
      req.on('end', () => {
        try { const item = JSON.parse(body || '{}'); if (typeof item.name !== 'string' || !item.name) return send(400, { error: 'name requis' }); items.push({ id: items.length + 1, name: item.name }); send(201, items[items.length - 1]); }
        catch { send(400, { error: 'JSON invalide' }); }
      });
      return;
    }
    send(404, { error: 'introuvable' });
  });
}
module.exports = { createServer };
if (require.main === module) { const port = +process.env.PORT || 3000; createServer().listen(port, () => console.log('API sur http://localhost:' + port)); }
