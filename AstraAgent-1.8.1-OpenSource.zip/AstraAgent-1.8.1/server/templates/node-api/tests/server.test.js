const test = require('node:test'), assert = require('node:assert/strict');
const { createServer } = require('../server.js');
test('health, création et liste', async () => {
  const srv = createServer(); await new Promise(r => srv.listen(0, '127.0.0.1', r));
  const base = 'http://127.0.0.1:' + srv.address().port;
  try {
    assert.deepEqual(await (await fetch(base + '/health')).json(), { ok: true });
    const r = await fetch(base + '/api/items', { method: 'POST', body: JSON.stringify({ name: 'a' }) });
    assert.equal(r.status, 201);
    assert.equal((await (await fetch(base + '/api/items')).json()).length, 1);
    assert.equal((await fetch(base + '/api/items', { method: 'POST', body: '{}' })).status, 400);
  } finally { srv.close(); }
});
