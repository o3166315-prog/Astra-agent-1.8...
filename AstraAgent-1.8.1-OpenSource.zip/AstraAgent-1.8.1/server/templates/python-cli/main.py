"""{{title}} : petit outil en ligne de commande. Lance-le avec : python main.py Alice --shout"""
import argparse


def greet(name: str = "toi", shout: bool = False) -> str:
    message = f"Bonjour {name} !"
    return message.upper() if shout else message


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="{{title}}")
    parser.add_argument("name", nargs="?", default="toi")
    parser.add_argument("--shout", action="store_true", help="tout en majuscules")
    args = parser.parse_args(argv)
    print(greet(args.name, args.shout))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
