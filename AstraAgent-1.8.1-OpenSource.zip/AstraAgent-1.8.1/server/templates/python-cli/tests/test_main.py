import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from main import greet  # noqa: E402


class GreetTests(unittest.TestCase):
    def test_default(self):
        self.assertEqual(greet(), "Bonjour toi !")

    def test_name(self):
        self.assertEqual(greet("Alice"), "Bonjour Alice !")

    def test_shout(self):
        self.assertEqual(greet("Alice", shout=True), "BONJOUR ALICE !")


if __name__ == "__main__":
    unittest.main()
