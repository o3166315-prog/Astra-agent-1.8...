document.getElementById('year').textContent = new Date().getFullYear();
document.getElementById('contactForm').addEventListener('submit', e => {
  e.preventDefault();
  document.getElementById('formMsg').textContent = 'Merci ! (Le formulaire n’envoie rien : branche-le à ton service préféré.)';
  e.target.reset();
});
