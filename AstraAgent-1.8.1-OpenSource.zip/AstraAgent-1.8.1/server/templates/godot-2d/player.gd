extends CharacterBody2D
# Déplacement 2D de base avec les actions « ui_* » (flèches par défaut).

@export var speed: float = 300.0


func _physics_process(_delta: float) -> void:
	var direction := Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	velocity = direction * speed
	move_and_slide()
