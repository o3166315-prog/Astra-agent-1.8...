// Mini-jeu : un carré qui ramasse des pièces. Point de départ à modifier.
const canvas = document.getElementById('game'), ctx = canvas.getContext('2d');
const W = canvas.width, H = canvas.height, TIME = 30;
const keys = new Set();
addEventListener('keydown', e => { keys.add(e.key.toLowerCase()); if (e.key.toLowerCase() === 'r') reset(); if (e.key.startsWith('Arrow')) e.preventDefault(); });
addEventListener('keyup', e => keys.delete(e.key.toLowerCase()));

let player, coins, score, timeLeft, over;
function reset() {
  player = { x: W / 2, y: H / 2, size: 28, speed: 260 };
  coins = Array.from({ length: 6 }, spawnCoin);
  score = 0; timeLeft = TIME; over = false;
}
function spawnCoin() { return { x: 30 + Math.random() * (W - 60), y: 30 + Math.random() * (H - 60), r: 10 }; }

function update(dt) {
  if (over) return;
  const dx = (keys.has('arrowright') || keys.has('d') ? 1 : 0) - (keys.has('arrowleft') || keys.has('a') || keys.has('q') ? 1 : 0);
  const dy = (keys.has('arrowdown') || keys.has('s') ? 1 : 0) - (keys.has('arrowup') || keys.has('w') || keys.has('z') ? 1 : 0);
  const len = Math.hypot(dx, dy) || 1;
  player.x = Math.min(W - player.size / 2, Math.max(player.size / 2, player.x + dx / len * player.speed * dt));
  player.y = Math.min(H - player.size / 2, Math.max(player.size / 2, player.y + dy / len * player.speed * dt));
  coins.forEach((c, i) => { if (Math.hypot(c.x - player.x, c.y - player.y) < c.r + player.size / 2) { score++; coins[i] = spawnCoin(); } });
  timeLeft -= dt; if (timeLeft <= 0) { timeLeft = 0; over = true; }
}

function draw() {
  ctx.clearRect(0, 0, W, H);
  ctx.fillStyle = '#ffd84a'; coins.forEach(c => { ctx.beginPath(); ctx.arc(c.x, c.y, c.r, 0, Math.PI * 2); ctx.fill(); });
  ctx.fillStyle = '#f2f2f2'; ctx.fillRect(player.x - player.size / 2, player.y - player.size / 2, player.size, player.size);
  ctx.fillStyle = '#fff'; ctx.font = '20px system-ui'; ctx.fillText('Score : ' + score, 16, 30); ctx.fillText('Temps : ' + timeLeft.toFixed(1), W - 140, 30);
  if (over) { ctx.font = '36px system-ui'; ctx.textAlign = 'center'; ctx.fillText('Partie terminée — score ' + score, W / 2, H / 2); ctx.font = '18px system-ui'; ctx.fillText('Appuie sur R pour rejouer', W / 2, H / 2 + 34); ctx.textAlign = 'left'; }
}

let last = performance.now();
function loop(now) { const dt = Math.min(0.05, (now - last) / 1000); last = now; update(dt); draw(); requestAnimationFrame(loop); }
reset(); requestAnimationFrame(loop);
