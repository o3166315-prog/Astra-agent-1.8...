#!/usr/bin/env node
// Petit outil en ligne de commande : « node src/index.js Alice --shout »
function run(argv) {
  const args = argv.filter(a => !a.startsWith('--')), flags = new Set(argv.filter(a => a.startsWith('--')));
  if (flags.has('--help') || flags.has('-h')) return 'Utilisation : {{slug}} [nom] [--shout]';
  const msg = 'Bonjour ' + (args[0] || 'toi') + ' !';
  return flags.has('--shout') ? msg.toUpperCase() : msg;
}
module.exports = { run };
if (require.main === module) console.log(run(process.argv.slice(2)));
