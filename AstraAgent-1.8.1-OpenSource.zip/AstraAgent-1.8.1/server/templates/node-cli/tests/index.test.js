const test = require('node:test'), assert = require('node:assert/strict');
const { run } = require('../src/index.js');
test('salue par défaut', () => assert.equal(run([]), 'Bonjour toi !'));
test('salue un nom', () => assert.equal(run(['Alice']), 'Bonjour Alice !'));
test('option --shout', () => assert.equal(run(['Alice', '--shout']), 'BONJOUR ALICE !'));
