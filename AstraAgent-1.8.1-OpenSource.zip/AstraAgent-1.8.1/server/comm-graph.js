// Astra Communication Graph (côté serveur) : le noyau est partagé avec l'interface (public/comm-core.js)
// pour que le graphe en direct et le graphe d'une mission archivée soient construits exactement de la même façon.
module.exports = require('../public/comm-core.js');
