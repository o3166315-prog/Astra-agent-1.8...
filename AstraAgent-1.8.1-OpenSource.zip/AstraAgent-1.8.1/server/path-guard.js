'use strict';
const fs = require('fs');
const path = require('path');
const os = require('os');

function samePath(a, b) {
  return path.relative(path.resolve(a), path.resolve(b)) === '';
}

function isInside(candidate, root) {
  const rel = path.relative(path.resolve(root), path.resolve(candidate));
  return rel === '' || (rel !== '..' && !rel.startsWith('..' + path.sep) && !path.isAbsolute(rel));
}

function rejectSymlinkComponents(target, startAtRoot = false) {
  const absolute = path.resolve(target);
  const parsed = path.parse(absolute);
  let current = parsed.root;
  const parts = absolute.slice(parsed.root.length).split(path.sep).filter(Boolean);
  for (const part of parts) {
    current = path.join(current, part);
    try {
      const st = fs.lstatSync(current);
      if (st.isSymbolicLink()) {
        const error = new Error('Lien symbolique refusé : ' + current);
        error.code = 'ASTRA_SYMLINK';
        throw error;
      }
      if (st.isFile() && Number(st.nlink) > 1) {
        const error = new Error('Lien matériel refusé : ' + current);
        error.code = 'ASTRA_HARDLINK';
        throw error;
      }
    } catch (error) {
      if (error.code === 'ENOENT' || error.code === 'ENOTDIR') break;
      throw error;
    }
  }
  return absolute;
}

function canonicalProjectRoot(root) {
  if (typeof root !== 'string' || !root.trim()) throw new Error('Racine de projet invalide.');
  const absolute = path.resolve(root);
  rejectSymlinkComponents(absolute);
  if (samePath(absolute, path.parse(absolute).root)) throw new Error('La racine du système ne peut pas être ouverte comme projet.');
  let st;
  try { st = fs.lstatSync(absolute); } catch { throw new Error('Le dossier du projet est introuvable : ' + absolute); }
  if (st.isSymbolicLink()) throw new Error('La racine du projet ne peut pas être un lien symbolique.');
  if (!st.isDirectory()) throw new Error('Le chemin du projet n’est pas un dossier : ' + absolute);
  const real = fs.realpathSync(absolute);
  const home = path.resolve(os.homedir());
  let realHome = home;
  try { realHome = fs.realpathSync(home); } catch {}
  if (samePath(real, path.parse(real).root)) throw new Error('La racine du système ne peut pas être ouverte comme projet.');
  if (samePath(real, realHome)) throw new Error('Le dossier personnel ne peut pas être ouvert comme projet. Choisis un sous-dossier de projet.');
  return real;
}

function resolveProjectPath(root, requested) {
  const rootAbs = canonicalProjectRoot(path.resolve(root));
  const candidate = path.resolve(rootAbs, String(requested || '.'));
  if (!isInside(candidate, rootAbs)) throw new Error('Chemin hors du projet refusé : ' + requested);
  const rel = path.relative(rootAbs, candidate);
  let current = rootAbs;
  if (rel) {
    for (const part of rel.split(path.sep).filter(Boolean)) {
      current = path.join(current, part);
      try {
        const st = fs.lstatSync(current);
        if (st.isSymbolicLink()) {
          const error = new Error('Lien symbolique refusé : ' + requested);
          error.code = 'ASTRA_SYMLINK';
          throw error;
        }
        if (st.isFile() && Number(st.nlink) > 1) {
          const error = new Error('Lien matériel refusé : ' + requested);
          error.code = 'ASTRA_HARDLINK';
          throw error;
        }
      } catch (error) {
        if (error.code === 'ENOENT' || error.code === 'ENOTDIR') break;
        throw error;
      }
    }
  }
  // Confirm that the nearest existing ancestor still resolves inside the canonical root.
  let ancestor = candidate;
  while (!fs.existsSync(ancestor)) {
    const parent = path.dirname(ancestor);
    if (parent === ancestor) break;
    ancestor = parent;
  }
  const realAncestor = fs.realpathSync(ancestor);
  if (!isInside(realAncestor, rootAbs)) throw new Error('Chemin résolu hors du projet refusé : ' + requested);
  return candidate;
}

function normalizeAnyPath(requested, base) {
  const expanded = String(requested || '.').replace(/^~(?=$|[\\/])/, os.homedir());
  const absolute = path.resolve(base || process.cwd(), expanded);
  rejectSymlinkComponents(absolute);
  return absolute;
}

module.exports = { samePath, isInside, rejectSymlinkComponents, canonicalProjectRoot, resolveProjectPath, normalizeAnyPath };
