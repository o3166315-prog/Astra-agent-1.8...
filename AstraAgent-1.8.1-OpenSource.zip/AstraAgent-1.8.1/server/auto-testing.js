// Astra Auto Testing — exécute uniquement la commande de test déjà déclarée par le projet.
// Aucun paquet n'est installé automatiquement et aucune correction n'est appliquée.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { spawn } = require('child_process');
const S = require('./store');
const { detectTest } = require('./moretools');
const { walk, safe } = require('./tools');

function fingerprint(root) {
  const hash = crypto.createHash('sha256');
  let files = 0;
  for (const rel of walk(root, root).filter(x => !x.endsWith('/')).slice(0, 5000)) {
    const full = safe(root, rel);
    try {
      const st = fs.statSync(full);
      if (!st.isFile() || st.size > 5 * 1024 * 1024) continue;
      hash.update(rel.replace(/\\/g, '/') + '\0');
      hash.update(fs.readFileSync(full));
      files++;
    } catch {}
  }
  return { sha256: hash.digest('hex'), files };
}

function reports(project) {
  return S.read('test-reports-' + String(project).replace(/[^\w-]/g, '') + '.json', []);
}

async function run({ root, project, timeoutMs = 300000 }) {
  const command = detectTest(root);
  const now = new Date().toISOString();
  if (!command) {
    return { id: 'test-' + Date.now().toString(36), project, status: 'no-tests', command: null,
      startedAt: now, finishedAt: now, exitCode: null, durationMs: 0,
      output: 'Aucune commande de test reconnue. Ajoute un script "test" dans package.json, ou une configuration pytest/Cargo/Go/CMake.' };
  }
  const before = fingerprint(root);
  const started = Date.now();
  const previous = reports(project);
  const lastSuccess = previous.find(x => x.status === 'passed');
  const result = await new Promise(resolve => {
    let output = '', settled = false, timedOut = false;
    const child = spawn(command, { cwd: root, shell: true, windowsHide: true, env: process.env });
    const finish = (code, err) => {
      if (settled) return; settled = true; clearTimeout(timer);
      if (err) output += '\n' + err;
      resolve({ exitCode: code, timedOut, output });
    };
    const append = chunk => { output += String(chunk); if (output.length > 50000) output = output.slice(-50000); };
    child.stdout.on('data', append); child.stderr.on('data', append);
    child.on('error', e => finish(null, e.message));
    child.on('close', code => finish(code));
    const timer = setTimeout(() => { timedOut = true; try { child.kill(); } catch {} finish(null, 'Délai maximal dépassé : processus arrêté.'); }, Math.max(5000, Math.min(300000, timeoutMs)));
  });
  const after = fingerprint(root);
  const finishedAt = new Date().toISOString();
  const status = result.timedOut ? 'timeout' : result.exitCode === 0 ? 'passed' : 'failed';
  const report = {
    id: 'test-' + Date.now().toString(36), project, command, status,
    startedAt: new Date(started).toISOString(), finishedAt, durationMs: Date.now() - started,
    exitCode: result.exitCode, output: result.output.slice(-30000),
    fingerprint: after, changedSincePreviousRun: !!(previous[0] && previous[0].fingerprint?.sha256 !== before.sha256),
    regressionCandidate: status !== 'passed' && !!lastSuccess,
    comparedWith: lastSuccess?.id || null
  };
  const next = [report, ...previous].slice(0, 20);
  S.write('test-reports-' + String(project).replace(/[^\w-]/g, '') + '.json', next);
  return report;
}

module.exports = { run, fingerprint, reports, detectTest };
