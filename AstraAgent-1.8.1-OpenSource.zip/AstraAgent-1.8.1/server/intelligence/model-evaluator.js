// Model Evaluator : 1) élimine les modèles qui violent une contrainte obligatoire, 2) note les autres.
// Score = Σ poids_i × note_i (notes normalisées 0–1). Donnée inconnue => note neutre 0,5 ET signalée comme telle.
const DEFAULT_WEIGHTS = { capability: 35, quality: 25, cost: 15, latency: 10, context: 10, reliability: 5 };
const LABELS = { capability: 'capacité sur la tâche', quality: 'qualité mesurée', cost: 'coût', latency: 'latence', context: 'contexte', reliability: 'fiabilité' };
const NEUTRAL = 0.5;

function weightsFor(cfg, task) {
  const w = { ...DEFAULT_WEIGHTS };
  for (const k of Object.keys(w)) { const v = cfg && cfg.weights && cfg.weights[k]; if (Number.isFinite(+v) && +v >= 0) w[k] = +v; }
  if (task) {
    if (task.priority === 'cost') w.cost *= 3;
    else if (task.priority === 'speed') w.latency *= 3;
    else if (task.priority === 'quality') { w.capability *= 1.5; w.quality *= 1.5; }
  }
  const sum = Object.values(w).reduce((a, b) => a + b, 0) || 1;
  return Object.fromEntries(Object.entries(w).map(([k, v]) => [k, v / sum]));
}
const avgCost = e => e.cost.source === 'unknown' ? null : (e.cost.in + e.cost.out) / 2;

function constraints(entry, task, cfg, settings) {
  const why = [];
  const s = (settings && settings[entry.provider]) || {};
  if (entry.type !== 'local' && !s.key) why.push('clé API manquante');
  if (task.requiresVision && entry.vision.value !== true) why.push(entry.vision.value === false ? 'pas de vision' : 'vision non confirmée');
  if (entry.context.value && task.contextRequired > entry.context.value) why.push('contexte insuffisant (' + entry.context.value + ' < ' + task.contextRequired + ' jetons)');
  const max = cfg && cfg.maxCostPer1M;
  if (max > 0 && avgCost(entry) !== null && avgCost(entry) > max) why.push('au-dessus du budget (' + avgCost(entry) + ' > ' + max + ' / 1M jetons)');
  if (cfg && cfg.localOnly && entry.type !== 'local') why.push('mode « local uniquement »');
  return why;
}

function evaluate(entries, task, cfg, settings) {
  const eligible = [], eliminated = [];
  for (const e of entries) { const why = constraints(e, task, cfg, settings); (why.length ? eliminated.push({ entry: e, reasons: why }) : eligible.push(e)); }
  const w = weightsFor(cfg, task);
  const costs = eligible.map(avgCost).filter(x => x !== null), lat = eligible.map(e => e.perf && e.perf.avgMs).filter(x => x != null);
  // note « de bonté » 0–1 ; si tous les modèles sont à égalité, personne n'est pénalisé.
  const norm = (v, arr, invert) => { const lo = Math.min(...arr), hi = Math.max(...arr); if (hi === lo) return 1; const n = (v - lo) / (hi - lo); return invert ? 1 - n : n; };
  const ranked = eligible.map(e => {
    const used = {}, notes = {}, known = {};
    const cats = [task.task, ...(task.categories || [])].filter((c, i, a) => a.indexOf(c) === i);
    const tested = cats.map(c => e.capabilities[c]).filter(c => c && c.score != null);
    if (cats.includes('vision') && e.vision.value) { tested.push({ score: 100 }); }
    notes.capability = tested.length ? tested.reduce((a, c) => a + c.score, 0) / tested.length / 100 : NEUTRAL; known.capability = tested.length > 0;
    const all = Object.values(e.capabilities).filter(c => c.score != null);
    notes.quality = all.length ? all.reduce((a, c) => a + c.score, 0) / all.length / 100 : NEUTRAL; known.quality = all.length > 0;
    const c = avgCost(e);
    notes.cost = c === null ? NEUTRAL : costs.length > 1 ? norm(c, costs, true) : (c === 0 ? 1 : NEUTRAL); known.cost = c !== null;
    const l = e.perf && e.perf.avgMs;
    notes.latency = l == null ? NEUTRAL : (lat.length > 1 ? norm(l, lat, true) : 1); known.latency = l != null;
    notes.context = e.context.value ? 1 : NEUTRAL; known.context = !!e.context.value;
    const fr = e.perf && e.perf.requests >= 3 ? e.perf.failureRate : null;
    notes.reliability = fr == null ? NEUTRAL : 1 - fr; known.reliability = fr != null;
    let score = 0; const parts = [];
    for (const k of Object.keys(w)) { const pts = w[k] * notes[k] * 100; score += pts; parts.push({ criterion: k, label: LABELS[k], weight: Math.round(w[k] * 1000) / 10, note: Math.round(notes[k] * 100) / 100, points: Math.round(pts * 10) / 10, known: known[k] }); }
    const knownWeight = Object.keys(w).reduce((a, k) => a + (known[k] ? w[k] : 0), 0);
    const warnings = [];
    if (!known.capability) warnings.push('capacité non testée pour cette tâche (note neutre) — lance un benchmark');
    if (!known.cost && e.type !== 'local') warnings.push('coût inconnu (saisis les prix pour l’inclure)');
    if (e.context.source === 'unknown') warnings.push('taille de contexte inconnue');
    return { entry: e, score: Math.round(score * 10) / 10, parts, confidence: Math.round(knownWeight * 100), warnings };
  }).sort((a, b) => b.score - a.score || b.confidence - a.confidence || a.entry.id.localeCompare(b.entry.id));
  return { ranked, eliminated, weights: w };
}
module.exports = { evaluate, weightsFor, DEFAULT_WEIGHTS, LABELS };
