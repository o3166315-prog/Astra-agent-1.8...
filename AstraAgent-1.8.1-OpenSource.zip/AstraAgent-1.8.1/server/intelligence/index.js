// Astra Model Intelligence : sélection, évaluation et routage des modèles existants (ce n'est pas un nouveau modèle d'IA).
const S = require('../store');
const { createMonitor } = require('./performance-monitor');
const registry = require('./model-registry');
const analyzer = require('./task-analyzer');
const router = require('./intelligent-router');
const bench = require('./benchmark-engine');
const fb = require('./fallback-manager');
const { DEFAULT_WEIGHTS } = require('./model-evaluator');

const DEFAULTS = { mode: 'hybrid', weights: { ...DEFAULT_WEIGHTS }, maxCostPer1M: null, localOnly: false, fallback: false, overrides: {} };

function sanitize(b, prev) {
  const out = { ...DEFAULTS, ...(prev || {}) };
  if (['auto', 'manual', 'hybrid'].includes(b.mode)) out.mode = b.mode;
  if (b.weights && typeof b.weights === 'object') {
    out.weights = { ...DEFAULT_WEIGHTS, ...(out.weights || {}) };
    for (const k of Object.keys(DEFAULT_WEIGHTS)) if (k in b.weights) { const v = +b.weights[k]; if (Number.isFinite(v)) out.weights[k] = Math.max(0, Math.min(100, v)); }
  }
  if ('maxCostPer1M' in b) { const v = +b.maxCostPer1M; out.maxCostPer1M = Number.isFinite(v) && v > 0 ? v : null; }
  if ('localOnly' in b) out.localOnly = !!b.localOnly;
  if ('fallback' in b) out.fallback = !!b.fallback;
  if (b.overrides && typeof b.overrides === 'object') {
    out.overrides = { ...(out.overrides || {}) };
    for (const [id, o] of Object.entries(b.overrides)) {
      if (!/^[a-z][a-z0-9_-]{0,30}\/[\w.:\-\/@+ ]{1,120}$/.test(id) || typeof o !== 'object') continue;
      if (o === null || Object.keys(o).length === 0) { delete out.overrides[id]; continue; }
      const n = x => (x === '' || x == null) ? undefined : (Number.isFinite(+x) && +x >= 0 ? +x : undefined);
      out.overrides[id] = { context: n(o.context), costIn: n(o.costIn), costOut: n(o.costOut) };
    }
  }
  return out;
}

function create({ providers, getSettings }) {
  const monitor = createMonitor();
  monitor.instrument(providers);
  const cfg = () => ({ ...DEFAULTS, ...(getSettings().intelligence || {}) });
  const benchmarks = () => S.read('intel-bench.json', {});
  const load = async force => registry.list({ providers, settings: getSettings(), benchmarks: benchmarks(), monitor, cfg: cfg(), force });
  return {
    monitor, registry, analyzer, bench, fallback: fb, DEFAULTS, sanitize,
    config: cfg,
    async snapshot(force) { const r = await load(force); return { config: cfg(), registry: r, perModel: monitor.perModel(), selections: monitor.selections(), incidents: monitor.incidents(), benchmarks: benchmarks(), tasks: bench.TASKS.map(t => ({ id: t.id, title: t.title, category: t.category })) }; },
    async route(input, manual) { const r = await load(); return router.route(input, { registry: r, cfg: cfg(), settings: getSettings(), monitor, manual }); },
    // Candidats de reprise : meilleurs modèles éligibles, hors modèle déjà tenté.
    async candidates(input, exclude, max) { const r = await router.route(input, { registry: await load(), cfg: cfg(), settings: getSettings(), monitor: null }); return r.ranking.filter(x => x.id !== exclude).slice(0, max || 3).map(x => ({ provider: x.provider, model: x.model, id: x.id })); },
    async runBenchmark(ids, { signal, onProgress } = {}) {
      const r = await load(), entries = r.entries.filter(e => ids.includes(e.id));
      if (!entries.length) throw new Error('Aucun modèle sélectionné disponible pour le benchmark.');
      const results = await bench.runBenchmark({ entries, signal, onProgress, chat: (e, msgs) => providers[e.provider].chat(getSettings()[e.provider] || {}, e.model, msgs, { plain: true, signal }) });
      const all = benchmarks(); Object.assign(all, results); S.write('intel-bench.json', all); registry.invalidate();
      return results;
    }
  };
}
module.exports = { create, sanitize, DEFAULTS };
