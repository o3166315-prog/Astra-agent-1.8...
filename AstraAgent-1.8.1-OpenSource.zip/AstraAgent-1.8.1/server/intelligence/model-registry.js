// Model Registry : fiche de chaque modèle disponible. On distingue strictement :
//   declared  = information fournie par le fournisseur / vérification du fournisseur,
//   tested    = mesuré par un benchmark Astra sur cette machine,
//   heuristic = déduit du nom du modèle (peu fiable),
//   user      = saisi par l'utilisateur (contexte, prix),
//   unknown   = inconnu : jamais deviné.
const { tokens } = require('./task-analyzer');
const STATIC_VISION = new Set(['openai', 'anthropic', 'gemini']);
const LOCAL = new Set(['ollama', 'local']);
const CAPS = ['coding', 'debugging', 'reasoning', 'document', 'structured'];
let cache = { at: 0, key: '', data: null };

const hasCreds = (name, s) => LOCAL.has(name) ? true : !!(s && s.key);

async function list({ providers, settings, benchmarks, monitor, cfg, force }) {
  const key = JSON.stringify(Object.keys(providers).map(k => [k, !!settings[k]?.key, settings[k]?.url || '', settings[k]?.ctx || '']));
  let base;
  if (!force && cache.data && cache.key === key && Date.now() - cache.at < 60000) base = cache.data;
  else {
    const entries = [], problems = [];
    await Promise.all(Object.entries(providers).map(async ([name, P]) => {
      const s = settings[name] || {};
      if (!hasCreds(name, s)) { problems.push({ provider: name, label: P.label, error: 'Clé API non configurée', level: 'info' }); return; }
      let models = [];
      try { models = await Promise.race([P.models(s), new Promise((_, r) => setTimeout(() => r(new Error('délai dépassé (6 s)')), 6000))]); }
      catch (e) { problems.push({ provider: name, label: P.label, error: String(e.message || e).slice(0, 200), level: 'warn' }); return; }
      for (const model of models || []) {
        let v = null, vs = 'unknown';
        try { v = !!(await P.vision(s, model)); vs = STATIC_VISION.has(name) ? 'declared' : 'heuristic'; } catch {}
        entries.push({
          id: name + '/' + model, provider: name, providerLabel: P.label, model, type: LOCAL.has(name) ? 'local' : 'cloud',
          vision: { value: v, source: vs },
          context: LOCAL.has(name) ? { value: s.ctx || 8192, source: 'user' } : { value: null, source: 'unknown' }
        });
      }
    }));
    base = { entries, problems }; cache = { at: Date.now(), key, data: base };
  }
  const ov = (cfg && cfg.overrides) || {};
  const entries = base.entries.map(e => {
    const o = ov[e.id] || {}, b = benchmarks && benchmarks[e.id];
    const caps = {};
    for (const c of CAPS) {
      const r = b && b.byCategory && b.byCategory[c];
      caps[c] = r ? { score: r.score, source: 'tested', at: b.at } : { score: null, source: 'unknown' };
    }
    const context = o.context > 0 ? { value: +o.context, source: 'user' } : e.context;
    const cost = LOCAL.has(e.provider) ? { in: 0, out: 0, source: 'local' } : (o.costIn >= 0 && o.costIn !== undefined && o.costIn !== null && o.costIn !== '') || (o.costOut >= 0 && o.costOut !== undefined && o.costOut !== null && o.costOut !== '') ? { in: +o.costIn || 0, out: +o.costOut || 0, source: 'user' } : { in: null, out: null, source: 'unknown' };
    const st = monitor ? monitor.stats(e.provider, e.model) : null;
    return { ...e, context, cost, capabilities: caps, tested: !!b, testedAt: b ? b.at : null, perf: st };
  });
  return { entries, problems: base.problems, fetchedAt: new Date(cache.at).toISOString() };
}
const invalidate = () => { cache = { at: 0, key: '', data: null }; };
// Estimation de coût À PARTIR DES PRIX SAISIS par l'utilisateur (jamais de tarif supposé).
function estimateCost(entry, inChars, outChars) {
  if (!entry || entry.cost.source === 'unknown') return null;
  return (tokens('x'.repeat(inChars)) * entry.cost.in + tokens('x'.repeat(outChars)) * entry.cost.out) / 1e6;
}
module.exports = { list, invalidate, estimateCost, CAPS, hasCreds };
