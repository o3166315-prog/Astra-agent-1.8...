// Intelligent Router : choisit le modèle, explique pourquoi, et ne décide jamais à l'insu de l'utilisateur en mode manuel.
const { analyze } = require('./task-analyzer');
const { evaluate } = require('./model-evaluator');
const MODES = ['auto', 'manual', 'hybrid'];

function explain(top, task, runnerUp) {
  if (!top) return 'Aucun modèle disponible ne respecte les contraintes de cette tâche.';
  const best = top.parts.filter(p => p.known).sort((a, b) => b.points - a.points).slice(0, 2).map(p => p.label);
  let t = top.entry.id + ' choisi pour une tâche « ' + task.task + ' » (complexité ' + task.complexity + ', priorité ' + task.priority + ') : score ' + top.score + '/100';
  if (best.length) t += ', porté par ' + best.join(' et ');
  if (runnerUp) t += '. Second : ' + runnerUp.entry.id + ' (' + runnerUp.score + ').';
  else t += '.';
  if (top.confidence < 50) t += ' Confiance faible (' + top.confidence + ' %) : peu de données mesurées, un benchmark améliorerait ce choix.';
  return t;
}

async function route(input, ctx) {
  const { registry, cfg, settings, monitor, manual } = ctx;
  const task = input && input.contextRequired ? input : analyze(input);
  const ev = evaluate(registry.entries, task, cfg, settings);
  const mode = MODES.includes(cfg && cfg.mode) ? cfg.mode : 'hybrid';
  const ranked = ev.ranked, top = ranked[0] || null;
  const out = {
    mode, task, weights: ev.weights, ranking: ranked.map(r => ({ id: r.entry.id, provider: r.entry.provider, model: r.entry.model, score: r.score, confidence: r.confidence, parts: r.parts, warnings: r.warnings })),
    eliminated: ev.eliminated.map(x => ({ id: x.entry.id, reasons: x.reasons })),
    recommended: top ? { provider: top.entry.provider, model: top.entry.model, id: top.entry.id } : null,
    explanation: explain(top, task, ranked[1]), problems: registry.problems
  };
  // Qui décide ? auto : Astra ; hybrid : l'utilisateur confirme ; manual : choix de l'utilisateur uniquement.
  if (mode === 'manual' && manual && manual.provider && manual.model) { out.chosen = { provider: manual.provider, model: manual.model, id: manual.provider + '/' + manual.model, by: 'user' }; }
  else if (mode === 'auto' && top) out.chosen = { ...out.recommended, by: 'astra' };
  else out.chosen = null; // hybrid/manual : en attente du choix de l'utilisateur
  out.needsUserChoice = !out.chosen;
  if (monitor && out.recommended) monitor.logSelection({ task: task.task, complexity: task.complexity, mode, recommended: out.recommended.id, chosen: out.chosen ? out.chosen.id : null, by: out.chosen ? out.chosen.by : 'pending', score: top.score });
  return out;
}
module.exports = { route, explain, MODES };
