// Outils de développement (V1.8, étape 3) : serveur de dev, capture de page, modèles de projet, tests, README, ZIP, patch.
// Même principe que devtools.js : une fabrique ; chaque outil = { desc, run(args, ctx) }. Permissions : perms.js.
const fs = require('fs'), path = require('path'), net = require('net'), http = require('http'), zlib = require('zlib'), os = require('os');
const { spawn, spawnSync } = require('child_process'), { pathToFileURL } = require('url');
const perms = require('./perms'), { helpers: H } = require('./devtools');
const { relPath, TAIL, killTree, SKIP_DIRS, traceReport, matcher, exists, WIN } = H;

// ── Serveurs de développement lancés par l'agent ────────────────────────────────────────
const SERVERS = new Map(); let seq = 0, hooked = false;
const MAX_SERVERS = 3;
const stopServer = s => { try { if (s.kind === 'static') { s.server.close(); s.server.closeAllConnections?.(); } else if (s.proc && s.exited === null) killTree(s.proc); } catch { /* déjà arrêté */ } s.stopped = true; };
const killAll = () => { for (const s of SERVERS.values()) stopServer(s); SERVERS.clear(); };
const hook = () => { if (hooked) return; hooked = true; process.once('exit', killAll); for (const sig of ['SIGINT', 'SIGTERM']) if (!process.listenerCount(sig)) process.once(sig, () => { killAll(); process.exit(130); }); };
const portNum = v => { const n = +v; if (!Number.isInteger(n) || n < 1 || n > 65535) throw new Error('port invalide : ' + v + ' (1 à 65535)'); return n; };
const portOpen = (port, host = '127.0.0.1', ms = 700) => new Promise(res => { const s = net.connect({ port, host }); const done = r => { s.destroy(); res(r); }; s.setTimeout(ms, () => done(false)); s.once('connect', () => done(true)); s.once('error', () => done(false)); });
const freePort = (from = 8080) => new Promise(res => { const tryPort = p => { const s = net.createServer(); s.once('error', () => p < from + 40 ? tryPort(p + 1) : (() => { const z = net.createServer(); z.listen(0, '127.0.0.1', () => { const q = z.address().port; z.close(() => res(q)); }); })()); s.listen(p, '127.0.0.1', () => s.close(() => res(p))); }; tryPort(from); });
const sleep = ms => new Promise(r => setTimeout(r, ms));
const MIME = { '.html': 'text/html; charset=utf-8', '.htm': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.webp': 'image/webp', '.ico': 'image/x-icon', '.txt': 'text/plain; charset=utf-8', '.md': 'text/plain; charset=utf-8', '.wasm': 'application/wasm', '.mp3': 'audio/mpeg', '.ogg': 'audio/ogg', '.wav': 'audio/wav', '.mp4': 'video/mp4', '.woff2': 'font/woff2', '.woff': 'font/woff', '.glb': 'model/gltf-binary', '.gltf': 'model/gltf+json' };
const staticServer = (root, port, log) => new Promise((resolve, reject) => {
  const srv = http.createServer((req, res) => {
    const fail = (c, m) => { res.writeHead(c, { 'content-type': 'text/plain; charset=utf-8' }); res.end(m); };
    if (req.method !== 'GET' && req.method !== 'HEAD') return fail(405, 'Méthode non autorisée');
    let rel; try { rel = decodeURIComponent((req.url || '/').split('?')[0].split('#')[0]); } catch { return fail(400, 'Adresse invalide'); }
    if (rel.includes('\0')) return fail(400, 'Adresse invalide');
    let p = path.normalize(path.join(root, rel)); if (!perms.inside(p, root)) return fail(403, 'Interdit');
    const parts = path.relative(root, p).split(path.sep);
    if (parts.some(x => x === '.kairo' || x === '.git' || x === 'node_modules' || /^\.env/.test(x))) return fail(403, 'Interdit');
    try { if (fs.statSync(p).isDirectory()) p = path.join(p, 'index.html'); } catch { /* 404 plus bas */ }
    fs.readFile(p, (err, data) => {
      log(`${req.method} ${rel} → ${err ? 404 : 200}`);
      if (err) return fail(404, 'Introuvable : ' + rel);
      res.writeHead(200, { 'content-type': MIME[path.extname(p).toLowerCase()] || 'application/octet-stream', 'cache-control': 'no-store' });
      res.end(req.method === 'HEAD' ? undefined : data);
    });
  });
  srv.once('error', reject); srv.listen(port, '127.0.0.1', () => resolve(srv));
});
const detectDevCommand = c => {
  try {
    const pkg = JSON.parse(fs.readFileSync(path.join(c.root, 'package.json'), 'utf8')), sc = pkg.scripts || {}, name = ['dev', 'start', 'serve'].find(k => sc[k]);
    if (!name) return null;
    return exists(c, 'pnpm-lock.yaml') ? 'pnpm run ' + name : exists(c, 'yarn.lock') ? 'yarn ' + name : 'npm run ' + name;
  } catch { return null; }
};
const logTail = (s, n = 4000) => TAIL(s.logs, n) || '(aucune sortie)';
const describe = s => `${s.id}${s.name ? ' « ' + s.name + ' »' : ''} — ${s.kind === 'static' ? 'serveur statique' : s.command}${s.port ? ' — http://127.0.0.1:' + s.port : ''} — ${s.stopped ? 'arrêté' : s.exited !== null && s.exited !== undefined ? 'terminé (code ' + s.exited + ')' : 'en cours'}`;
const findServer = a => {
  if (a.id) { const s = SERVERS.get(String(a.id)); if (!s) throw new Error('Serveur inconnu : ' + a.id); return s; }
  if (a.port) { const p = portNum(a.port), s = [...SERVERS.values()].find(x => x.port === p); if (!s) throw new Error('Aucun serveur de l’agent sur le port ' + p); return s; }
  return null;
};

// ── Capture d'une page web (Edge / Chrome / Chromium sans interface) ────────────────────
const findBrowser = () => {
  const env = process.env.ASTRA_BROWSER; if (env && fs.existsSync(env)) return env;
  const win = [process.env['PROGRAMFILES(X86)'], process.env.PROGRAMFILES, process.env.LOCALAPPDATA].filter(Boolean).flatMap(b => [path.join(b, 'Microsoft/Edge/Application/msedge.exe'), path.join(b, 'Google/Chrome/Application/chrome.exe'), path.join(b, 'Chromium/Application/chrome.exe')]);
  const mac = ['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge', '/Applications/Chromium.app/Contents/MacOS/Chromium'];
  for (const f of WIN ? win : process.platform === 'darwin' ? mac : []) if (fs.existsSync(f)) return f;
  if (!WIN) for (const n of ['google-chrome', 'google-chrome-stable', 'chromium', 'chromium-browser', 'microsoft-edge', 'msedge']) { const r = spawnSync('which', [n], { encoding: 'utf8' }); if (r.status === 0 && r.stdout.trim()) return r.stdout.trim().split('\n')[0]; }
  return null;
};
const shoot = (browser, args, out, timeoutMs) => new Promise(resolve => {
  const p = spawn(browser, args, { windowsHide: true, detached: !WIN, stdio: 'ignore' }); let done = false, last = -1, stable = 0, iv, to;
  const fin = ok => { if (done) return; done = true; clearInterval(iv); clearTimeout(to); killTree(p); resolve(ok); };
  iv = setInterval(() => { try { const n = fs.statSync(out).size; if (n > 100 && n === last) { if (++stable >= 2) fin(true); } else { stable = 0; last = n; } } catch { /* pas encore écrit */ } }, 250);
  to = setTimeout(() => fin(false), timeoutMs);
  p.on('exit', () => setTimeout(() => { let ok = false; try { ok = fs.statSync(out).size > 100; } catch { /* absent */ } fin(ok); }, 150));
  p.on('error', () => fin(false));
});
const pngSize = b => b.length > 24 && b.readUInt32BE(0) === 0x89504e47 ? { w: b.readUInt32BE(16), h: b.readUInt32BE(20) } : null;
const isLocalHost = h => ['localhost', '127.0.0.1', '[::1]', '::1'].includes(String(h).toLowerCase());

// ── Modèles de projet ───────────────────────────────────────────────────────────────────
const TPL_DIR = path.join(__dirname, 'templates');
const TPL_DESC = { 'html-site': 'site vitrine HTML/CSS/JS (thème clair/sombre, formulaire)', 'html-game': 'mini-jeu 2D dans le navigateur (canvas, pièces à ramasser)', 'node-cli': 'outil en ligne de commande Node.js avec tests', 'node-api': 'API HTTP Node.js sans dépendance, avec tests', 'python-cli': 'outil en ligne de commande Python avec tests', 'godot-2d': 'projet Godot 4 (2D) avec un joueur déplaçable' };
const slugify = s => String(s).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 50) || 'projet';
const cleanTitle = s => String(s || '').replace(/[^\p{L}\p{N} _.'-]/gu, '').replace(/\s+/g, ' ').trim().slice(0, 60);
const listTpl = (dir, base = dir, out = []) => { for (const e of fs.readdirSync(dir, { withFileTypes: true })) { const p = path.join(dir, e.name); if (e.isDirectory()) listTpl(p, base, out); else out.push(path.relative(base, p).replace(/\\/g, '/')); } return out; };

// ── ZIP (écriture et lecture sans dépendance) ───────────────────────────────────────────
const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
const crc32 = buf => { let c = 0xFFFFFFFF; for (let i = 0; i < buf.length; i++) c = CRC[(c ^ buf[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };
const dosTime = d => { const y = Math.max(1980, d.getFullYear()); return { time: ((d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1)) & 0xFFFF, date: (((y - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate()) & 0xFFFF }; };
const ZIP_LIMITS = { entries: 20000, total: 500 * 1024 * 1024, file: 200 * 1024 * 1024 };
const buildZip = entries => {
  const chunks = [], central = []; let off = 0;
  for (const e of entries) {
    const nameB = Buffer.from(e.name, 'utf8'), dir = e.data === null, raw = dir ? Buffer.alloc(0) : e.data; let method = 0, body = raw;
    if (!dir && raw.length > 0) { const d = zlib.deflateRawSync(raw, { level: 6 }); if (d.length < raw.length) { method = 8; body = d; } }
    const crc = dir ? 0 : crc32(raw), { time, date } = dosTime(e.mtime || new Date());
    const lh = Buffer.alloc(30); lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(0x0800, 6); lh.writeUInt16LE(method, 8); lh.writeUInt16LE(time, 10); lh.writeUInt16LE(date, 12); lh.writeUInt32LE(crc, 14); lh.writeUInt32LE(body.length, 18); lh.writeUInt32LE(raw.length, 22); lh.writeUInt16LE(nameB.length, 26);
    chunks.push(lh, nameB, body);
    const ch = Buffer.alloc(46); ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(0x031E, 4); ch.writeUInt16LE(20, 6); ch.writeUInt16LE(0x0800, 8); ch.writeUInt16LE(method, 10); ch.writeUInt16LE(time, 12); ch.writeUInt16LE(date, 14); ch.writeUInt32LE(crc, 16); ch.writeUInt32LE(body.length, 20); ch.writeUInt32LE(raw.length, 24); ch.writeUInt16LE(nameB.length, 28);
    ch.writeUInt32LE((((dir ? 0o040755 : 0o100644) << 16) | (dir ? 0x10 : 0)) >>> 0, 38); ch.writeUInt32LE(off, 42);
    central.push(ch, nameB); off += 30 + nameB.length + body.length;
  }
  const cdSize = central.reduce((n, b) => n + b.length, 0), end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(entries.length, 8); end.writeUInt16LE(entries.length, 10); end.writeUInt32LE(cdSize, 12); end.writeUInt32LE(off, 16);
  return Buffer.concat([...chunks, ...central, end]);
};
const readZipDir = buf => {
  let i = buf.length - 22; const min = Math.max(0, buf.length - 65557);
  for (; i >= min; i--) if (buf.readUInt32LE(i) === 0x06054b50) break;
  if (i < min || i < 0) throw new Error('Archive ZIP invalide (fin de répertoire introuvable)');
  const n = buf.readUInt16LE(i + 10), cdOff = buf.readUInt32LE(i + 16);
  if (n === 0xFFFF || cdOff === 0xFFFFFFFF) throw new Error('ZIP64 non pris en charge');
  let p = cdOff; const out = [];
  for (let k = 0; k < n; k++) {
    if (p + 46 > buf.length || buf.readUInt32LE(p) !== 0x02014b50) throw new Error('Archive ZIP corrompue (répertoire central)');
    const flags = buf.readUInt16LE(p + 8), method = buf.readUInt16LE(p + 10), crc = buf.readUInt32LE(p + 16), csize = buf.readUInt32LE(p + 20), usize = buf.readUInt32LE(p + 24), nl = buf.readUInt16LE(p + 28), el = buf.readUInt16LE(p + 30), cl = buf.readUInt16LE(p + 32), attr = buf.readUInt32LE(p + 38), off = buf.readUInt32LE(p + 42);
    if (p + 46 + nl > buf.length) throw new Error('Archive ZIP corrompue (nom d’entrée)');
    out.push({ name: buf.toString(flags & 0x800 ? 'utf8' : 'latin1', p + 46, p + 46 + nl), flags, method, crc, csize, usize, attr, off });
    p += 46 + nl + el + cl;
  }
  return out;
};
const safeEntryName = name => {
  const n = String(name).replace(/\\/g, '/').replace(/^(\.\/)+/, '');
  if (!n || n.includes('\0') || /^\//.test(n) || /^[A-Za-z]:/.test(n) || n.length > 260) throw new Error('Entrée ZIP dangereuse refusée : ' + String(name).slice(0, 80));
  const segs = n.split('/').filter(Boolean);
  if (segs.some(x => x === '..')) throw new Error('Entrée ZIP dangereuse refusée (sortie du dossier) : ' + String(name).slice(0, 80));
  if (['.kairo', '.git'].includes(segs[0])) throw new Error('Entrée ZIP refusée (zone interne) : ' + n);
  return n;
};
const extractEntry = (buf, e) => {
  if (e.flags & 1) throw new Error('Archive chiffrée non prise en charge : ' + e.name);
  if (e.method !== 0 && e.method !== 8) throw new Error('Méthode de compression non prise en charge (' + e.method + ') : ' + e.name);
  if (e.off + 30 > buf.length || buf.readUInt32LE(e.off) !== 0x04034b50) throw new Error('Archive ZIP corrompue (en-tête local) : ' + e.name);
  const start = e.off + 30 + buf.readUInt16LE(e.off + 26) + buf.readUInt16LE(e.off + 28), raw = buf.subarray(start, start + e.csize);
  if (raw.length !== e.csize) throw new Error('Archive ZIP tronquée : ' + e.name);
  let data; try { data = e.method === 0 ? Buffer.from(raw) : zlib.inflateRawSync(raw, { maxOutputLength: e.usize + 1 }); } catch (err) { throw new Error('Décompression impossible (' + e.name + ') : ' + err.message); }
  if (data.length !== e.usize) throw new Error('Taille inattendue après décompression : ' + e.name);
  if (crc32(data) !== e.crc) throw new Error('Somme de contrôle incorrecte (fichier corrompu) : ' + e.name);
  return data;
};
const ZIP_SKIP = new Set(['node_modules', '.git', '.kairo', '__pycache__', '.venv', 'venv', '.godot', '.import']);

// ── Patch (diff unifié) ─────────────────────────────────────────────────────────────────
const patchPath = raw => { let p = String(raw).replace(/\t.*$/, '').trim(); if (p === '/dev/null') return null; p = p.replace(/^"(.*)"$/, '$1').replace(/^[ab]\//, ''); return p; };
const parsePatch = text => {
  const L = String(text).replace(/\r\n/g, '\n').split('\n'), files = []; let i = 0;
  while (i < L.length) {
    if (L[i].startsWith('--- ') && (L[i + 1] || '').startsWith('+++ ')) {
      const f = { old: patchPath(L[i].slice(4)), neu: patchPath(L[i + 1].slice(4)), hunks: [] }; i += 2;
      while (i < L.length && L[i].startsWith('@@')) {
        const m = /^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@/.exec(L[i]); if (!m) throw new Error('En-tête de bloc illisible : ' + L[i].slice(0, 80)); i++;
        let ro = m[2] === undefined ? 1 : +m[2], rn = m[4] === undefined ? 1 : +m[4]; const h = { oldStart: +m[1], body: [] };
        while (i < L.length && (ro > 0 || rn > 0 || (L[i] || '').startsWith('\\'))) {
          const l = L[i]; i++;
          if (l.startsWith('\\')) continue;
          const c = l === '' ? ' ' : l[0], t = l === '' ? '' : l.slice(1);
          if (c === ' ') { ro--; rn--; } else if (c === '-') ro--; else if (c === '+') rn--; else throw new Error('Ligne de patch invalide : ' + l.slice(0, 80));
          h.body.push([c, t]);
        }
        f.hunks.push(h);
      }
      files.push(f);
    } else i++;
  }
  return files;
};
const applyHunks = (content, hunks, reverse) => {
  const endsNl = content.endsWith('\n'), lines = content === '' ? [] : content.replace(/\n$/, '').split('\n'); let delta = 0;
  const results = [];
  for (const [hi, h] of hunks.entries()) {
    const body = reverse ? h.body.map(([c, t]) => [c === '+' ? '-' : c === '-' ? '+' : c, t]) : h.body;
    const oldL = body.filter(([c]) => c !== '+').map(([, t]) => t), newL = body.filter(([c]) => c !== '-').map(([, t]) => t);
    const base = (reverse ? 0 : h.oldStart) - 1 + delta, want = Math.max(0, oldL.length ? (reverse ? Math.max(0, h.oldStart - 1) : h.oldStart - 1) + delta : base);
    const at = (pos, loose) => { if (pos < 0 || pos + oldL.length > lines.length) return false; for (let k = 0; k < oldL.length; k++) { const a = lines[pos + k], b = oldL[k]; if (loose ? a.trimEnd() !== b.trimEnd() : a !== b) return false; } return true; };
    let found = -1, shift = 0;
    for (const loose of [false, true]) { for (let d = 0; d <= 200 && found < 0; d++) for (const s of d ? [-d, d] : [0]) if (at(want + s, loose)) { found = want + s; shift = s; break; } if (found >= 0) break; }
    if (found < 0 && oldL.length === 0) found = Math.min(lines.length, Math.max(0, h.oldStart)) ;
    if (found < 0) return { error: `bloc ${hi + 1} : le contenu attendu est introuvable (première ligne attendue : « ${(oldL[0] ?? '').slice(0, 80)} »)` };
    lines.splice(found, oldL.length, ...newL); delta += newL.length - oldL.length; results.push(shift);
  }
  return { text: lines.join('\n') + (lines.length && (endsNl || content === '') ? '\n' : ''), shifts: results };
};

module.exports = h => {
  const writeNew = async (c, rel, content) => { const p = path.join(c.root, rel); fs.mkdirSync(path.dirname(p), { recursive: true }); if (typeof content === 'string' && h.textFile(rel) && content.length < 1e6) await h.backup(c, p, '', content, false); fs.writeFileSync(p, content); c.created?.add(p); };
  return {
    // ─────────────── Serveur de développement ───────────────
    start_dev_server: {
      desc: 'Lance un serveur de développement en arrière-plan (reste actif après la commande) et attend qu’il soit prêt. Sans command : détecte le script dev/start/serve de package.json, sinon sert le dossier en statique (index.html). Max 3 serveurs. args:{command?, static?:false, port?, name?, ready?:"texte ou /regex/", timeout?:5-120 (défaut 30)}',
      run: async (a, c) => {
        if ([...SERVERS.values()].filter(s => !s.stopped && (s.kind === 'static' || s.exited === null || s.exited === undefined)).length >= MAX_SERVERS) throw new Error(MAX_SERVERS + ' serveurs maximum : arrête-en un avec stop_dev_server');
        const timeout = Math.min(120, Math.max(5, +a.timeout || 30)) * 1000; let port = a.port !== undefined && a.port !== '' ? portNum(a.port) : null;
        const ready = a.ready ? matcher(a.ready) : null; let command = String(a.command || '').trim() || null, kind = 'process';
        if (!command && !a.static) { command = detectDevCommand(c); if (!command) { if (exists(c, 'index.html')) kind = 'static'; else throw new Error('Aucun script dev/start/serve dans package.json et pas d’index.html : précise « command »'); } }
        if (a.static) kind = 'static', command = null;
        if (port && await portOpen(port)) throw new Error('Le port ' + port + ' est déjà utilisé');
        hook(); const id = 'srv' + (++seq), s = { id, name: a.name ? String(a.name).slice(0, 40) : '', kind, command, port, logs: '', started: Date.now(), exited: null, stopped: false };
        const log = t => { s.logs += (t.endsWith('\n') ? t : t + '\n'); if (s.logs.length > 100000) s.logs = s.logs.slice(-60000); };
        if (kind === 'static') {
          s.port = port || await freePort(8080); try { s.server = await staticServer(c.root, s.port, log); } catch (e) { throw new Error('Impossible de démarrer le serveur statique : ' + e.message); }
          SERVERS.set(id, s); log('Serveur statique sur http://127.0.0.1:' + s.port);
        } else {
          const env = { ...process.env, ...(port ? { PORT: String(port) } : {}), BROWSER: 'none', FORCE_COLOR: '0' };
          s.proc = spawn(command, { shell: true, cwd: c.root, env, windowsHide: true, detached: !WIN });
          s.proc.stdout.on('data', d => { const t = String(d); log(t); c.emit?.('term', { stream: 'stdout', text: t }); }); s.proc.stderr.on('data', d => { const t = String(d); log(t); c.emit?.('term', { stream: 'stderr', text: t }); });
          s.proc.on('error', e => { log(e.message); s.exited = -1; }); s.proc.on('close', k => { s.exited = k; });
          SERVERS.set(id, s);
        }
        const t0 = Date.now(); let isReady = kind === 'static';
        while (!isReady && Date.now() - t0 < timeout) {
          if (s.exited !== null) break;
          if (!s.port) { const m = /https?:\/\/(?:localhost|127\.0\.0\.1|\[::1\]|0\.0\.0\.0):(\d{2,5})/.exec(s.logs); if (m) s.port = +m[1]; }
          if (s.port && await portOpen(s.port)) isReady = true; else if (ready && ready(s.logs)) isReady = true;
          else if (!s.port && !ready && Date.now() - t0 > 4000) break;
          if (!isReady) await sleep(250);
        }
        if (s.exited !== null && !isReady) { const rep = traceReport(s.logs, c.root); SERVERS.delete(id); throw new Error(`Le serveur s’est arrêté (code ${s.exited}) avant d’être prêt.\n${rep ? rep + '\n\n' : ''}Sortie :\n${logTail(s, 2500)}`); }
        const url = s.port ? 'http://127.0.0.1:' + s.port : null;
        return `Serveur ${id} ${isReady ? 'prêt' : 'lancé (pas encore confirmé prêt)'}${url ? ' : ' + url : ''}${kind === 'static' ? ' (fichiers du projet, en statique)' : '\nCommande : ' + command}\nUtilise screenshot_page pour voir la page, check_port (logs:true) pour lire sa sortie, stop_dev_server pour l’arrêter.\n--- sortie ---\n${logTail(s, 1500)}`;
      },
    },
    stop_dev_server: {
      desc: 'Arrête un serveur lancé par start_dev_server et renvoie la fin de sa sortie. args:{id? | port? | all?:true}',
      run: async a => {
        if (a.all) { const n = SERVERS.size; killAll(); return n ? n + ' serveur(s) arrêté(s).' : 'Aucun serveur à arrêter.'; }
        let s = findServer(a);
        if (!s) { const live = [...SERVERS.values()]; if (live.length === 1) s = live[0]; else if (!live.length) return 'Aucun serveur lancé par l’agent.'; else throw new Error('Plusieurs serveurs actifs : précise id, port ou all.\n' + live.map(describe).join('\n')); }
        stopServer(s); SERVERS.delete(s.id); return `Serveur ${s.id} arrêté.\n--- fin de sa sortie ---\n${logTail(s, 2000)}`;
      },
    },
    check_port: {
      desc: 'Indique si un port local écoute et à quel serveur de l’agent il correspond. Sans port : liste les serveurs de l’agent. args:{port?, logs?:false (true = fin de la sortie du serveur), lines?}',
      run: async a => {
        if (a.port === undefined || a.port === '') return SERVERS.size ? 'Serveurs lancés par l’agent :\n' + [...SERVERS.values()].map(describe).join('\n') : 'Aucun serveur lancé par l’agent.';
        const p = portNum(a.port), open = await portOpen(p), s = [...SERVERS.values()].find(x => x.port === p);
        let out = `Port ${p} : ${open ? 'ouvert (un programme écoute)' : 'fermé (personne n’écoute)'}${s ? '\nServeur de l’agent : ' + describe(s) : open ? '\nCe n’est pas un serveur lancé par l’agent.' : ''}`;
        if (a.logs && s) out += '\n--- sortie ---\n' + logTail(s, Math.min(8000, Math.max(200, (+a.lines || 30) * 120)));
        return out;
      },
    },
    screenshot_page: {
      desc: 'Prend une capture d’une page web (navigateur Edge/Chrome sans interface) et la décrit sous forme exploitable sans vision. Enregistrée dans .kairo/screenshots. args:{url? (http://localhost:… ) | path? (fichier .html du projet), width?:320-3840 (1280), height?:200-3000 (800), wait?:0-10000 ms (1500), name?}',
      run: async (a, c) => {
        let target;
        if (a.path) { const rel = relPath(a.path, c); if (!/\.html?$/i.test(rel)) throw new Error('path doit être un fichier .html'); const abs = path.join(c.root, rel); if (!fs.existsSync(abs)) throw new Error('Fichier inexistant : ' + rel); target = pathToFileURL(abs).href; }
        else { let u; try { u = new URL(String(a.url || '')); } catch { throw new Error('url invalide (exemple : http://localhost:3000)'); } if (!/^https?:$/.test(u.protocol)) throw new Error('Seules les adresses http(s) sont autorisées'); if (u.username || u.password) throw new Error('Adresse avec identifiants refusée'); target = u.href; }
        const browser = findBrowser(); if (!browser) throw new Error('Aucun navigateur trouvé (Edge, Chrome ou Chromium). Installe-en un, ou indique son chemin dans la variable ASTRA_BROWSER.');
        const w = Math.min(3840, Math.max(320, +a.width || 1280)), hh = Math.min(3000, Math.max(200, +a.height || 800)), wait = Math.min(10000, Math.max(0, a.wait === undefined ? 1500 : +a.wait));
        const dir = path.join(c.root, '.kairo', 'screenshots'); fs.mkdirSync(dir, { recursive: true });
        const name = (a.name ? slugify(a.name) : 'page-' + Date.now().toString(36)) + '.png', out = path.join(dir, name);
        const base = ['--disable-gpu', '--hide-scrollbars', '--force-device-scale-factor=1', '--no-first-run', '--no-default-browser-check', '--window-size=' + w + ',' + hh, ...(process.getuid && process.getuid() === 0 ? ['--no-sandbox', '--disable-dev-shm-usage'] : [])];
        // Les navigateurs sans interface se comportent différemment selon les versions : on essaie plusieurs réglages, le premier qui produit l'image gagne.
        const attempts = [...(wait > 0 ? [['--headless=new', '--virtual-time-budget=' + (wait + 500)]] : []), ['--headless=new'], ['--headless=new'], ['--headless=old'], ['--headless=new']];
        let r = { status: null, stderr: '' };
        for (const extra of attempts) {
          try { fs.rmSync(out, { force: true }); } catch { /* ignoré */ }
          const prof = fs.mkdtempSync(path.join(os.tmpdir(), 'astra-shot-'));
          const ok = await shoot(browser, [...extra, ...base, '--user-data-dir=' + prof, '--screenshot=' + out, target], out, 6000 + wait);
          try { fs.rmSync(prof, { recursive: true, force: true }); } catch { /* ignoré */ }
          if (ok) break;
        }
        if (!fs.existsSync(out) || fs.statSync(out).size < 100) throw new Error('Aucune capture produite : le navigateur n’a pas répondu (plusieurs essais). Vérifie que la page s’ouvre dans ton navigateur.');
        const buf = fs.readFileSync(out), sz = pngSize(buf); let desc = '';
        try { desc = (await require('./imagecodec').prepare(buf, { name, size: 64, encoding: 'auto', maxChars: c.imageBudget || 4500, lite: true })).text; } catch { /* la capture reste enregistrée */ }
        return `Capture enregistrée : .kairo/screenshots/${name}${sz ? ' (' + sz.w + '×' + sz.h + ')' : ''}\n` + (desc ? '--- aperçu de la page ---\n' + desc : '');
      },
    },

    // ─────────────── Projet ───────────────
    scaffold_project: {
      desc: 'Crée un projet de départ à partir d’un modèle : html-site, html-game, node-cli, node-api, python-cli, godot-2d. Ne remplace jamais un fichier existant (sauf force:true). args:{template, name?, path? (dossier cible, défaut : un dossier au nom du projet), force?:false}',
      run: async (a, c) => {
        const t = String(a.template || '').trim();
        if (!TPL_DESC[t]) throw new Error('Modèle inconnu : « ' + t + ' ». Modèles : ' + Object.entries(TPL_DESC).map(([k, v]) => k + ' (' + v + ')').join(' ; '));
        const title = cleanTitle(a.name) || 'Mon projet', slug = slugify(title), target = relPath(a.path || (a.name ? slug : '.'), c), base = path.join(c.root, target);
        const files = listTpl(path.join(TPL_DIR, t)), fill = s => s.replace(/\{\{title\}\}/g, title).replace(/\{\{slug\}\}/g, slug);
        const conflicts = files.filter(f => fs.existsSync(path.join(base, f)));
        if (conflicts.length && !a.force) throw new Error('Fichiers déjà présents (rien n’a été écrit) : ' + conflicts.join(', ') + '. Choisis un autre dossier (path) ou utilise force:true.');
        for (const f of files) { const rel = path.join(target === '.' ? '' : target, f).replace(/\\/g, '/'); await writeNew(c, rel, fill(fs.readFileSync(path.join(TPL_DIR, t, f), 'utf8'))); }
        const run = { 'html-site': 'start_dev_server (statique) puis screenshot_page', 'html-game': 'start_dev_server (statique) puis ouvre la page', 'node-cli': 'npm start / npm test', 'node-api': 'npm start / npm test', 'python-cli': 'python main.py / python -m unittest discover -s tests', 'godot-2d': 'ouvre le dossier dans Godot 4 puis F5' }[t];
        return `Modèle « ${t} » créé dans ${target === '.' ? 'le dossier du projet' : target + '/'} (${files.length} fichiers) :\n` + files.map(f => '  ' + f).join('\n') + '\nÉtape suivante : ' + run;
      },
    },
    generate_tests: {
      desc: 'Génère un fichier de tests de départ pour un fichier source JavaScript (node:test) ou Python (unittest) : vérifie que chaque fonction/classe est bien exportée et laisse des cas à compléter. Ne remplace pas un fichier existant (sauf force:true). args:{path, force?:false}',
      run: async (a, c) => {
        const rel = relPath(a.path, c), abs = path.join(c.root, rel); if (!fs.existsSync(abs) || fs.statSync(abs).isDirectory()) throw new Error('Fichier inexistant : ' + rel);
        const src = fs.readFileSync(abs, 'utf8'), ext = path.extname(rel).toLowerCase(), base = path.basename(rel, ext);
        let outRel, body, names;
        if (['.js', '.mjs', '.cjs'].includes(ext)) {
          const esm = ext === '.mjs' || /^\s*(export|import)\s/m.test(src) || (() => { try { return JSON.parse(fs.readFileSync(path.join(c.root, 'package.json'), 'utf8')).type === 'module'; } catch { return false; } })();
          const set = new Set(), add = n => { if (/^[\p{L}_$][\p{L}\p{N}_$]*$/u.test(n) && n !== 'default') set.add(n); };
          for (const m of src.matchAll(/(?:module\.)?exports\.([\w$]+)\s*=/g)) add(m[1]);
          for (const m of src.matchAll(/module\.exports\s*=\s*\{([^}]*)\}/g)) m[1].split(',').forEach(x => add(x.split(':')[0].trim()));
          for (const m of src.matchAll(/export\s+(?:async\s+)?(?:function\*?|class|const|let|var)\s+([\w$]+)/g)) add(m[1]);
          for (const m of src.matchAll(/export\s*\{([^}]*)\}/g)) m[1].split(',').forEach(x => add(x.trim().split(/\s+as\s+/).pop()));
          if (!set.size) for (const m of src.matchAll(/^(?:async\s+)?function\*?\s+([\w$]+)|^(?:const|let)\s+([\w$]+)\s*=\s*(?:async\s*)?(?:\([^)]*\)|[\w$]+)\s*=>/gm)) add(m[1] || m[2]);
          names = [...set]; if (!names.length) throw new Error('Aucune fonction ni classe exportée trouvée dans ' + rel);
          const testRel = 'tests/' + base + '.test.' + (ext === '.mjs' ? 'mjs' : 'js'), relImport = path.relative(path.join(c.root, 'tests'), abs).replace(/\\/g, '/'), imp = relImport.startsWith('.') ? relImport : './' + relImport;
          outRel = testRel; body = [esm ? "import test from 'node:test';\nimport assert from 'node:assert/strict';\nimport * as lib from '" + imp + "';" : "const test = require('node:test');\nconst assert = require('node:assert/strict');\nconst lib = require('" + imp + "');", '',
            ...names.flatMap(n => { const esc = n.replace(/\$/g, '\\$'), fn = new RegExp('(?:function\\*?\\s+|class\\s+)' + esc + '(?![\\w$])|(?<![\\w$.])' + esc + '\\s*[:=]\\s*(?:async\\s*)?(?:function\\b|\\([^)]*\\)\\s*=>|[\\w$]+\\s*=>|class\\b)').test(src); return fn ? [`test('${n} est exporté et appelable', () => {\n  assert.equal(typeof lib.${n}, 'function');\n});`, `test.todo('${n} : cas nominal');`, `test.todo('${n} : cas limites et erreurs');`, ''] : [`test('${n} est exporté', () => {\n  assert.notEqual(typeof lib.${n}, 'undefined');\n});`, '']; })].join('\n');
        } else if (ext === '.py') {
          if (!/^[A-Za-z_]\w*$/.test(base)) throw new Error('Nom de module Python invalide pour un import : ' + base);
          names = [...src.matchAll(/^(?:async\s+)?def\s+([A-Za-z]\w*)\s*\(|^class\s+([A-Za-z]\w*)/gm)].map(m => m[1] || m[2]).filter(n => !n.startsWith('_'));
          if (!names.length) throw new Error('Aucune fonction ni classe publique trouvée dans ' + rel);
          outRel = 'tests/test_' + base + '.py'; const up = path.relative(path.join(c.root, 'tests'), path.dirname(abs)).replace(/\\/g, '/') || '.';
          body = ['import os', 'import sys', 'import unittest', '', 'sys.path.insert(0, os.path.join(os.path.dirname(__file__), "' + up + '"))', 'import ' + base + ' as module  # noqa: E402', '', '', 'class ' + base.replace(/(^|_)(\w)/g, (_, __, ch) => ch.toUpperCase()) + 'Tests(unittest.TestCase):',
            ...names.flatMap(n => [`    def test_${n}_existe(self):`, `        self.assertTrue(callable(module.${n}))`, '', `    @unittest.skip("à compléter : cas nominal et limites de ${n}")`, `    def test_${n}_cas(self):`, '        pass', '']), '', 'if __name__ == "__main__":', '    unittest.main()', ''].join('\n');
        } else throw new Error('Type non pris en charge (js, mjs, cjs, py). Pour TypeScript, utilise Vitest ou Jest.');
        if (fs.existsSync(path.join(c.root, outRel)) && !a.force) throw new Error('Le fichier de tests existe déjà : ' + outRel + ' (force:true pour le remplacer)');
        const p = path.join(c.root, outRel), existed = fs.existsSync(p), before = existed ? fs.readFileSync(p, 'utf8') : '';
        fs.mkdirSync(path.dirname(p), { recursive: true }); await h.backup(c, p, before, body, existed); fs.writeFileSync(p, body); c.created?.add(p);
        return `Tests créés : ${outRel} (${names.length} élément(s) : ${names.slice(0, 12).join(', ')}${names.length > 12 ? '…' : ''}).\nLes cas « todo / skip » restent à compléter avec edit_file ; lance-les avec run_tests ou run_with_trace.`;
      },
    },
    create_readme: {
      desc: 'Génère un README.md en français à partir du projet (package.json, pyproject, Godot…) : description, installation, utilisation, tests, structure. Ne remplace pas un README existant (sauf force:true). args:{title?, description?, path? (dossier), force?:false}',
      run: async (a, c) => {
        const dir = relPath(a.path || '.', c), base = path.join(c.root, dir), out = path.join(dir === '.' ? '' : dir, 'README.md').replace(/\\/g, '/');
        if (fs.existsSync(path.join(c.root, out)) && !a.force) throw new Error('README.md existe déjà (force:true pour le remplacer ; l’ancienne version reste dans .kairo/backups)');
        const has = f => fs.existsSync(path.join(base, f)); let pkg = {}; try { pkg = JSON.parse(fs.readFileSync(path.join(base, 'package.json'), 'utf8')); } catch { /* pas de package.json */ }
        const godot = has('project.godot') ? (/config\/name="([^"]*)"/.exec(fs.readFileSync(path.join(base, 'project.godot'), 'utf8')) || [])[1] : null;
        const title = cleanTitle(a.title) || pkg.name || godot || path.basename(base), desc = String(a.description || pkg.description || '').trim() || 'À compléter : décris en une ou deux phrases ce que fait le projet.';
        const sc = pkg.scripts || {}, pm = has('pnpm-lock.yaml') ? 'pnpm' : has('yarn.lock') ? 'yarn' : 'npm', run = n => pm === 'yarn' ? 'yarn ' + n : pm + (n === 'start' || n === 'test' ? ' ' + n : ' run ' + n);
        const tech = [has('package.json') && 'Node.js', has('requirements.txt') || has('pyproject.toml') || fs.readdirSync(base).some(f => f.endsWith('.py')) ? 'Python' : null, godot !== null && godot !== undefined || has('project.godot') ? 'Godot 4' : null, has('index.html') && !has('package.json') ? 'HTML/CSS/JavaScript' : null].filter(Boolean);
        const L = ['# ' + title, '', desc, ''];
        if (tech.length) L.push('**Technologies :** ' + tech.join(', '), '');
        L.push('## Prérequis', '');
        if (has('package.json')) L.push('- [Node.js](https://nodejs.org) (version LTS récente)');
        if (tech.includes('Python')) L.push('- [Python](https://www.python.org) 3.10 ou plus');
        if (has('project.godot')) L.push('- [Godot](https://godotengine.org) 4.x');
        if (!has('package.json') && !tech.includes('Python') && !has('project.godot')) L.push('- Un navigateur web récent');
        L.push('', '## Installation', '');
        if (has('package.json')) L.push('```bash', pm + ' install', '```'); else if (has('requirements.txt')) L.push('```bash', 'pip install -r requirements.txt', '```'); else if (has('project.godot')) L.push('Ouvre ce dossier avec Godot (« Importer ») puis lance la scène principale avec F5.'); else L.push('Aucune installation nécessaire : ouvre `index.html` dans ton navigateur (ou sers le dossier avec un petit serveur local).');
        L.push('', '## Utilisation', '');
        const useCmds = ['dev', 'start', 'build'].filter(k => sc[k]); if (useCmds.length) L.push('```bash', ...useCmds.map(k => run(k) + '   # ' + String(sc[k]).slice(0, 70)), '```'); else if (has('main.py')) L.push('```bash', 'python main.py', '```'); else L.push('À compléter.');
        L.push('', '## Tests', ''); if (sc.test) L.push('```bash', run('test'), '```'); else if (has('tests') && fs.readdirSync(path.join(base, 'tests')).some(f => f.endsWith('.py'))) L.push('```bash', 'python -m unittest discover -s tests', '```'); else L.push('Pas encore de tests.');
        const tree = []; const walk = (d, pre, depth) => { let ents; try { ents = fs.readdirSync(d, { withFileTypes: true }); } catch { return; } ents = ents.filter(e => !SKIP_DIRS.has(e.name) && !e.name.startsWith('.') && !e.isSymbolicLink()).sort((x, y) => (y.isDirectory() - x.isDirectory()) || x.name.localeCompare(y.name)).slice(0, 25); for (const e of ents) { tree.push(pre + e.name + (e.isDirectory() ? '/' : '')); if (e.isDirectory() && depth < 2) walk(path.join(d, e.name), pre + '  ', depth + 1); } };
        walk(base, '', 1); if (tree.length) L.push('', '## Structure du projet', '', '```', ...tree.slice(0, 60), '```');
        if (has('LICENSE')) L.push('', '## Licence', '', 'Voir le fichier `LICENSE`.');
        const text = L.join('\n') + '\n', p = path.join(c.root, out), existed = fs.existsSync(p), before = existed ? fs.readFileSync(p, 'utf8') : '';
        await h.backup(c, p, before, text, existed); fs.writeFileSync(p, text); c.created?.add(p);
        return `README créé : ${out} (${text.split('\n').length} lignes). Relis-le et complète la description avec edit_file.`;
      },
    },

    // ─────────────── Fichiers ───────────────
    zip_files: {
      desc: 'Crée une archive .zip de fichiers/dossiers du projet (ignore node_modules, .git, .kairo, .env). Ne remplace pas une archive existante (sauf force:true). args:{paths:["dossier","fichier"], output?:"archive.zip", force?:false}',
      run: async (a, c) => {
        const list = Array.isArray(a.paths) ? a.paths : a.paths ? [a.paths] : []; if (!list.length) throw new Error('paths vide : indique les fichiers ou dossiers à archiver');
        const outRel = relPath(a.output || 'archive.zip', c); if (!/\.zip$/i.test(outRel)) throw new Error('output doit se terminer par .zip');
        const outAbs = path.join(c.root, outRel); if (fs.existsSync(outAbs) && !a.force) throw new Error('Cette archive existe déjà : ' + outRel + ' (force:true pour la remplacer)');
        const entries = [], seen = new Set(); let total = 0, excluded = 0;
        const addFile = (abs, name) => {
          if (abs === outAbs || seen.has(name)) return; const st = fs.lstatSync(abs); if (st.isSymbolicLink() || !st.isFile()) return;
          if (/^\.env(\.|$)/i.test(path.basename(abs))) { excluded++; return; }
          if (st.size > ZIP_LIMITS.file) throw new Error('Fichier trop gros (' + Math.round(st.size / 1048576) + ' Mo) : ' + name);
          total += st.size; if (total > ZIP_LIMITS.total) throw new Error('Archive trop volumineuse (limite ' + ZIP_LIMITS.total / 1048576 + ' Mo)');
          if (entries.length >= ZIP_LIMITS.entries) throw new Error('Trop de fichiers (limite ' + ZIP_LIMITS.entries + ')');
          seen.add(name); entries.push({ name, data: fs.readFileSync(abs), mtime: st.mtime });
        };
        const walk = (abs, name) => { const st = fs.lstatSync(abs); if (st.isSymbolicLink()) return; if (st.isDirectory()) { if (ZIP_SKIP.has(path.basename(abs)) && name.includes('/')) return; for (const e of fs.readdirSync(abs).sort()) { if (ZIP_SKIP.has(e)) continue; walk(path.join(abs, e), name + '/' + e); } } else addFile(abs, name); };
        for (const raw of list) { const rel = relPath(raw, c), abs = path.join(c.root, rel); if (!fs.existsSync(abs)) throw new Error('Chemin inexistant : ' + raw); if (rel === '.') { for (const e of fs.readdirSync(abs).sort()) if (!ZIP_SKIP.has(e)) walk(path.join(abs, e), e); } else walk(abs, rel.replace(/\\/g, '/')); }
        if (!entries.length) throw new Error('Rien à archiver (dossiers vides ou fichiers exclus)');
        const buf = buildZip(entries); fs.mkdirSync(path.dirname(outAbs), { recursive: true }); fs.writeFileSync(outAbs, buf); c.created?.add(outAbs);
        return `Archive créée : ${outRel} — ${entries.length} fichier(s), ${(total / 1024).toFixed(0)} Ko → ${(buf.length / 1024).toFixed(0)} Ko${excluded ? '\n' + excluded + ' fichier(s) .env exclu(s) par sécurité.' : ''}`;
      },
    },
    unzip_files: {
      desc: 'Extrait une archive .zip du projet dans un dossier du projet. Refuse les entrées dangereuses (../, chemins absolus), ne remplace jamais un fichier existant. args:{path, dest? (défaut : dossier au nom de l’archive)}',
      run: async (a, c) => {
        const rel = relPath(a.path, c), abs = path.join(c.root, rel); if (!fs.existsSync(abs) || fs.statSync(abs).isDirectory()) throw new Error('Archive inexistante : ' + rel);
        if (fs.statSync(abs).size > ZIP_LIMITS.total) throw new Error('Archive trop volumineuse');
        const destRel = relPath(a.dest || path.join(path.dirname(rel), path.basename(rel, path.extname(rel))), c), destAbs = path.join(c.root, destRel), buf = fs.readFileSync(abs), list = readZipDir(buf);
        if (list.length > ZIP_LIMITS.entries) throw new Error('Trop d’entrées dans l’archive (limite ' + ZIP_LIMITS.entries + ')');
        let total = 0; const plan = [];
        for (const e of list) {
          const name = safeEntryName(e.name), dir = name.endsWith('/'); total += e.usize;
          if (e.usize > ZIP_LIMITS.file || total > ZIP_LIMITS.total) throw new Error('Contenu trop volumineux une fois décompressé (limite ' + ZIP_LIMITS.total / 1048576 + ' Mo) : archive refusée');
          if (((e.attr >>> 16) & 0o170000) === 0o120000) continue;
          const target = path.join(destAbs, name); if (!perms.inside(target, destAbs) || !perms.inside(target, c.root)) throw new Error('Entrée ZIP dangereuse refusée : ' + e.name);
          plan.push({ e, name, dir, target });
        }
        const conflicts = plan.filter(x => !x.dir && fs.existsSync(x.target)).map(x => path.relative(c.root, x.target).replace(/\\/g, '/'));
        if (conflicts.length) throw new Error(conflicts.length + ' fichier(s) existent déjà (rien n’a été extrait) : ' + conflicts.slice(0, 8).join(', ') + (conflicts.length > 8 ? '…' : '') + '. Choisis un autre dossier (dest).');
        const datas = plan.map(x => x.dir ? null : extractEntry(buf, x.e));
        let n = 0; for (const [i, x] of plan.entries()) { if (x.dir) { fs.mkdirSync(x.target, { recursive: true }); continue; } const r = path.relative(c.root, x.target).replace(/\\/g, '/'); await writeNew(c, r, h.textFile(r) && datas[i].length < 1e6 ? datas[i].toString('utf8') : datas[i]); n++; }
        return `Extrait dans ${destRel}/ : ${n} fichier(s), ${(total / 1024).toFixed(0)} Ko.`;
      },
    },
    patch_apply: {
      desc: 'Applique un patch au format diff unifié (celui de « git diff » ou « diff -u ») : plusieurs fichiers, création de fichiers, tolérance aux décalages de lignes. Tout ou rien : si un bloc ne correspond pas, rien n’est modifié. args:{patch, check?:false (true = vérifier sans appliquer), reverse?:false (true = annuler le patch)}',
      run: async (a, c) => {
        const text = String(a.patch || ''); if (!text.trim()) throw new Error('patch vide'); if (text.length > 1e6) throw new Error('patch trop gros (1 Mo maximum)');
        const files = parsePatch(text); if (!files.length) throw new Error('Aucun fichier reconnu : le patch doit être au format diff unifié (--- / +++ / @@)'); if (files.length > 100) throw new Error('Trop de fichiers (100 maximum)');
        const reverse = !!a.reverse, plan = [], errors = [];
        for (const f of files) {
          let from = reverse ? f.neu : f.old, to = reverse ? f.old : f.neu;
          if (to === null) { errors.push((from || '?') + ' : la suppression de fichier par patch n’est pas prise en charge (utilise delete_file)'); continue; }
          let rel; try { rel = relPath(to, c); } catch (e) { errors.push(to + ' : ' + e.message); continue; }
          if (/^(\.kairo|\.git)([\\/]|$)/.test(rel)) { errors.push(rel + ' : zone interne refusée'); continue; }
          const abs = path.join(c.root, rel), creating = from === null;
          if (creating) { if (fs.existsSync(abs)) { errors.push(rel + ' : le fichier existe déjà (le patch veut le créer)'); continue; } const r = applyHunks('', f.hunks, reverse); if (r.error) errors.push(rel + ' : ' + r.error); else plan.push({ rel, abs, before: '', after: r.text, created: true, shifts: r.shifts }); continue; }
          if (!fs.existsSync(abs) || fs.statSync(abs).isDirectory()) { errors.push(rel + ' : fichier inexistant'); continue; }
          let before; try { before = fs.readFileSync(abs, 'utf8'); } catch { errors.push(rel + ' : lecture impossible'); continue; }
          if (before.includes('\0')) { errors.push(rel + ' : fichier binaire non pris en charge'); continue; }
          const r = applyHunks(before.replace(/\r\n/g, '\n'), f.hunks, reverse); if (r.error) errors.push(rel + ' : ' + r.error); else plan.push({ rel, abs, before, after: before.includes('\r\n') ? r.text.replace(/\n/g, '\r\n') : r.text, shifts: r.shifts });
        }
        if (errors.length) throw new Error('Patch non appliqué (aucun fichier modifié) :\n' + errors.map(e => '  - ' + e).join('\n'));
        const sum = plan.map(p => `  ${p.created ? '+' : '~'} ${p.rel} (${p.shifts.length} bloc(s)${p.shifts.some(s => s) ? ', décalé de ' + p.shifts.filter(s => s).join('/') + ' ligne(s)' : ''})`).join('\n');
        if (a.check) return 'Le patch s’applique proprement à ' + plan.length + ' fichier(s) :\n' + sum;
        for (const p of plan) { fs.mkdirSync(path.dirname(p.abs), { recursive: true }); await h.backup(c, p.abs, p.before, p.after, !p.created); fs.writeFileSync(p.abs, p.after); c.created?.add(p.abs); }
        return (reverse ? 'Patch annulé' : 'Patch appliqué') + ' sur ' + plan.length + ' fichier(s) (sauvegardes dans .kairo/backups) :\n' + sum;
      },
    },
  };
};

module.exports.META = {
  start_dev_server: ['Serveur', 'variable'], stop_dev_server: ['Serveur', 'SAFE'], check_port: ['Serveur', 'SAFE'], screenshot_page: ['Serveur', 'CONFIRM'],
  scaffold_project: ['Projet', 'CONFIRM'], generate_tests: ['Projet', 'CONFIRM'], create_readme: ['Projet', 'CONFIRM'],
  zip_files: ['Fichiers', 'CONFIRM'], unzip_files: ['Fichiers', 'CONFIRM'], patch_apply: ['Fichiers', 'CONFIRM'],
};
module.exports.killAllServers = killAll;
module.exports.buildZip = buildZip; module.exports.readZipDir = readZipDir; module.exports.extractEntry = extractEntry; module.exports.safeEntryName = safeEntryName; module.exports.crc32 = crc32;
module.exports.parsePatch = parsePatch; module.exports.applyHunks = applyHunks; module.exports.findBrowser = findBrowser; module.exports.slugify = slugify; module.exports.TEMPLATES = Object.keys(TPL_DESC);
