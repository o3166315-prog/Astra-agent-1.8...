// Vision Lite : analyse réelle des pixels d'une capture PNG (décodeur PNG maison, aucune dépendance) -> description textuelle compacte
// pour les modèles sans vision. Pipeline : PNG -> pixels -> grille 8x8 -> fond -> composants colorés -> blocs de texte -> OCR (tesseract si présent) -> texte.
const zlib=require('zlib'),fs=require('fs'),os=require('os'),path=require('path'),{execFile}=require('child_process');
const CS=8,dist=(a,b)=>Math.abs(a[0]-b[0])+Math.abs(a[1]-b[1])+Math.abs(a[2]-b[2]);
function decode(b){if(b.readUInt32BE(0)!==0x89504e47)throw new Error('PNG invalide');let p=8,w,h,bd,ct,il,pal,trns;const id=[];
 while(p+8<=b.length){const len=b.readUInt32BE(p),ty=b.toString('ascii',p+4,p+8),d=b.subarray(p+8,p+8+len);if(ty==='IHDR'){w=d.readUInt32BE(0);h=d.readUInt32BE(4);bd=d[8];ct=d[9];il=d[12]}else if(ty==='PLTE')pal=d;else if(ty==='tRNS')trns=d;else if(ty==='IDAT')id.push(d);p+=12+len}
 if(il)throw new Error('PNG entrelacé non supporté');const ch={0:1,2:3,3:1,4:2,6:4}[ct];if(!ch)throw new Error('type PNG '+ct+' non supporté');
 const raw=zlib.inflateSync(Buffer.concat(id)),rb=Math.ceil(w*ch*bd/8),bpp=Math.max(1,Math.ceil(ch*bd/8)),o=Buffer.alloc(rb*h);
 for(let y=0;y<h;y++){const f=raw[y*(rb+1)],s=y*(rb+1)+1,r=y*rb;for(let x=0;x<rb;x++){const a=x>=bpp?o[r+x-bpp]:0,u=y?o[r-rb+x]:0,c=x>=bpp&&y?o[r-rb+x-bpp]:0;let v=raw[s+x];
  if(f===1)v+=a;else if(f===2)v+=u;else if(f===3)v+=(a+u)>>1;else if(f===4){const pp=a+u-c,pa=Math.abs(pp-a),pb=Math.abs(pp-u),pc=Math.abs(pp-c);v+=pa<=pb&&pa<=pc?a:pb<=pc?u:c}o[r+x]=v&255}}
 const smp=(y,x,c)=>{if(bd===8)return o[y*rb+x*ch+c];if(bd===16)return o[y*rb+(x*ch+c)*2];const per=8/bd,i=x*ch+c;return(o[y*rb+Math.floor(i/per)]>>(8-bd-(i%per)*bd))&((1<<bd)-1)};
 const rgb=new Uint8Array(w*h*3),a=(ct===4||ct===6||(ct===3&&trns))?new Uint8Array(w*h).fill(255):null;for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*3;if(a)a[y*w+x]=ct===6?smp(y,x,3):ct===4?smp(y,x,1):(trns[smp(y,x,0)]??255);if(ct===2||ct===6){rgb[i]=smp(y,x,0);rgb[i+1]=smp(y,x,1);rgb[i+2]=smp(y,x,2)}else if(ct===3){const k=smp(y,x,0);rgb[i]=pal[k*3];rgb[i+1]=pal[k*3+1];rgb[i+2]=pal[k*3+2]}else{let g=smp(y,x,0);if(bd<8)g=Math.round(g*255/((1<<bd)-1));rgb[i]=rgb[i+1]=rgb[i+2]=g}}
 return{w,h,rgb,a}}
const crcT=(()=>{const t=[];for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=c&1?0xedb88320^(c>>>1):c>>>1;t[n]=c>>>0}return t})(),crc=b=>{let c=-1;for(const x of b)c=crcT[(c^x)&255]^(c>>>8);return(~c)>>>0};
const chunk=(t,d)=>{const l=Buffer.alloc(4);l.writeUInt32BE(d.length);const td=Buffer.concat([Buffer.from(t),d]),c=Buffer.alloc(4);c.writeUInt32BE(crc(td));return Buffer.concat([l,td,c])};
const encodeGray=(w,h,g)=>{const raw=Buffer.alloc((w+1)*h);for(let y=0;y<h;y++)Buffer.from(g.buffer,g.byteOffset+y*w,w).copy(raw,y*(w+1)+1);const ih=Buffer.alloc(13);ih.writeUInt32BE(w,0);ih.writeUInt32BE(h,4);ih[8]=8;ih[9]=0;
 return Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),chunk('IHDR',ih),chunk('IDAT',zlib.deflateSync(raw)),chunk('IEND',Buffer.alloc(0))])};
const encodeRGB=(w,h,rgb)=>{const raw=Buffer.alloc((w*3+1)*h);for(let y=0;y<h;y++)Buffer.from(rgb.buffer,rgb.byteOffset+y*w*3,w*3).copy(raw,y*(w*3+1)+1);const ih=Buffer.alloc(13);ih.writeUInt32BE(w,0);ih.writeUInt32BE(h,4);ih[8]=8;ih[9]=2;
 return Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),chunk('IHDR',ih),chunk('IDAT',zlib.deflateSync(raw)),chunk('IEND',Buffer.alloc(0))])};
// recadre une capture (haut-gauche) à W x H maximum
const crop=(buf,W,H)=>{const i=decode(buf);if(i.w<=W&&i.h<=H)return buf;const w=Math.min(W,i.w),h=Math.min(H,i.h),o=new Uint8Array(w*h*3);for(let y=0;y<h;y++)o.set(i.rgb.subarray(y*i.w*3,y*i.w*3+w*3),y*w*3);return encodeRGB(w,h,o)};
const name=(r,g,b)=>{const mx=Math.max(r,g,b),mn=Math.min(r,g,b),v=mx/255,s=mx?(mx-mn)/mx:0;let hu=0;if(mx!==mn){const d=mx-mn;hu=(mx===r?(g-b)/d+(g<b?6:0):mx===g?(b-r)/d+2:(r-g)/d+4)*60}
 if(v<0.16)return'black';if(s<0.14)return v>0.88?'white':v>0.62?'light gray':v>0.35?'gray':'dark gray';
 let n=hu<15||hu>=345?'red':hu<40?'orange':hu<70?'yellow':hu<165?'green':hu<200?'cyan':hu<260?'blue':hu<300?'purple':'pink';if(n==='orange'&&v<0.6)n='brown';return(v<0.42?'dark ':v>0.88&&s<0.5?'light ':'')+n};
const LET={black:'K',white:'W',red:'R',orange:'O',yellow:'Y',green:'G',cyan:'C',blue:'B',purple:'P',pink:'M',brown:'N'},letter=n=>LET[n.replace(/^(dark|light) /,'')]||(n.includes('gray')?'g':'?');
const hex=c=>'#'+c.map(v=>Math.round(v).toString(16).padStart(2,'0')).join('');
let ocrOK=null;const hasOcr=()=>ocrOK||(ocrOK=new Promise(r=>execFile(process.platform==='win32'?'where':'which',['tesseract'],e=>r(!e))));
const parseTSV=(tsv,sc)=>{const L=new Map();for(const l of String(tsv).split(/\r?\n/).slice(1)){const c=l.split('\t');if(c.length<12||c[0]!=='5')continue;const t=c[11].trim();if(!t||+c[10]<35)continue;const k=c[2]+'-'+c[3]+'-'+c[4],o={t,x:+c[6]/sc,y:+c[7]/sc,w:+c[8]/sc,h:+c[9]/sc};(L.get(k)||L.set(k,[]).get(k)).push(o)}
 return[...L.values()].map(ws=>{const x=Math.min(...ws.map(o=>o.x)),y=Math.min(...ws.map(o=>o.y)),x2=Math.max(...ws.map(o=>o.x+o.w)),y2=Math.max(...ws.map(o=>o.y+o.h));return{text:ws.map(o=>o.t).join(' '),x:Math.round(x),y:Math.round(y),w:Math.round(x2-x),h:Math.round(y2-y)}})};
async function ocr(buf){if(!await hasOcr())return{available:false,reason:'tesseract introuvable : le texte des captures ne peut pas être lu (installe Tesseract OCR)'};
 const f=path.join(os.tmpdir(),'kairo-ocr-'+process.pid+'-'+Date.now()+'.png');fs.writeFileSync(f,buf);
 try{const tsv=await new Promise((ok,ko)=>execFile('tesseract',[f,'stdout','--psm','11','tsv'],{timeout:30000,maxBuffer:1<<24,windowsHide:true},(e,so)=>e?ko(e):ok(so)));return{available:true,lines:parseTSV(tsv,1)}}
 catch(e){return{available:false,reason:'tesseract a échoué : '+String(e.message).slice(0,100)}}finally{try{fs.unlinkSync(f)}catch{}}}
const ERR=/(error|erreur|exception|uncaught|failed|cannot|can't|undefined|ERR_[A-Z_]+|\b404\b|not found|refused|traceback|syntaxerror)/i;
async function analyze(buf,o={}){const img=decode(buf),{w,h,rgb}=img,gw=Math.ceil(w/CS),gh=Math.ceil(h/CS),L=i=>0.2126*rgb[i]+0.7152*rgb[i+1]+0.0722*rgb[i+2],cell=new Array(gw*gh);
 for(let cy=0;cy<gh;cy++)for(let cx=0;cx<gw;cx++){let sr=0,sg=0,sb=0,n=0,mn=255,mx=0,ht=0,vt=0;const x0=cx*CS,y0=cy*CS,x1=Math.min(w,x0+CS),y1=Math.min(h,y0+CS);
  for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++){const i=(y*w+x)*3,l=L(i);sr+=rgb[i];sg+=rgb[i+1];sb+=rgb[i+2];n++;if(l<mn)mn=l;if(l>mx)mx=l;if(x+1<x1&&Math.abs(l-L(i+3))>40)ht++;if(y+1<y1&&Math.abs(l-L(i+w*3))>40)vt++}
  cell[cy*gw+cx]={c:[sr/n,sg/n,sb/n],flat:mx-mn<28,text:ht>=4&&vt>=4}}
 const hist={};for(const c of cell)if(c.flat){const k=(c.c[0]>>5)+','+(c.c[1]>>5)+','+(c.c[2]>>5);(hist[k]||(hist[k]={n:0,s:[0,0,0]})).n++;for(let j=0;j<3;j++)hist[k].s[j]+=c.c[j]}
 const top=Object.values(hist).sort((a,b)=>b.n-a.n)[0]||{n:1,s:[0,0,0]},bg=top.s.map(v=>v/top.n),bgFrac=top.n/cell.length,bgLum=0.2126*bg[0]+0.7152*bg[1]+0.0722*bg[2];
 const fg=cell.map(c=>c.flat&&dist(c.c,bg)>45),lab=new Int32Array(cell.length).fill(-1),comps=[];
 for(let s=0;s<cell.length;s++){if(!fg[s]||lab[s]>=0)continue;const id=comps.length,q=[s],cc=cell[s].c,cs=[];lab[s]=id;
  while(q.length){const k=q.pop();cs.push(k);const x=k%gw,y=(k/gw)|0;for(const[dx,dy]of[[1,0],[-1,0],[0,1],[0,-1]]){const nx=x+dx,ny=y+dy;if(nx<0||ny<0||nx>=gw||ny>=gh)continue;const m=ny*gw+nx;if(fg[m]&&lab[m]<0&&dist(cell[m].c,cc)<36){lab[m]=id;q.push(m)}}}
  let x0=1e9,y0=1e9,x1=-1,y1=-1;for(const k of cs){const x=k%gw,y=(k/gw)|0;x0=Math.min(x0,x);x1=Math.max(x1,x);y0=Math.min(y0,y);y1=Math.max(y1,y)}comps.push({cs,cc,x0,y0,x1,y1,fill:cs.length/((x1-x0+1)*(y1-y0+1))})}
 const refine=c=>{const X0=Math.max(0,c.x0*CS-CS),Y0=Math.max(0,c.y0*CS-CS),X1=Math.min(w-1,(c.x1+1)*CS+CS),Y1=Math.min(h-1,(c.y1+1)*CS+CS);let a=1e9,b=1e9,d=-1,e=-1;
  for(let y=Y0;y<=Y1;y++)for(let x=X0;x<=X1;x++){const i=(y*w+x)*3;if(Math.abs(rgb[i]-c.cc[0])+Math.abs(rgb[i+1]-c.cc[1])+Math.abs(rgb[i+2]-c.cc[2])<40){if(x<a)a=x;if(x>d)d=x;if(y<b)b=y;if(y>e)e=y}}
  return a>d?{x:c.x0*CS,y:c.y0*CS,w:(c.x1-c.x0+1)*CS,h:(c.y1-c.y0+1)*CS}:{x:a,y:b,w:d-a+1,h:e-b+1}};
 const A=w*h,regions=[],objects=[],has=(r,x,y)=>x>=r.x&&x<=r.x+r.w&&y>=r.y&&y<=r.y+r.h;
 for(const c of comps){const b=refine(c),col=name(...c.cc),base={...b,color:col,hex:hex(c.cc)};
  if(b.w>=0.9*w&&b.h<=0.16*h)regions.push({...base,type:b.y<=0.2*h?'header bar':'footer bar'});
  else if(b.w*b.h>0.12*A)regions.push({...base,type:'panel/canvas'});
  else if(b.h>=20&&b.h<=100&&b.w>=50&&b.w<=420&&b.w/b.h>=1.6&&b.w/b.h<=10&&c.fill>0.5)regions.push({...base,type:'button'});
  else if(b.w<=60&&b.h<=60)objects.push({...base,type:'object'});
  else if(c.cs.length>=6)regions.push({...base,type:'box'})}
 // blocs de texte (cellules à contrastes horizontaux ET verticaux) regroupés
 const tl=new Int32Array(cell.length).fill(-1),blocks=[];
 for(let s=0;s<cell.length;s++){if(!cell[s].text||tl[s]>=0)continue;const q=[s],cs=[];tl[s]=blocks.length;while(q.length){const k=q.pop();cs.push(k);const x=k%gw,y=(k/gw)|0;for(let dy=-1;dy<=1;dy++)for(let dx=-2;dx<=2;dx++){const nx=x+dx,ny=y+dy;if(nx<0||ny<0||nx>=gw||ny>=gh)continue;const m=ny*gw+nx;if(cell[m].text&&tl[m]<0){tl[m]=blocks.length;q.push(m)}}}
  if(cs.length>=2){let x0=1e9,y0=1e9,x1=-1,y1=-1;for(const k of cs){const x=k%gw,y=(k/gw)|0;x0=Math.min(x0,x);x1=Math.max(x1,x);y0=Math.min(y0,y);y1=Math.max(y1,y)}blocks.push({x:x0*CS,y:y0*CS,w:(x1-x0+1)*CS,h:(y1-y0+1)*CS})}else blocks.push(null)}
 const tb=blocks.filter(Boolean);
 const O=o.noOcr?{available:false,reason:'désactivé'}:await ocr(buf),lines=O.available?O.lines.filter(l=>/[A-Za-z0-9À-ÿ]/.test(l.text)):[];
 const errors=[];for(const l of lines)if(ERR.test(l.text))errors.push('"'+l.text+'"');
 if(!errors.length&&bgFrac>0.97&&!comps.length&&!tb.length&&!lines.length)errors.push('possible blank screen (uniform '+name(...bg)+')');
 const inside=(l,r)=>has(r,l.x+l.w/2,l.y+l.h/2);
 for(const r of regions.concat(objects)){const ls=lines.filter(l=>inside(l,r));if(ls.length)r.label=ls.map(l=>l.text).join(' ');else if(r.type==='button'&&tb.some(t=>has(r,t.x+t.w/2,t.y+t.h/2)))r.hasText=true}
 const GOOD=/[A-Za-z0-9À-ÿ]{2,}/;
 // OCR ciblé sur les boutons dont le libellé n'a pas été lu (texte clair sur fond coloré) : recadrage + mode « une ligne »
 const ocrCrop=async r=>{const x0=Math.max(0,r.x-6),y0=Math.max(0,r.y-6),x1=Math.min(w,r.x+r.w+6),y1=Math.min(h,r.y+r.h+6),cw=x1-x0,chh=y1-y0,sc=chh<40?2:1,W2=cw*sc,H2=chh*sc,o=new Uint8Array(W2*H2*3);
  for(let y=0;y<H2;y++)for(let x=0;x<W2;x++){const s=((y0+((y/sc)|0))*w+x0+((x/sc)|0))*3,d=(y*W2+x)*3;o[d]=rgb[s];o[d+1]=rgb[s+1];o[d+2]=rgb[s+2]}
  const f=path.join(os.tmpdir(),'kairo-ocrc-'+process.pid+'-'+Date.now()+'.png');fs.writeFileSync(f,encodeRGB(W2,H2,o));
  try{return(await new Promise(ok=>execFile('tesseract',[f,'stdout','--psm','7'],{timeout:15000,windowsHide:true},(e,so)=>ok(e?'':String(so))))).trim().replace(/\s+/g,' ')}finally{try{fs.unlinkSync(f)}catch{}}};
 if(O.available)for(const r of regions.filter(r=>r.type==='button').slice(0,6)){const t=await ocrCrop(r);if(GOOD.test(t)&&(t.length>=(r.label||'').length||!GOOD.test(r.label||''))){r.label=t;r.hasText=false}}
 const free=lines.filter(l=>!regions.concat(objects).some(r=>r.label&&inside(l,r))).sort((a,b)=>a.y-b.y||a.x-b.x);
 const title=free.filter(l=>l.y<0.25*h).sort((a,b)=>b.h-a.h)[0];
 const rest=O.available?[]:tb.filter(t=>!regions.some(r=>has(r,t.x+t.w/2,t.y+t.h/2)));
 objects.sort((a,b)=>b.w*b.h-a.w*a.h);
 const P=r=>`x=${r.x} y=${r.y} w=${r.w} h=${r.h}`,out=[`SCREEN ${w}x${h}`,'',O.available?'OCR: tesseract ('+lines.length+' text lines read)':'OCR: UNAVAILABLE — '+O.reason+'. Text content is NOT readable; only text positions are known.','','Detected regions:',`- background: ${bgLum<90?'dark':bgLum>170?'light':'mid-tone'} (${hex(bg)}, ${name(...bg)})`];
 for(const r of regions.slice(0,10))out.push(`- ${r.type}: ${P(r)} color=${r.color}${r.label?` label="${r.label}"`:r.hasText?' contains text (unread)':''}`);
 for(const l of free.slice(0,10))out.push(`- ${l===title?'title':/score|points|pts|vies|lives|level|niveau|temps|time/i.test(l.text)?'score/HUD':'text'}: "${l.text}" ${P(l)}`);
 for(const t of rest.slice(0,6))out.push(`- text block (unread): ${P(t)}`);
 if(!regions.length&&!free.length&&!rest.length)out.push('- (no distinct region found)');
 out.push('','Objects:');for(const r of objects.slice(0,10))out.push(`- ${r.color} object${r.label?' "'+r.label+'"':''}: ${P(r)} center=(${r.x+(r.w>>1)},${r.y+(r.h>>1)})`);if(!objects.length)out.push('- none');
 out.push('','Errors:');out.push(errors.length?errors.map(e=>'- '+e).join('\n'):'- none detected');
 const GX=24,GY=15,cw=w/GX,ch2=h/GY,rows=[];for(let j=0;j<GY;j++){let r='';for(let i=0;i<GX;i++){let nb=0,nt=0,cnt={},n=0;for(let y=Math.floor(j*ch2/CS);y<Math.min(gh,Math.ceil((j+1)*ch2/CS));y++)for(let x=Math.floor(i*cw/CS);x<Math.min(gw,Math.ceil((i+1)*cw/CS));x++){const c=cell[y*gw+x];n++;if(c.text)nt++;else if(dist(c.c,bg)<=45)nb++;else{const l=letter(name(...c.c));cnt[l]=(cnt[l]||0)+1}}
  const dom=Object.entries(cnt).sort((a,b)=>b[1]-a[1])[0];r+=nb>=0.7*n?'.':nt>=0.15*n?'T':dom?dom[0]:'.'}rows.push(r)}
 out.push('',`MAP (each char ≈ ${Math.round(cw)}x${Math.round(ch2)} px; . background, T text, K black W white g gray R red O orange Y yellow G green C cyan B blue P purple M pink N brown):`,...rows);
 const items=[...regions.map(r=>({kind:r.type,color:r.color,label:r.label,x:r.x,y:r.y,w:r.w,h:r.h})),...objects.slice(0,10).map(r=>({kind:'object',color:r.color,label:r.label,x:r.x,y:r.y,w:r.w,h:r.h})),...free.slice(0,10).map(l=>({kind:'text',label:l.text,x:l.x,y:l.y,w:l.w,h:l.h}))];
 const bl=[`bg ${bgLum<90?'dark':bgLum>170?'light':'mid'} ${name(...bg)}`],bt=regions.filter(r=>r.type==='button'),pn=regions.filter(r=>r.type==='panel/canvas');
 if(bt.length)bl.push('buttons: '+bt.slice(0,3).map(r=>`${r.label||r.color}(${r.x},${r.y})`).join(', '));if(pn.length)bl.push('panels: '+pn.slice(0,2).map(r=>`${r.w}x${r.h}@${r.x},${r.y}`).join(', '));
 if(objects.length)bl.push('objects: '+objects.slice(0,5).map(r=>`${r.color}(${r.x},${r.y})`).join(', '));if(free.length)bl.push('text: '+free.slice(0,5).map(l=>'"'+l.text.slice(0,30)+'"').join(' | '));else if(tb.length)bl.push(tb.length+' text block(s), unread');
 bl.push(errors.length?'errors: '+errors.join('; ').slice(0,120):'no error detected');
 return{w,h,text:out.join('\n'),bullets:bl,items,ocr:O.available,regions,objects,errors}}
const key=i=>i.kind+':'+(i.kind==='text'?String(i.label).toLowerCase().slice(0,24):(i.label||i.color))+(i.kind==='text'?'':'@'+Math.round(i.x/48)+','+Math.round(i.y/48)),dsc=i=>i.kind==='text'?`text "${i.label}"`:`${i.kind} ${i.label?'"'+i.label+'" ':''}${i.color||''}(${i.x},${i.y})`;
function diff(prev,cur){const a=new Map(prev.items.map(i=>[key(i),i])),b=new Map(cur.items.map(i=>[key(i),i])),add=[...b].filter(([k])=>!a.has(k)).map(x=>x[1]),rem=[...a].filter(([k])=>!b.has(k)).map(x=>x[1]),mv=[];
 for(const r of rem.slice())if(r.kind==='object'){const j=add.findIndex(x=>x.kind==='object'&&x.color===r.color);if(j>=0){mv.push(`moved: ${r.color} object (${r.x},${r.y}) -> (${add[j].x},${add[j].y})`);add.splice(j,1);rem.splice(rem.indexOf(r),1)}}
 const l=[...mv,...add.slice(0,5).map(i=>'+ '+dsc(i)),...rem.slice(0,5).map(i=>'- '+dsc(i))];return l.length?l:['no visible change']}
exports.analyze=analyze;exports.name=name;exports.hex=hex;exports.crop=crop;exports.encodeRGB=encodeRGB;exports.diff=diff;exports.decode=decode;exports.parseTSV=parseTSV;exports.encodeGray=encodeGray;
