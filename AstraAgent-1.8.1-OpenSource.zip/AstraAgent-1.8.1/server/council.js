'use strict';
const cleanText=(v,n=12000)=>String(v??'').trim().slice(0,n);
function create({providers,getSettings,save}){
 async function run({message,agents,coordinator,signal}){
  const prompt=cleanText(message,12000);if(!prompt)throw new Error('Décris la mission à soumettre au conseil.');
  if(!Array.isArray(agents)||agents.length<2||agents.length>4)throw new Error('Astra Council accepte de 2 à 4 modèles.');
  const members=agents.map((a,i)=>{const provider=String(a?.provider||''),model=cleanText(a?.model,120);if(!providers[provider]||!model)throw new Error('Modèle invalide pour le membre '+(i+1)+'.');return{id:'c'+(i+1),name:cleanText(a.name||providers[provider].label,40),provider,model}});
  const coord=coordinator&&providers[coordinator.provider]&&cleanText(coordinator.model,120)?{provider:coordinator.provider,model:cleanText(coordinator.model,120)}:members[0];
  const proposals=await Promise.all(members.map(async a=>{if(signal?.aborted)throw new Error('Conseil interrompu.');const system='Tu es membre indépendant du Astra Agent Council. Analyse la demande sans prétendre avoir exécuté quoi que ce soit. Donne une proposition concrète, les risques, les hypothèses et les points à vérifier. Réponds en français.';const answer=await providers[a.provider].chat(getSettings()[a.provider]||{},a.model,[{role:'system',content:system},{role:'user',content:prompt}],{plain:true,signal});return{...a,answer:cleanText(answer,9000)}}));
  if(signal?.aborted)throw new Error('Conseil interrompu.');
  const bundle=proposals.map(p=>'### '+p.name+' ('+p.provider+'/'+p.model+')\n'+p.answer).join('\n\n');
  const final=await providers[coord.provider].chat(getSettings()[coord.provider]||{},coord.model,[{role:'system',content:'Tu es le président du Astra Agent Council. Compare les propositions, repère les accords et désaccords, évalue les risques, puis produis une synthèse équilibrée et une recommandation. Ne prétends pas que les propositions ont été exécutées. Réponds en français avec les sections : Synthèse, Accords, Désaccords, Risques, Recommandation.'},{role:'user',content:'DEMANDE :\n'+prompt+'\n\nPROPOSITIONS INDÉPENDANTES :\n'+bundle}],{plain:true,signal});
  const result={id:Date.now().toString(36),at:new Date().toISOString(),message:prompt,coordinator:coord,members:proposals.map(({id,name,provider,model,answer})=>({id,name,provider,model,answer})),final:cleanText(final,12000)};
  if(save)save(result);return result;
 }
 return{run};
}
module.exports={create};
