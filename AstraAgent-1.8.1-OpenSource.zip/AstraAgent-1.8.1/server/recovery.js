// Astra Mission Recovery & Export — mission metadata + snapshots partagés avec Time Machine.
'use strict';
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const crypto = require('crypto');
const S = require('./store');
const pathGuard = require('./path-guard');
const TimeMachine = require('./time-machine').manager(S.dataDir);
const BASE = path.join(S.dataDir, 'recovery');
const OMIT = new Set(['.git', 'node_modules', '.kairo', '.venv', 'venv', '__pycache__', 'dist', 'build', '.next', 'coverage', '.ssh', '.aws', 'data']);
const OMIT_FILES = new Set(['.env', '.npmrc', '.pypirc', '.netrc', '.git-credentials', '.dockerconfigjson', 'credentials.json', 'service-account.json', 'id_rsa', 'id_ed25519']);
const omitPrivateFile = name => OMIT_FILES.has(name.toLowerCase()) || (/^\.env\./i.test(name) && !/^\.env\.example$/i.test(name)) || /\.(pem|p12|pfx|keystore)$/i.test(name);
const safeProject = id => String(id || '').replace(/[^\w-]/g, '') || 'unknown';
const projectDir = id => path.join(BASE, safeProject(id));
const validId = id => /^[a-z0-9-]{1,90}$/i.test(String(id || ''));

// Recovery and Time Machine intentionally share the same snapshot list and restore engine.
function snapshotProject(root, project, reason = 'manual') {
  const snap = TimeMachine.snapshot(safeProject(project), pathGuard.canonicalProjectRoot(root), String(reason || 'manual'));
  return { id: snap.id, project: safeProject(project), reason: snap.label, createdAt: snap.at,
    files: { length: snap.fileCount }, fileCount: snap.fileCount, totalBytes: snap.totalBytes, truncated: false, complete: true };
}
function listSnapshots(project) {
  return TimeMachine.list(safeProject(project)).map(s => ({ id: s.id, project: safeProject(project), reason: s.label,
    createdAt: s.at, files: { length: s.fileCount || 0 }, fileCount: s.fileCount || 0,
    totalBytes: s.totalBytes || 0, truncated: false, complete: true }));
}
function restoreSnapshot(root, project, id) {
  if (!validId(id)) throw new Error('Identifiant d’instantané invalide.');
  return TimeMachine.restore(safeProject(project), pathGuard.canonicalProjectRoot(root), id, { confirm: true });
}
function listFiles(root, limits = {}) {
  root = pathGuard.canonicalProjectRoot(root);
  const maxFiles = limits.maxFiles || 5000, maxBytes = limits.maxBytes || 120 * 1024 * 1024;
  const out = []; let total = 0, truncated = false;
  function visit(dir, rel) {
    for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
      const rp = rel ? path.join(rel, ent.name) : ent.name, full = path.join(dir, ent.name);
      if (ent.isSymbolicLink()) throw new Error('Export refusé : lien symbolique détecté (' + rp + ').');
      if (OMIT.has(ent.name) || omitPrivateFile(ent.name)) continue;
      if (ent.isDirectory()) { visit(full, rp); continue; }
      if (!ent.isFile()) continue;
      const safe = pathGuard.resolveProjectPath(root, rp), st = fs.lstatSync(safe);
      if (!st.isFile()) continue;
      if (out.length >= maxFiles || total + st.size > maxBytes) { truncated = true; continue; }
      total += st.size; out.push({ rel: rp, full: safe, size: st.size });
    }
  }
  visit(root, '');
  return { files: out, totalBytes: total, truncated };
}

function missionFile(project) { return 'recovery-missions-' + safeProject(project) + '.json'; }
function missionList(project) { return S.read(missionFile(project), []); }
function saveMission(project, list) { S.write(missionFile(project), list.slice(0, 40)); }
function beginMission({ project, conversation, title, snapshotId, history, log }) {
  const pid = safeProject(project), list = missionList(pid), id = 'mission-' + Date.now().toString(36) + '-' + crypto.randomBytes(2).toString('hex');
  const rec = { id, project: pid, conversation: String(conversation || ''), title: String(title || 'Mission').slice(0, 120), status: 'running',
    startedAt: new Date().toISOString(), updatedAt: new Date().toISOString(), snapshotId: snapshotId || null,
    history: Array.isArray(history) ? history.slice(-80) : [], log: Array.isArray(log) ? log.slice(-200) : [] };
  list.unshift(rec); saveMission(pid, list); return rec;
}
function checkpointMission(project, id, data = {}) {
  if (!id) return null;
  const list = missionList(project), rec = list.find(x => x.id === id); if (!rec) return null;
  if (Array.isArray(data.history)) rec.history = data.history.slice(-80);
  if (Array.isArray(data.log)) rec.log = data.log.slice(-200);
  rec.updatedAt = new Date().toISOString(); saveMission(project, list); return rec;
}
function finishMission(project, id, status, data = {}) {
  const list = missionList(project), rec = list.find(x => x.id === id); if (!rec) return null;
  if (Array.isArray(data.history)) rec.history = data.history.slice(-80);
  if (Array.isArray(data.log)) rec.log = data.log.slice(-200);
  rec.status = status || 'completed'; rec.finishedAt = new Date().toISOString(); rec.updatedAt = rec.finishedAt;
  saveMission(project, list); return rec;
}
function listMissions(project) {
  return missionList(project).map(({ history, log, ...m }) => ({ ...m, checkpoints: log?.length || 0 })).slice(0, 30);
}
function getMission(project, id) { return missionList(project).find(x => x.id === id) || null; }
function markInterrupted() {
  if (!fs.existsSync(S.dataDir)) return;
  for (const name of fs.readdirSync(S.dataDir).filter(x => /^recovery-missions-[\w-]+\.json$/.test(x))) {
    const p = path.join(S.dataDir, name); let list = [];
    try { list = JSON.parse(fs.readFileSync(p, 'utf8')); } catch { continue; }
    let changed = false;
    for (const m of list) if (m.status === 'running') { m.status = 'interrupted'; m.interruptedAt = new Date().toISOString(); changed = true; }
    if (changed) try { S.write(name, list.slice(0, 40)); } catch {}
  }
}

const crcTable = (() => { const a = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; a[n] = c >>> 0; } return a; })();
function crc32(buf) { let c = 0xffffffff; for (const b of buf) c = crcTable[(c ^ b) & 0xff] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; }
function dosDate(date) { const d = date || new Date(); return { time: (d.getHours() << 11) | (d.getMinutes() << 5) | Math.floor(d.getSeconds() / 2), date: ((Math.max(1980, d.getFullYear()) - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate() }; }
function zipProject(root) {
  const info = listFiles(root, { maxFiles: 5000, maxBytes: 120 * 1024 * 1024 });
  if (info.truncated) throw new Error('Export incomplet : le projet dépasse la limite de 5 000 fichiers ou 120 Mo. Réduis le projet avant l’export.');
  const local = [], central = []; let offset = 0;
  for (const item of info.files) {
    const name = item.rel.replace(/\\/g, '/'); if (name.split('/').some(x => OMIT.has(x) || omitPrivateFile(x))) continue;
    const raw = fs.readFileSync(item.full), compressed = zlib.deflateRawSync(raw), crc = crc32(raw), nm = Buffer.from(name, 'utf8'), dt = dosDate(fs.statSync(item.full).mtime);
    const lh = Buffer.alloc(30); lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(0, 6); lh.writeUInt16LE(8, 8); lh.writeUInt16LE(dt.time, 10); lh.writeUInt16LE(dt.date, 12); lh.writeUInt32LE(crc, 14); lh.writeUInt32LE(compressed.length, 18); lh.writeUInt32LE(raw.length, 22); lh.writeUInt16LE(nm.length, 26); lh.writeUInt16LE(0, 28);
    local.push(lh, nm, compressed);
    const ch = Buffer.alloc(46); ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(20, 4); ch.writeUInt16LE(20, 6); ch.writeUInt16LE(0, 8); ch.writeUInt16LE(8, 10); ch.writeUInt16LE(dt.time, 12); ch.writeUInt16LE(dt.date, 14); ch.writeUInt32LE(crc, 16); ch.writeUInt32LE(compressed.length, 20); ch.writeUInt32LE(raw.length, 24); ch.writeUInt16LE(nm.length, 28); ch.writeUInt16LE(0, 30); ch.writeUInt16LE(0, 32); ch.writeUInt16LE(0, 34); ch.writeUInt16LE(0, 36); ch.writeUInt32LE(0, 38); ch.writeUInt32LE(offset, 42);
    central.push(ch, nm); offset += lh.length + nm.length + compressed.length;
  }
  const cbuf = Buffer.concat(central), lbuf = Buffer.concat(local), end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(0, 4); end.writeUInt16LE(0, 6);
  const count = central.filter((_, i) => i % 2 === 0).length; // overridden below by actual entries
  const entries = central.length / 2;
  end.writeUInt16LE(entries, 8); end.writeUInt16LE(entries, 10); end.writeUInt32LE(cbuf.length, 12); end.writeUInt32LE(lbuf.length, 16); end.writeUInt16LE(0, 20);
  return Buffer.concat([lbuf, cbuf, end]);
}

module.exports = { snapshotProject, listSnapshots, restoreSnapshot, beginMission, checkpointMission, finishMission, listMissions, getMission, markInterrupted, zipProject, listFiles };
