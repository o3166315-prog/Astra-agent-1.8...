// Analyse de la demande : clarifier seulement si une info essentielle manque ; base générique pour les demandes vagues mais exploitables.
const norm=s=>String(s||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');
const SPEC=/\b(html|css|js|javascript|typescript|react|vue|svelte|angular|tailwind|bootstrap|python|node|nodejs|electron|godot|unity|cmake|c\+\+|cpp|rust|snake|tetris|pong|landing|hero|sombre|clair|dark|light|theme|bouton|fichier|index\.html|simple|minimal|exemple|test|demo|hello|todo|calculatrice|api)\b/,FREE=/(a toi de choisir|comme tu veux|surprends|peu importe|libre choix|fais au mieux|choisis pour moi)/;
exports.classify=msg=>{const n=norm(msg),w=n.split(/\s+/).filter(Boolean);
 const create=/\b(cree|creer|cree-moi|fais|fais-moi|construis|genere|generer|developpe|developper|ecris|make|create|build)\b/.test(n);
 if(!create||w.length>8||SPEC.test(n)||FREE.test(n)||/["'`]/.test(msg))return{kind:'clear'};
 if(/\b(page web|page|site|site web|site internet|portfolio|blog|boutique|vitrine)\b/.test(n)){const q=[];
  if(!/\bpour\b|restaurant|association|entreprise|startup|artiste|cv\b/.test(n))q.push("Quel est le but de la page (présenter une activité, un produit, un portfolio, un événement…) ?");
  q.push("Quel contenu doit y apparaître (sections, textes, images) ?");
  if(!/(moderne|minimal|colore|couleur|style|design)/.test(n))q.push("Quel style veux-tu (sombre ou clair, couleurs, ambiance) ?");
  q.push("HTML/CSS/JS simple, ou un framework (React, Vue…) ? Y a-t-il des fonctionnalités particulières (formulaire, animations…) ?");
  return{kind:'clarify',text:'Avant de créer la page, j\'ai besoin de quelques précisions qui changent vraiment le résultat :\n'+q.slice(0,4).map((x,i)=>(i+1)+'. '+x).join('\n')+'\n\nSi tu préfères, réponds « à toi de choisir » et je pars sur une version moderne en HTML/CSS/JS simple.'}}
 if(/\bjeu\b/.test(n))return{kind:'clarify',text:'Pour créer ton jeu, dis-moi :\n1. Quel type de jeu (plateforme, puzzle, arcade, aventure…) ?\n2. 2D ou 3D, et sur quoi (navigateur HTML/JS, Godot…) ?\n3. Quelles commandes (clavier, souris, manette) ?\n\nOu réponds « à toi de choisir » et je commence par un petit jeu d\'arcade 2D en HTML/JS.'};
 if(/\b(logiciel|application|appli|app|programme|outil|systeme)\b/.test(n))return{kind:'base',hint:'The request is vague but exploitable: state your interpretation in ONE sentence (for example a small extensible desktop/CLI application base), build a reasonable generic working base, run it, then ask what main function the user wants. Do not block on questions.'};
 return{kind:'clear'}};
