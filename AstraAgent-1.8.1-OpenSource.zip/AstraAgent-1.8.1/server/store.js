// Storage : JSON sur disque, un dossier de fichiers par projet
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const D=process.env.ASTRA_DATA||process.env.KAIRO_DATA||path.join(__dirname,'..','data');fs.mkdirSync(D,{recursive:true});
const f=n=>path.join(D,n);
exports.read=(n,d)=>{try{return JSON.parse(fs.readFileSync(f(n),'utf8'))}catch{return d}};
// Atomic JSON persistence: temp file in the same directory, fsync, then rename.
exports.write=(n,v)=>{
 const target=f(n),dir=path.dirname(target),temp=path.join(dir,'.'+path.basename(target)+'.'+process.pid+'.'+crypto.randomBytes(6).toString('hex')+'.tmp');
 let fd;
 try{
  fd=fs.openSync(temp,'wx',0o600);
  fs.writeFileSync(fd,JSON.stringify(v,null,2),'utf8');
  fs.fsyncSync(fd);fs.closeSync(fd);fd=null;
  fs.renameSync(temp,target);
  try{const dfd=fs.openSync(dir,'r');try{fs.fsyncSync(dfd)}finally{fs.closeSync(dfd)}}catch{}
 }catch(error){if(fd!==null&&fd!==undefined)try{fs.closeSync(fd)}catch{};try{fs.rmSync(temp,{force:true})}catch{};throw error}
};
exports.projDir=id=>{const p=path.join(D,'projects',String(id).replace(/[^\w-]/g,''),'files');fs.mkdirSync(p,{recursive:true});return p};
exports.dataDir=D;
