// Outils du projet. Les permissions tiennent compte du contexte explicite de la tâche.
const fs=require('fs'),path=require('path'),{spawn}=require('child_process'),perms=require('./perms'),caps=require('./caps'),pathGuard=require('./path-guard');
const safe=(root,p)=>pathGuard.resolveProjectPath(root,p||'.');
const hidden=p=>p.split(path.sep).some(x=>x==='node_modules'||x==='.git'||x==='.kairo');
const walk=(d,root,out=[])=>{for(const e of fs.readdirSync(d,{withFileTypes:true})){if(e.name==='node_modules'||e.name==='.git'||e.name==='.kairo')continue;const p=path.join(d,e.name);if(e.isSymbolicLink())throw new Error('Lien symbolique refusé pendant le parcours : '+path.relative(root,p));out.push(path.relative(root,p)+(e.isDirectory()?'/':''));if(e.isDirectory()&&out.length<700)walk(p,root,out)}return out};
const textFile=p=>/\.(txt|md|json|jsonc|js|jsx|ts|tsx|css|scss|html|htm|py|gd|cs|cpp|c|h|hpp|java|kt|rs|go|php|rb|sh|bat|ps1|yml|yaml|xml|toml|ini|cfg|env|log|sql|vue|svelte|astro|tscn|tres)$/i.test(p);
const briefDiff=(file,before,after)=>{
 const A=String(before??'').split('\n'),B=String(after??'').split('\n');
 if(A.join('\n')===B.join('\n'))return null;
 const max=700;
 let pre=0;while(pre<Math.min(A.length,B.length)&&A[pre]===B[pre])pre++;
 let suf=0;while(suf<Math.min(A.length-pre,B.length-pre)&&A[A.length-1-suf]===B[B.length-1-suf])suf++;
 if(A.length>max||B.length>max||A.length-pre-suf>180||B.length-pre-suf>180){
   return {file,lines:[`@@ ${file}`,`- ${A.length} lignes avant`,`+ ${B.length} lignes après`],added:Math.max(0,B.length-A.length),removed:Math.max(0,A.length-B.length),coarse:true};
 }
 const oldMid=A.slice(pre,A.length-suf),newMid=B.slice(pre,B.length-suf),lines=[`@@ ${file}:${pre+1}`];
 oldMid.slice(0,120).forEach(x=>lines.push('- '+x));
 newMid.slice(0,120).forEach(x=>lines.push('+ '+x));
 if(oldMid.length>120||newMid.length>120)lines.push('…');
 return {file,lines,added:newMid.length,removed:oldMid.length,coarse:false};
};
const backup=async(c,p,before,after,existedBefore)=>{const dir=pathGuard.resolveProjectPath(c.root,'.kairo/backups');fs.mkdirSync(dir,{recursive:true});const id=Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,7),file=pathGuard.resolveProjectPath(c.root,'.kairo/backups/'+id+'.json');fs.writeFileSync(file,JSON.stringify({id,path:path.relative(c.root,p),before,after,existedBefore,at:new Date().toISOString()},null,2),{flag:'wx'});return id};
exports.walk=walk;exports.safe=safe;exports.briefDiff=briefDiff;
exports.tools={
 analyze_image:{desc:'Convertit une image (png, jpg, gif, bmp, webp) du projet en représentation numérique compacte lisible sans modèle de vision. args:{path, size?:16-256, encoding?:auto|palette|rle|hex12|hex|json}',run:async(a,c)=>{const p=perms.norm(a.path,c.root);if(!fs.existsSync(p)||fs.statSync(p).isDirectory())throw new Error('Fichier inexistant : '+a.path);return (await require('./imagecodec').prepare(fs.readFileSync(p),{name:a.path,size:a.size,encoding:a.encoding,maxChars:c.imageBudget||5500,lite:true})).text}},
 fetch_url:{perm:'CONFIRM',desc:"Télécharge le texte d'une page web. args:{url}",run:async a=>{const r=await fetch(a.url,{signal:AbortSignal.timeout(15000)});return (await r.text()).replace(/<script[\s\S]*?<\/script>|<style[\s\S]*?<\/style>|<[^>]+>/g,' ').replace(/\s+/g,' ').slice(0,6000)}},
 remember:{perm:'SAFE',desc:"Mémorise une information durable sur le projet. args:{text}",run:async(a,c)=>{if(!c.mem)throw new Error('mémoire indisponible');c.mem.project.push({text:String(a.text||'').slice(0,300)});return 'mémorisé'}},
 search_files:{perm:'SAFE',desc:'Cherche un texte dans les fichiers texte pertinents, sans scanner les dossiers système. args:{query}',run:async(a,c)=>{const q=String(a.query||'').trim().toLowerCase();if(!q)return 'Requête vide';const hits=[];for(const f of walk(c.root,c.root).filter(x=>!x.endsWith('/')&&textFile(x))){try{const lines=fs.readFileSync(safe(c.root,f),'utf8').split('\n');lines.forEach((l,i)=>{if(l.toLowerCase().includes(q)&&hits.length<80)hits.push(`${f}:${i+1}: ${l.trim()}`)})}catch{}}return hits.join('\n')||'Aucun résultat'}},
 detect_tools:{desc:'Détecte les outils installés (node, npm, python, cmake, git, compilateurs, Blender, Godot…) avec leur version. args:{}',run:async()=>caps.describe(await caps.detect(true))},
 list_dir:{desc:'Liste l’arborescence du projet, ou d’un autre dossier avec args:{path?}.',run:async(a,c)=>{const d=perms.norm(a.path||'.',c.root);if(!fs.existsSync(d)||!fs.statSync(d).isDirectory())throw new Error('Dossier inexistant : '+(a.path||'.'));return walk(d,d).join('\n')||'(vide)'}},
 read_file:{desc:'Lit un fichier (chemin relatif au projet ; hors projet = confirmation). args:{path}',run:async(a,c)=>{const p=perms.norm(a.path,c.root);if(!fs.existsSync(p)||fs.statSync(p).isDirectory())throw new Error('Fichier inexistant : '+a.path);return fs.readFileSync(p,'utf8').slice(0,20000)}},
 write_file:{desc:'Crée ou modifie un fichier (dossiers créés automatiquement). args:{path,content}',run:async(a,c)=>{const rel=String(a.path||'');if(!rel)throw new Error('chemin manquant');const p=perms.norm(rel,c.root),inside=perms.inside(p,c.root);if(inside&&hidden(path.relative(c.root,p)))throw new Error('Écriture dans une zone interne refusée : '+rel);if(fs.existsSync(p)&&fs.statSync(p).isDirectory())throw new Error('Ce chemin est un dossier : '+rel);const existedBefore=fs.existsSync(p),before=existedBefore?fs.readFileSync(p,'utf8'):'',after=String(a.content??''),changeId=inside?await backup(c,p,before,after,existedBefore):null;fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,after);c.created?.add(p);const d=briefDiff(rel,before,after);return{text:(existedBefore?'Modifié ':'Créé ')+rel+' ('+after.length+' car.)',diff:d,changeId,path:rel}}},
 delete_file:{desc:'Supprime un fichier ou dossier. args:{path}',run:async(a,c)=>{const p=perms.norm(a.path,c.root);if(!fs.existsSync(p))throw new Error('Fichier inexistant : '+a.path);if(p===c.root||path.parse(p).root===p||p===require('os').homedir())throw new Error('Suppression refusée : dossier racine ou système protégé');fs.rmSync(p,{recursive:true});c.created?.delete(p);return 'Supprimé '+a.path}},
 run_command:{desc:'Exécute une commande shell dans le dossier du projet. Les commandes de développement normales (node, npm run, python, cmake, git local, compilateurs, scripts du projet) s’exécutent sans confirmation ; installations, réseau et système demandent confirmation ; le destructif demande une confirmation explicite. args:{command, background?:true (serveur/appli GUI : environnement actif requis), timeout?:secondes (défaut 120, max 300)}',run:(a,c)=>new Promise((res,rej)=>{
   if(!String(a.command||'').trim())return rej(new Error('commande vide'));
   if(a.background&&!c.env)return rej(new Error('background nécessite un environnement actif (onglet Écran)'));
   const t0=Date.now(),[f,ar,o]=c.env?c.env.spawn(a.command):[a.command,[],{shell:true,cwd:c.root}],p=spawn(f,ar,{windowsHide:true,...o});let out='',done=false;if(c.env)c.env.procs.add(p);
   c.emit('term',{stream:'status',text:'$ '+a.command});
   const tmo=Math.min(300,Math.max(5,+a.timeout||120))*1000,to=a.background?null:setTimeout(()=>{out+='\n[délai de '+tmo/1000+' s dépassé : processus arrêté]';p.kill()},tmo);
   if(a.background)setTimeout(()=>{if(!done)res('démarré en arrière-plan (pid '+p.pid+')\n'+out.slice(-2000))},2500);
   const on=s=>d=>{out+=d;c.emit('term',{stream:s,text:String(d)})};p.stdout.on('data',on('stdout'));p.stderr.on('data',on('stderr'));p.on('error',e=>{out+=e.message;c.emit('term',{stream:'stderr',text:e.message})});
   p.on('close',code=>{done=true;clearTimeout(to);const ms=Date.now()-t0;c.emit('term',{stream:'status',text:`exit ${code} · ${ms} ms`});const t=`exit ${code}\n`+out.slice(-6000);code===0?res(t):rej(new Error(t))})})},
};
Object.assign(exports.tools,require('./moretools')({walk,briefDiff,backup,hidden,textFile,tools:exports.tools}));
Object.assign(exports.tools,require('./extratools')({walk,briefDiff,backup,hidden,textFile,tools:exports.tools}));
Object.assign(exports.tools,require('./devtools')({walk,briefDiff,backup,hidden,textFile,tools:exports.tools}));
Object.assign(require('./extratools').META,require('./devtools').META);
Object.assign(exports.tools,require('./devtools3')({walk,briefDiff,backup,hidden,textFile,tools:exports.tools}));
Object.assign(require('./extratools').META,require('./devtools3').META);
