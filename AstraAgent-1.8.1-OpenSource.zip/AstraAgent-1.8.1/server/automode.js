// Mode Auto : discussion normale, et passage automatique en mode Agent quand la demande est une vraie tâche
// (créer, développer, corriger, installer…). Les questions de culture générale restent en discussion.
const norm = s => String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[’‘]/g, "'");
// Heuristique historique (sur le texte brut) : verbes et mots qui désignent une action sur le projet.
const OLD = /cr[ée]e|cr[ée]er|écri|génèr|génér|modifi|supprim|lance|exécut|install|fichier|dossier|script|captur|screenshot|corrig|ajout|compil|test/i;
// Verbes qui demandent à eux seuls une réalisation (sur le texte sans accents).
const STRONG = /\b(construi[st]|construire|developpe\w*|programmer|programmes?-?moi|coder|codes?-?moi|implemente\w*|recree\w*|refais|refaire|fabrique\w*|realise\w*|concois|concevoir|reproduis\w*|reecri\w*|refactor\w*|migre\w*|deploie\w*|debogue\w*|deboguer|repare\w*|rajoute\w*|integre\w*|optimise\w*)\b/;
// Verbes plus généraux : seulement s'il y a aussi un objet à produire.
const WEAK = /\b(fais|fait|faire|cree|creer|genere|generer|ecris|ecrire|ajoute|ajouter|ameliore|ameliorer|make|build|create|implement|develop|generate|write)\b/;
const NOUN = /\b(jeu|jeux|site|appli\w*|app|logiciel|outil|bot|api|extension|plugin|page|interface|moteur|clone|minecraft|fonctionnalite|feature|module|composant|classe|fonction|systeme|menu|niveau|generateur|editeur|simulateur|dashboard|tableau de bord|serveur|calculatrice|convertisseur|formulaire|landing|portfolio|blog|boutique|scraper|crawler|script|programme|projet)\b/;
// Question de connaissance pure (« c'est quoi… », « pourquoi… ») sans rien de concret dans le projet.
const KNOW = /^\s*(c'est quoi|qu'est[- ]ce (que|qu')|qu'est ce (que|qu')|pourquoi|que (signifie|veut dire)|quelle? (est|sont) (la|les) difference|quelle? difference|ca veut dire quoi|definis|definition de|qui (est|a)\b|combien|quand\b|ou (est|se trouve))/;
const CONCRETE = /\b(fichier|dossier|projet|depot|repo|ce code|mon code|erreur|bug|plante|crash)\b|\b[\w-]+\.(js|ts|py|gd|json|html|css|cpp|c|cs|java|rs|go|md|txt|yml|yaml|xml|sh|bat)\b/;
exports.needsAgent = msg => {
  const raw = String(msg || ''), n = norm(raw);
  if (KNOW.test(n) && !CONCRETE.test(n)) return { agent: false, why: 'question' };
  if (OLD.test(raw) || STRONG.test(n) || (WEAK.test(n) && NOUN.test(n))) return { agent: true, why: 'tâche' };
  return { agent: false, why: '' };
};
