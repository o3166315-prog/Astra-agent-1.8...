// Astra Swarm workspace isolation, change detection and guarded integration.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { safe } = require('./tools');
const pathGuard = require('./path-guard');

const SKIP_DIRS = new Set([
  '.git', '.kairo', 'node_modules', '.venv', 'venv', '__pycache__',
  '.next', '.nuxt', '.cache', '.turbo', 'coverage', 'dist', 'build',
  'out', 'target', 'bin', 'obj', '.idea', '.vscode-test'
]);
const SECRET_FILES = /^(\.env(?:\..*)?|.*\.(?:pem|key|p12|pfx|keystore|jks))$/i;
const MAX_FILES = 3500;
const MAX_TOTAL_BYTES = 120 * 1024 * 1024;
const MAX_FILE_BYTES = 8 * 1024 * 1024;

const hash = b => crypto.createHash('sha256').update(b).digest('hex');
const rel = (root, file) => path.relative(root, file).split(path.sep).join('/');
const isText = b => !b.includes(0) && Buffer.from(b.toString('utf8'), 'utf8').equals(b);

function copyWorkspace(source, destination) {
  fs.mkdirSync(destination, { recursive: true });
  const baseline = {};
  const warnings = [];
  let totalBytes = 0, count = 0, limitReached = false;
  const walk = (dir) => {
    if (limitReached) return;
    for (const item of fs.readdirSync(dir, { withFileTypes: true })) {
      if (item.isSymbolicLink()) continue;
      if (item.isDirectory() && SKIP_DIRS.has(item.name)) continue;
      if (item.isFile() && SECRET_FILES.test(item.name)) {
        warnings.push('Fichier sensible ignoré : ' + rel(source, path.join(dir, item.name)));
        continue;
      }
      const from = safe(source, path.relative(source, path.join(dir, item.name)));
      const to = path.join(destination, path.relative(source, from));
      if (item.isDirectory()) {
        fs.mkdirSync(to, { recursive: true });
        walk(from);
      } else if (item.isFile()) {
        const st = fs.statSync(from);
        if (st.size > MAX_FILE_BYTES) { warnings.push('Fichier volumineux ignoré : ' + rel(source, from)); continue; }
        if (count >= MAX_FILES || totalBytes + st.size > MAX_TOTAL_BYTES) {
          if (!limitReached) warnings.push('Limite de copie atteinte ; certains fichiers n’ont pas été copiés.');
          limitReached = true;
          return;
        }
        fs.mkdirSync(path.dirname(to), { recursive: true });
        fs.copyFileSync(from, to);
        const data = fs.readFileSync(from);
        baseline[rel(source, from)] = { hash: hash(data), size: st.size, text: isText(data) };
        totalBytes += st.size;
        count++;
      }
    }
  };
  walk(source);
  return { baseline, count, totalBytes, warnings };
}

function collectChanges(workspace, baseline, workerId) {
  const current = {};
  const walk = dir => {
    if (!fs.existsSync(dir)) return;
    for (const item of fs.readdirSync(dir, { withFileTypes: true })) {
      if (item.isSymbolicLink() || (item.isDirectory() && SKIP_DIRS.has(item.name))) continue;
      const file = safe(workspace, path.relative(workspace, path.join(dir, item.name)));
      if (item.isDirectory()) walk(file);
      else if (item.isFile()) {
        const rp = rel(workspace, file);
        if (SECRET_FILES.test(item.name)) continue;
        const data = fs.readFileSync(file);
        current[rp] = { hash: hash(data), size: data.length, text: isText(data), file: rp };
      }
    }
  };
  walk(workspace);
  const changes = [];
  for (const [file, now] of Object.entries(current)) {
    const before = baseline[file];
    if (!before || before.hash !== now.hash) {
      changes.push({
        workerId, path: file, type: before ? 'modify' : 'create',
        beforeHash: before?.hash || null, afterHash: now.hash,
        size: now.size, text: now.text
      });
    }
  }
  for (const [file, before] of Object.entries(baseline)) {
    if (!current[file]) changes.push({ workerId, path: file, type: 'delete', beforeHash: before.hash, afterHash: null, size: 0, text: before.text });
  }
  return changes.sort((a, b) => a.path.localeCompare(b.path));
}

function summarizeChanges(changes, workspace) {
  return changes.map(change => {
    let preview = '';
    if (change.text && change.type !== 'delete') {
      try {
        const text = fs.readFileSync(safe(workspace, change.path), 'utf8');
        preview = text.slice(0, 900);
      } catch {}
    }
    return { ...change, preview };
  });
}

function mergeChanges(projectRoot, mission) {
  const groups = new Map();
  for (const change of mission.changes || []) {
    if (!groups.has(change.path)) groups.set(change.path, []);
    groups.get(change.path).push(change);
  }
  const applied = [], conflicts = [], skipped = [];
  for (const [file, group] of groups) {
    const candidates = group.filter(x => x.type !== 'delete' && x.text);
    if (group.some(x => x.type === 'delete')) {
      conflicts.push({ path: file, reason: 'Suppression non fusionnée automatiquement' });
      continue;
    }
    if (candidates.length !== group.length) {
      conflicts.push({ path: file, reason: 'Fichier binaire ou illisible : fusion manuelle requise' });
      continue;
    }
    const hashes = new Set(candidates.map(x => x.afterHash));
    if (hashes.size > 1) {
      conflicts.push({ path: file, reason: 'Plusieurs agents ont produit des versions différentes', workers: group.map(x => x.workerId) });
      continue;
    }
    const candidate = candidates[0];
    const target = safe(projectRoot, file);
    const exists = fs.existsSync(target);
    const currentHash = exists && fs.statSync(target).isFile() ? hash(fs.readFileSync(target)) : null;
    if ((candidate.beforeHash && currentHash !== candidate.beforeHash) || (!candidate.beforeHash && exists)) {
      conflicts.push({ path: file, reason: 'Le fichier du projet principal a changé depuis le lancement de la mission' });
      continue;
    }
    const worker = mission.workers.find(w => w.id === candidate.workerId);
    const source = safe(worker.workspace, file);
    if (!fs.existsSync(source) || !fs.statSync(source).isFile()) {
      conflicts.push({ path: file, reason: 'Résultat de l’agent introuvable' });
      continue;
    }
    const after = fs.readFileSync(source);
    if (!isText(after)) {
      conflicts.push({ path: file, reason: 'Fichier binaire : fusion automatique désactivée' });
      continue;
    }
    const before = exists ? fs.readFileSync(target, 'utf8') : '';
    const afterText = after.toString('utf8');
    const backupDir = safe(projectRoot, '.kairo/backups');
    fs.mkdirSync(backupDir, { recursive: true });
    const backupId = Date.now().toString(36) + '-' + crypto.randomBytes(3).toString('hex');
    const backupFile = safe(projectRoot, '.kairo/backups/' + backupId + '.json');
    fs.writeFileSync(backupFile, JSON.stringify({
      id: backupId, path: file, before, after: afterText, existedBefore: exists, at: new Date().toISOString()
    }, null, 2));
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.writeFileSync(target, afterText, 'utf8');
    applied.push({ path: file, workerId: candidate.workerId, backupId, type: candidate.type });
  }
  return { applied, conflicts, skipped };
}

function replayTimeline(mission) {
  const names = Object.fromEntries((mission.workers || []).map(w => [w.id, w.name || w.id]));
  return (mission.events || []).map((event, index) => {
    const nested = event.event || {};
    const type = String(event.type || nested.type || 'event');
    const message = nested.message || event.text || event.lastAction || (type === 'plan' ? 'Plan réparti entre les agents' : type === 'review-start' ? 'Revue indépendante démarrée' : type === 'complete' ? 'Mission terminée' : type === 'mission' ? 'Préparation des copies isolées' : type);
    return {
      index, at: event.at || nested.at || null, type,
      actor: event.workerId ? (names[event.workerId] || event.workerId) : 'Astra Swarm',
      message: String(message).slice(0, 700)
    };
  }).sort((a, b) => String(a.at || '').localeCompare(String(b.at || '')) || a.index - b.index);
}

function safeMission(mission) {
  return {
    id: mission.id, project: mission.project, title: mission.title,
    status: mission.status, createdAt: mission.createdAt, updatedAt: mission.updatedAt,
    coordinator: mission.coordinator,
    workers: mission.workers.map(w => ({
      id: w.id, name: w.name, role: w.role, provider: w.provider, model: w.model,
      task: w.task || '', status: w.status, lastAction: w.lastAction || '',
      startedAt: w.startedAt || null, finishedAt: w.finishedAt || null,
      result: w.result || '', changes: (w.changes || []).map(c => ({
        path: c.path, type: c.type, afterHash: c.afterHash, size: c.size, text: c.text
      })), events: (w.events || []).slice(-80)
    })),
    plan: mission.plan || [], review: mission.review || '',
    changes: (mission.changes || []).map(c => ({
      workerId: c.workerId, path: c.path, type: c.type, afterHash: c.afterHash,
      size: c.size, text: c.text, preview: c.preview || ''
    })),
    warnings: mission.warnings || [], conflicts: mission.conflicts || [],
    events: (mission.events || []).slice(-120),
    copyStats: mission.copyStats || null, integration: mission.integration || null
  };
}

exports.copyWorkspace = copyWorkspace;
exports.collectChanges = collectChanges;
exports.summarizeChanges = summarizeChanges;
exports.mergeChanges = mergeChanges;
exports.safeMission = safeMission;
exports.replayTimeline = replayTimeline;
