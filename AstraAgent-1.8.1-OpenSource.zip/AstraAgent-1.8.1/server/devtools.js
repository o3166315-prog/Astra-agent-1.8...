// Outils de développement (V1.8) : Git complet, qualité de code, dépendances, recherche web.
// Même principe que extratools.js : une fabrique ; chaque outil = { desc, run(args, ctx) }.
// Les permissions sont décidées dans perms.js (classifyTool). Aucune commande n'est passée à un shell
// (sauf les .cmd de Windows, dont les arguments sont strictement validés) : pas d'injection possible.
const fs = require('fs'), path = require('path'), { spawnSync } = require('child_process'), perms = require('./perms');

const WIN = process.platform === 'win32';
const TAIL = (s, n = 6000) => { s = String(s || '').trim(); return s.length > n ? '…\n' + s.slice(-n) : s; };

// ── Exécution de programmes ─────────────────────────────────────────────────────────────
const BAD_WIN = /["&|<>^%`\r\n]/;
const quoteWin = a => { a = String(a); if (BAD_WIN.test(a)) throw new Error('Caractère interdit dans un argument : ' + a.slice(0, 40)); return /\s/.test(a) ? '"' + a + '"' : a; };
const exec = (c, cmd, args, opts = {}) => {
  const o = { cwd: c.root, encoding: 'utf8', timeout: opts.timeout || 120000, windowsHide: true, maxBuffer: 8 * 1024 * 1024 };
  const r = WIN && /(\.cmd|\.bat)$|^(npm|npx|pnpm|yarn)$/i.test(cmd) ? spawnSync([quoteWin(cmd), ...args.map(quoteWin)].join(' '), { ...o, shell: true }) : spawnSync(cmd, args, o);
  if (r.error) {
    if (r.error.code === 'ENOENT') throw new Error(path.basename(cmd) + ' introuvable (non installé ou absent du PATH)');
    if (r.error.code === 'ETIMEDOUT') throw new Error('délai dépassé (' + Math.round(o.timeout / 1000) + ' s) : ' + path.basename(cmd));
    throw new Error(path.basename(cmd) + ' : ' + r.error.message);
  }
  return { code: r.status, out: String(r.stdout || ''), err: String(r.stderr || '') };
};
const localBin = (c, name) => { const b = path.join(c.root, 'node_modules', '.bin', name + (WIN ? '.cmd' : '')); return fs.existsSync(b) ? b : null; };
const exists = (c, f) => fs.existsSync(path.join(c.root, f));
const hasCmd = (c, cmd, args = ['--version']) => { try { return exec(c, cmd, args, { timeout: 8000 }).code === 0; } catch { return false; } };
const pyBin = c => ['python3', 'python', 'py'].find(x => hasCmd(c, x)) || null;
const hasPyFiles = c => { try { return fs.readdirSync(c.root).some(f => /\.py$/i.test(f)) || exists(c, 'pyproject.toml') || exists(c, 'requirements.txt'); } catch { return false; } };

// Chemin du projet → chemin relatif sûr pour une ligne de commande.
const relPath = (v, c) => {
  const p = perms.norm(v || '.', c.root);
  if (!perms.inside(p, c.root)) throw new Error('Chemin hors du projet refusé : ' + v);
  const r = path.relative(c.root, p) || '.';
  if (r.startsWith('-')) throw new Error('Chemin invalide : ' + v);
  return r;
};

// ── Git ─────────────────────────────────────────────────────────────────────────────────
const git = (c, args) => {
  const r = spawnSync('git', ['--no-pager', '-c', 'core.quotepath=false', ...args], { cwd: c.root, encoding: 'utf8', timeout: 30000, windowsHide: true, maxBuffer: 4 * 1024 * 1024 });
  if (r.error) throw new Error('git indisponible : ' + r.error.message);
  if (r.status !== 0) { const m = String(r.stderr || r.stdout).trim(); throw new Error(/not a git repository/i.test(m) ? 'Ce projet n’est pas un dépôt git (lance « git init » avec run_command)' : 'git : ' + m.slice(0, 600)); }
  return String(r.stdout);
};
// Identité de secours (commit/stash échouent sans nom d'utilisateur git) : valable pour cette commande seulement.
const identity = c => { try { if (git(c, ['config', 'user.name']).trim() && git(c, ['config', 'user.email']).trim()) return []; } catch { /* non configuré */ } return ['-c', 'user.name=Astra Agent', '-c', 'user.email=astra-agent@localhost']; };
const refName = (v, label = 'nom') => {
  v = String(v || '').trim();
  if (!/^[A-Za-z0-9_][\w./@#+-]{0,100}$/.test(v) || v.includes('..') || v.endsWith('/') || v.endsWith('.lock')) throw new Error(label + ' git invalide : « ' + v.slice(0, 60) + ' »');
  return v;
};

// ── Parseurs purs (testés sans réseau) ──────────────────────────────────────────────────
const summarizeOutdated = (manager, json) => {
  let data; try { data = JSON.parse(json || '{}'); } catch { return 'Résultat illisible.'; }
  if (manager === 'pip') {
    const rows = Array.isArray(data) ? data : [];
    return rows.length ? rows.length + ' paquet(s) à mettre à jour :\n' + rows.map(r => `  ${r.name} : ${r.version} → ${r.latest_version}`).join('\n') : 'Tout est à jour.';
  }
  const rows = Object.entries(data);
  if (!rows.length) return 'Tout est à jour.';
  return rows.length + ' paquet(s) à mettre à jour :\n' + rows.map(([n, r]) => `  ${n} : ${r.current || '—'} → ${r.wanted || '—'} (dernière : ${r.latest || '—'})${r.type === 'devDependencies' ? ' [dev]' : ''}`).join('\n');
};
const summarizeAudit = json => {
  let d; try { d = JSON.parse(json || '{}'); } catch { return 'Résultat illisible.'; }
  if (d.error) return 'npm audit : ' + (d.error.summary || d.error.code || 'erreur');
  const m = d.metadata?.vulnerabilities || {}, total = m.total ?? Object.keys(d.vulnerabilities || {}).length;
  if (!total) return 'Aucune faille connue dans les dépendances.';
  const order = { critical: 0, high: 1, moderate: 2, low: 3, info: 4 };
  const rows = Object.entries(d.vulnerabilities || {}).sort((a, b) => (order[a[1].severity] ?? 9) - (order[b[1].severity] ?? 9)).slice(0, 15);
  const head = `${total} faille(s) : ` + ['critical', 'high', 'moderate', 'low'].filter(k => m[k]).map(k => m[k] + ' ' + k).join(', ');
  return head + '\n' + rows.map(([n, v]) => `  [${v.severity}] ${n}${v.fixAvailable ? (v.fixAvailable === true ? ' — correctif : npm audit fix' : ' — correctif : ' + (v.fixAvailable.name || '') + '@' + (v.fixAvailable.version || '')) : ' — pas de correctif automatique'}`).join('\n');
};
const decodeEntities = s => String(s).replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#x27;|&#39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&nbsp;/g, ' ');
const stripTags = s => decodeEntities(String(s).replace(/<[^>]+>/g, ' ')).replace(/\s+/g, ' ').trim();
const parseDuckDuckGo = html => {
  const out = [], anchors = [...String(html).matchAll(/<a\b[^>]*class="[^"]*result__a[^"]*"[^>]*>/g)];
  anchors.forEach((m, i) => {
    const hrefM = /href="([^"]+)"/.exec(m[0]); if (!hrefM) return;
    let url = decodeEntities(hrefM[1]);
    const u = /[?&]uddg=([^&]+)/.exec(url); if (u) { try { url = decodeURIComponent(u[1]); } catch { /* garde l'URL brute */ } }
    if (url.startsWith('//')) url = 'https:' + url;
    if (!/^https?:\/\//i.test(url)) return;
    const end = html.indexOf('</a>', m.index), title = stripTags(html.slice(m.index + m[0].length, end));
    const next = anchors[i + 1] ? anchors[i + 1].index : html.length, chunk = html.slice(end, next);
    const sn = /class="[^"]*result__snippet[^"]*"[^>]*>([\s\S]*?)<\/(?:a|td|div|span)>/.exec(chunk);
    out.push({ title, url, snippet: sn ? stripTags(sn[1]) : '' });
  });
  return out;
};
const parseSearx = json => { let d; try { d = JSON.parse(json); } catch { return []; } return (d.results || []).map(r => ({ title: String(r.title || ''), url: String(r.url || ''), snippet: String(r.content || '') })).filter(r => /^https?:\/\//.test(r.url)); };
const formatResults = (q, rows, n) => rows.length ? `Résultats pour « ${q} » :\n\n` + rows.slice(0, n).map((r, i) => `${i + 1}. ${r.title}\n   ${r.url}${r.snippet ? '\n   ' + r.snippet.slice(0, 280) : ''}`).join('\n\n') + '\n\n(utilise fetch_url sur une adresse pour lire la page)' : '';

// ── Dépendances ─────────────────────────────────────────────────────────────────────────
const pkgSpec = v => {
  v = String(v || '').trim();
  if (!/^(@[a-z0-9_.-]+\/)?[A-Za-z0-9_.-]+(\[[\w,-]+\])?(@[\w.^~<>=*|-]+|[=<>~!]=?[\w.*,<>=!~-]+)?$/.test(v) || v.startsWith('-')) throw new Error('Nom de paquet invalide : « ' + v.slice(0, 60) + ' »');
  return v;
};
const manager = (c, forced) => {
  if (forced) { if (!['npm', 'pnpm', 'yarn', 'pip'].includes(forced)) throw new Error('Gestionnaire non géré : ' + forced + ' (npm, pnpm, yarn, pip)'); return forced; }
  if (exists(c, 'pnpm-lock.yaml')) return 'pnpm';
  if (exists(c, 'yarn.lock')) return 'yarn';
  if (exists(c, 'package.json')) return 'npm';
  if (exists(c, 'requirements.txt') || exists(c, 'pyproject.toml') || exists(c, 'setup.py')) return 'pip';
  throw new Error('Aucun package.json, requirements.txt ou pyproject.toml dans le projet');
};
const pipCmd = (c, args) => { const py = pyBin(c); if (!py) throw new Error('Python introuvable'); return py === 'py' ? ['py', ['-3', '-m', 'pip', ...args]] : [py, ['-m', 'pip', ...args]]; };

// ── Parcours de code (navigation) ───────────────────────────────────────────────────────
const SKIP_DIRS = new Set(['node_modules', '.git', '.kairo', 'dist', 'build', 'out', '.venv', 'venv', '__pycache__', '.next', 'target', '.godot', '.import', 'coverage']);
const CODE_EXT = /\.(js|mjs|cjs|jsx|ts|tsx|py|gd|cs|cpp|cc|c|h|hpp|java|kt|rs|go|php|rb|lua|vue|svelte|swift|sh)$/i;
const codeFiles = (c, dirRel, glob) => {
  const base = perms.norm(dirRel || '.', c.root);
  if (!perms.inside(base, c.root)) throw new Error('Dossier hors du projet refusé');
  if (!fs.existsSync(base)) throw new Error('Chemin inexistant : ' + (dirRel || '.'));
  const re = glob ? new RegExp('^' + String(glob).replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*\*/g, '\u0000').replace(/\*/g, '[^/]*').replace(/\u0000/g, '.*') + '$', 'i') : null;
  const out = [];
  const visit = p => {
    if (out.length >= 4000) return;
    let st; try { st = fs.lstatSync(p); } catch { return; }
    if (st.isSymbolicLink()) return;
    if (st.isDirectory()) { let ents; try { ents = fs.readdirSync(p); } catch { return; } for (const e of ents.sort()) if (!SKIP_DIRS.has(e)) visit(path.join(p, e)); return; }
    if (st.size > 1024 * 1024 || !CODE_EXT.test(p)) return;
    const rel = path.relative(c.root, p).replace(/\\/g, '/');
    if (!re || re.test(rel) || re.test(path.basename(rel))) out.push(rel);
  };
  visit(base);
  return out;
};
const IDENT = /^[\p{L}_$][\p{L}\p{N}_$]{0,80}$/u;
const ident = (v, label = 'symbole') => { v = String(v || '').trim(); if (!IDENT.test(v)) throw new Error(label + ' invalide : « ' + v.slice(0, 60) + ' » (lettres, chiffres, _ et $ seulement)'); return v; };
const escRe = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const wordRe = (sym, flags = 'u') => new RegExp('(?<![\\p{L}\\p{N}_$])' + escRe(sym) + '(?![\\p{L}\\p{N}_$])', flags);
const defRes = sym => {
  const S = escRe(sym), B = '(?<![\\p{L}\\p{N}_$.])', E = '(?![\\p{L}\\p{N}_$])';
  return [
    ['fonction/classe/type', new RegExp(B + '(?:function\\*?|class|interface|enum|type|namespace|struct|trait|union|fn|def|func|fun|sub|signal|class_name|object|protocol|record)\\s+' + S + E, 'u')],
    ['variable', new RegExp('^\\s*(?:(?:export|public|private|protected|static|final|readonly|pub)\\s+)*(?:const|let|var|val|var)\\s+' + S + E, 'u')],
    ['variable', new RegExp('^\\s*(?:@\\w+(?:\\([^)]*\\))?\\s+)*(?:var|const|onready var|export var)\\s+' + S + E, 'u')],
    ['variable', new RegExp('^\\s*' + S + '\\s*(?::\\s*[\\w\\[\\], .|]+)?\\s*=(?!=)', 'u')],
    ['export', new RegExp('(?:module\\.)?exports\\.' + S + '\\s*=', 'u')],
    ['propriété', new RegExp('^\\s*[\'"]?' + S + '[\'"]?\\s*:\\s*(?:async\\s*)?(?:function\\b|\\()', 'u')],
    ['méthode', new RegExp('^\\s*(?:(?:public|private|protected|static|async|override|virtual|abstract|get|set|final)\\s+)*' + S + '\\s*\\([^)]*\\)\\s*(?::\\s*[\\w<>\\[\\]., ?|]+)?\\s*\\{', 'u')],
    ['fonction C/Java', new RegExp('^\\s*(?!\\s*(?:return|else|new|throw|await|yield|delete|case|if|for|while|switch)\\b)[\\w<>\\[\\]*&:,\\s]+?\\s[*&]*' + S + '\\s*\\([^;]*\\)\\s*(?:const\\s*)?(?:\\{|$)', 'u')],
  ];
};
const defKind = (line, rs) => { for (const [k, re] of rs) if (re.test(line)) return k; return null; };
const readLines = (c, rel) => { try { return fs.readFileSync(path.join(c.root, rel), 'utf8').split('\n'); } catch { return null; } };

// ── Analyse d'une erreur (pile d'appels) ────────────────────────────────────────────────
const resolveFrame = (file, root) => {
  let f = String(file).replace(/^["'(]+|["')]+$/g, '').replace(/^file:\/\/\/?/, '').replace(/^res:\/\//, '');
  const cands = [f, ...f.split(/\s+/).slice(-1)];
  for (const x of cands) {
    for (const p of [path.isAbsolute(x) ? x : null, path.join(root, x)].filter(Boolean)) {
      const abs = path.resolve(p);
      if (!perms.inside(abs, root) || /(^|[\\/])node_modules([\\/]|$)/.test(abs)) continue;
      try { if (fs.statSync(abs).isFile()) return path.relative(root, abs).replace(/\\/g, '/'); } catch { /* suivant */ }
    }
  }
  return null;
};
const parseTrace = (text, root) => {
  const lines = String(text || '').split(/\r?\n/), frames = [], seen = new Set();
  const re = /((?:[A-Za-z]:[\\/]|res:\/\/|file:\/\/\/?|\.{0,2}[\\/])?[\w@.\-\\/ ]+?\.(?:js|mjs|cjs|jsx|ts|tsx|py|gd|c|cc|cpp|h|hpp|cs|java|kt|rs|go|php|rb|lua|sh))["']?[:,]\s*(?:line\s*)?(\d+)(?::(\d+))?/g;
  for (const ln of lines) {
    re.lastIndex = 0; let m;
    while ((m = re.exec(ln))) {
      const rel = resolveFrame(m[1], root); if (!rel) continue;
      const key = rel + ':' + m[2], fn = (/\bat (?:async )?([^\s(]+) \(/.exec(ln) || /, in (\S+)/.exec(ln) || [])[1];
      if (seen.has(key)) { const ex = frames.find(x => x.file === rel && x.line === +m[2]); if (ex && !ex.fn && fn) { ex.fn = fn; if (!ex.col && m[3]) ex.col = +m[3]; } continue; }
      seen.add(key);
      frames.push({ file: rel, line: +m[2], col: m[3] ? +m[3] : null, fn: fn || null });
    }
  }
  let message = '';
  const tb = lines.map((l, i) => /Traceback \(most recent call last\)/.test(l) ? i : -1).filter(i => i >= 0).pop();
  if (tb !== undefined) { const rest = lines.slice(tb + 1).filter(l => l.trim() && !/^\s/.test(l)); message = rest[rest.length - 1] || ''; }
  if (!message) message = (lines.find(l => /^\s*(?:Uncaught\s+)?[\w.$]*(?:Error|Exception|Panic)\b/.test(l) && !/^\s*at\s/.test(l)) || '').trim();
  if (!message) message = (lines.find(l => /(error|erreur|exception|fatal|panic|failed|échec)/i.test(l) && !/^\s*at\s/.test(l)) || '').trim();
  return { message: message.trim().slice(0, 400), frames };
};
const traceReport = (text, root, max = 3) => {
  const { message, frames } = parseTrace(text, root); if (!message && !frames.length) return '';
  const out = [];
  if (message) out.push('Erreur : ' + message);
  if (frames.length) {
    out.push('Pile (fichiers du projet) :');
    frames.slice(0, 6).forEach((f, i) => {
      out.push(`  ${i + 1}. ${f.file}:${f.line}${f.col ? ':' + f.col : ''}${f.fn ? '  dans ' + f.fn : ''}`);
      const L = i < max ? readLines({ root }, f.file) : null;
      if (L) for (let j = Math.max(0, f.line - 3); j <= Math.min(L.length - 1, f.line + 1); j++) out.push(`   ${j + 1 === f.line ? '>' : ' '}${String(j + 1).padStart(4)}│ ${L[j].slice(0, 160)}`);
    });
  }
  return out.join('\n');
};
const killTree = p => { try { if (WIN) spawnSync('taskkill', ['/pid', String(p.pid), '/T', '/F'], { windowsHide: true }); else process.kill(-p.pid, 'SIGKILL'); } catch { try { p.kill('SIGKILL'); } catch { /* déjà arrêté */ } } };
const matcher = v => { v = String(v || ''); if (v.length > 120) throw new Error('motif trop long (120 caractères maximum)'); const m = /^\/(.+)\/([i]?)$/.exec(v); if (m) { try { const r = new RegExp(m[1], 'i'); return t => r.test(t); } catch (e) { throw new Error('expression invalide : ' + e.message); } } const low = v.toLowerCase(); return t => t.toLowerCase().includes(low); };
const logLevel = { error: /error|erreur|exception|fatal|panic|traceback|failed|échec/i, warn: /warn|avertissement|error|erreur|exception|fatal|panic|traceback|failed/i };
const tailFile = (file, maxBytes = 512 * 1024) => { const fd = fs.openSync(file, 'r'); try { const size = fs.fstatSync(fd).size, start = Math.max(0, size - maxBytes), buf = Buffer.alloc(size - start); fs.readSync(fd, buf, 0, buf.length, start); let t = buf.toString('utf8'); if (start > 0) t = t.slice(t.indexOf('\n') + 1); return { size, text: t }; } finally { fs.closeSync(fd); } };

module.exports = h => {
  void h;
  return {
    // ─────────────── Git ───────────────
    git_commit: {
      desc: 'Crée un commit git (ajoute les changements puis valide). Ignore .kairo et node_modules. args:{message, paths?:[fichiers], all?:true}',
      run: async (a, c) => {
        const msg = String(a.message || '').trim();
        if (!msg) throw new Error('message de commit manquant');
        if (msg.length > 500) throw new Error('message trop long (500 caractères maximum)');
        const paths = Array.isArray(a.paths) && a.paths.length ? a.paths.map(p => relPath(p, c)) : null;
        if (paths) git(c, ['add', '--', ...paths]);
        else if (a.all !== false) git(c, ['add', '-A', '--', '.', ':(exclude).kairo', ':(exclude)node_modules']);
        if (!git(c, ['diff', '--cached', '--name-only']).trim()) return 'Rien à valider : aucun changement.';
        git(c, [...identity(c), 'commit', '-m', msg]);
        return git(c, ['log', '-1', '--stat', '--format=%h %s']).trim();
      },
    },
    git_branch: {
      desc: 'Gère les branches git : liste, création, suppression (sûre). args:{action?:"list"|"create"|"delete", name?, from?, force?:false}',
      run: async (a, c) => {
        const act = String(a.action || 'list');
        if (act === 'list') return git(c, ['branch', '-vv', '--no-color']).trim() || 'Aucune branche (aucun commit pour l’instant)';
        const name = refName(a.name, 'nom de branche');
        if (act === 'create') { git(c, ['branch', name, ...(a.from ? [refName(a.from, 'point de départ')] : [])]); return 'Branche « ' + name + ' » créée (utilise git_checkout pour t’y placer).'; }
        if (act === 'delete') { git(c, ['branch', a.force ? '-D' : '-d', name]); return 'Branche « ' + name + ' » supprimée.'; }
        throw new Error('action inconnue : ' + act + ' (list, create, delete)');
      },
    },
    git_checkout: {
      desc: 'Change de branche git (ou en crée une et s’y place). Refuse si des changements seraient écrasés. args:{branch, create?:false}',
      run: async (a, c) => {
        const b = refName(a.branch, 'nom de branche');
        git(c, a.create ? ['checkout', '-b', b] : ['checkout', b]);
        return 'Sur la branche « ' + b + ' ».\n' + git(c, ['status', '--short', '--branch']).trim();
      },
    },
    git_stash: {
      desc: 'Met des changements de côté puis les restaure. args:{action?:"push"|"pop"|"apply"|"list"|"drop", message?, untracked?:false, index?:0}',
      run: async (a, c) => {
        const act = String(a.action || 'push'), idx = Math.max(0, Math.min(99, +a.index || 0)), ref = 'stash@{' + idx + '}';
        if (act === 'list') return git(c, ['stash', 'list']).trim() || 'Aucun stash';
        if (act === 'push') { const o = git(c, [...identity(c), 'stash', 'push', ...(a.untracked ? ['-u'] : []), ...(a.message ? ['-m', String(a.message).slice(0, 200)] : [])]).trim(); return o || 'Rien à mettre de côté'; }
        if (act === 'pop' || act === 'apply' || act === 'drop') return git(c, [...identity(c), 'stash', act, ref]).trim() || 'OK';
        throw new Error('action inconnue : ' + act + ' (push, pop, apply, list, drop)');
      },
    },
    git_restore: {
      desc: 'ANNULE les modifications non validées d’un fichier (retour à la dernière version commitée, perte définitive). args:{path, staged?:false, source?}',
      run: async (a, c) => {
        if (!a.path) throw new Error('chemin manquant (précise le fichier à restaurer)');
        const p = relPath(a.path, c);
        git(c, ['restore', ...(a.staged ? ['--staged'] : []), ...(a.source ? ['--source=' + refName(a.source, 'source')] : []), '--', p]);
        return 'Restauré : ' + p + (a.staged ? ' (retiré de l’index)' : '');
      },
    },

    // ─────────────── Qualité du code ───────────────
    lint_code: {
      desc: 'Analyse le code avec le linter du projet (ESLint, sinon Ruff pour Python). args:{path?, fix?:false}',
      run: async (a, c) => {
        const t = relPath(a.path, c), fix = a.fix ? ['--fix'] : [];
        const eslint = localBin(c, 'eslint');
        let r, name;
        if (eslint) { name = 'ESLint'; r = exec(c, eslint, [t, ...fix]); }
        else if (hasPyFiles(c) && hasCmd(c, 'ruff')) { name = 'Ruff'; r = exec(c, 'ruff', ['check', t, ...fix]); }
        else return 'Aucun linter détecté. Pour JavaScript/TypeScript : deps_install avec packages:["eslint"] (dev:true) ; pour Python : « pip install ruff ».';
        const out = TAIL(r.out + (r.err ? '\n' + r.err : ''), 5000);
        if (r.code === 0) return name + ' : aucun problème.' + (out ? '\n' + out : '');
        if (r.code === 1) return name + ' : problèmes trouvés.\n' + out;
        throw new Error(name + ' a échoué (code ' + r.code + ')\n' + out);
      },
    },
    format_code: {
      desc: 'Reformate le code avec l’outil du projet (Prettier, sinon Ruff/Black pour Python, gofmt pour Go). args:{path?, check?:false (true = seulement vérifier)}',
      run: async (a, c) => {
        const t = relPath(a.path, c), check = !!a.check, prettier = localBin(c, 'prettier');
        let r, name;
        if (prettier) { name = 'Prettier'; r = exec(c, prettier, [check ? '--check' : '--write', t]); }
        else if (hasPyFiles(c) && hasCmd(c, 'ruff')) { name = 'Ruff'; r = exec(c, 'ruff', ['format', ...(check ? ['--check'] : []), t]); }
        else if (hasPyFiles(c) && hasCmd(c, 'black', ['--version'])) { name = 'Black'; r = exec(c, 'black', [...(check ? ['--check'] : []), t]); }
        else if (exists(c, 'go.mod') && hasCmd(c, 'gofmt', ['-h'])) { name = 'gofmt'; r = exec(c, 'gofmt', [check ? '-l' : '-w', t]); }
        else return 'Aucun formateur détecté. Pour JavaScript/TypeScript : deps_install avec packages:["prettier"] (dev:true) ; pour Python : « pip install ruff ».';
        const out = TAIL(r.out + (r.err ? '\n' + r.err : ''), 4000);
        if (r.code === 0 && !(name === 'gofmt' && check && out)) return name + (check ? ' : le code est bien formaté.' : ' : formatage terminé.') + (out ? '\n' + out : '');
        if (check) return name + ' : des fichiers ne sont pas formatés.\n' + out;
        throw new Error(name + ' a échoué (code ' + r.code + ')\n' + out);
      },
    },
    type_check: {
      desc: 'Vérifie les types sans rien modifier (TypeScript avec tsc, Python avec mypy ou pyright). args:{path?}',
      run: async (a, c) => {
        const tsc = localBin(c, 'tsc');
        if (tsc && exists(c, 'tsconfig.json')) { const r = exec(c, tsc, ['--noEmit', '--pretty', 'false']), out = TAIL(r.out + r.err, 5000); return r.code === 0 ? 'tsc : aucune erreur de type.' : 'tsc : erreurs de type.\n' + out; }
        if (hasPyFiles(c)) {
          const t = relPath(a.path, c);
          if (hasCmd(c, 'mypy')) { const r = exec(c, 'mypy', [t]), out = TAIL(r.out + r.err, 5000); return r.code === 0 ? 'mypy : aucune erreur de type.\n' + out : 'mypy : erreurs de type.\n' + out; }
          if (hasCmd(c, 'pyright')) { const r = exec(c, 'pyright', [t]), out = TAIL(r.out + r.err, 5000); return r.code === 0 ? 'pyright : aucune erreur de type.\n' + out : 'pyright : erreurs de type.\n' + out; }
        }
        return tsc ? 'tsc est installé mais il n’y a pas de tsconfig.json à la racine du projet.' : 'Aucun vérificateur de types détecté. TypeScript : deps_install avec packages:["typescript"] (dev:true) et un tsconfig.json ; Python : « pip install mypy ».';
      },
    },

    // ─────────────── Dépendances ───────────────
    deps_install: {
      desc: 'Installe les dépendances du projet (tout, ou seulement certains paquets). Détecte npm/pnpm/yarn/pip. args:{packages?:["nom", "nom@version"], dev?:false, manager?}',
      run: async (a, c) => {
        const pk = (Array.isArray(a.packages) ? a.packages : a.packages ? [a.packages] : []).map(pkgSpec), m = manager(c, a.manager);
        if (pk.length > 30) throw new Error('trop de paquets en une fois (30 maximum)');
        let r;
        if (m === 'pip') {
          const [cmd, args] = pipCmd(c, pk.length ? ['install', ...pk] : exists(c, 'requirements.txt') ? ['install', '-r', 'requirements.txt'] : ['install', '.']);
          r = exec(c, cmd, args, { timeout: 280000 });
        } else {
          const base = { npm: ['install'], pnpm: [pk.length ? 'add' : 'install'], yarn: [pk.length ? 'add' : 'install'] }[m];
          r = exec(c, m, [...base, ...(pk.length && a.dev ? ['-D'] : []), ...pk], { timeout: 280000 });
        }
        const out = TAIL(r.out + (r.err ? '\n' + r.err : ''), 3500);
        if (r.code !== 0) throw new Error(m + ' a échoué (code ' + r.code + ')\n' + out);
        return m + ' : ' + (pk.length ? pk.join(', ') + ' installé(s).' : 'dépendances installées.') + '\n' + out;
      },
    },
    deps_outdated: {
      desc: 'Liste les dépendances qui ont une version plus récente (npm ou pip). Accès réseau. args:{manager?}',
      run: async (a, c) => {
        const m = manager(c, a.manager);
        if (m === 'pip') { const [cmd, args] = pipCmd(c, ['list', '--outdated', '--format=json']), r = exec(c, cmd, args, { timeout: 90000 }); if (r.code !== 0) throw new Error('pip : ' + TAIL(r.err, 800)); return summarizeOutdated('pip', r.out); }
        const r = exec(c, m === 'pnpm' ? 'pnpm' : 'npm', ['outdated', '--json'], { timeout: 90000 });
        if (r.code > 1 || (r.code === 1 && !r.out.trim())) throw new Error('outdated a échoué\n' + TAIL(r.err, 800));
        return summarizeOutdated('npm', r.out);
      },
    },
    deps_audit: {
      desc: 'Cherche des failles de sécurité connues dans les dépendances (npm audit, ou pip-audit). Accès réseau. args:{manager?}',
      run: async (a, c) => {
        const m = manager(c, a.manager);
        if (m === 'pip') { if (!hasCmd(c, 'pip-audit')) return 'pip-audit n’est pas installé (« pip install pip-audit »).'; const r = exec(c, 'pip-audit', [], { timeout: 120000 }); return TAIL(r.out + r.err, 4000) || 'Aucune faille connue.'; }
        const r = exec(c, 'npm', ['audit', '--json'], { timeout: 120000 });
        if (r.code > 1 && !r.out.trim()) throw new Error('npm audit a échoué\n' + TAIL(r.err, 800));
        return summarizeAudit(r.out);
      },
    },

    // ─────────────── Navigation dans le code ───────────────
    find_definition: {
      desc: 'Trouve où un nom (fonction, classe, variable, méthode…) est défini : JS/TS, Python, GDScript, C/C++/C#, Java, Rust, Go… args:{symbol, path?, glob?:"*.ts", max?:1-50}',
      run: async (a, c) => {
        const sym = ident(a.symbol), rs = defRes(sym), max = Math.min(50, Math.max(1, +a.max || 20)), hits = [];
        const files = codeFiles(c, a.path, a.glob);
        for (const f of files) {
          const L = readLines(c, f); if (!L) continue;
          for (let i = 0; i < L.length && hits.length < max; i++) { if (!L[i].includes(sym)) continue; const k = defKind(L[i], rs); if (k) hits.push(`${f}:${i + 1}  [${k}]  ${L[i].trim().slice(0, 160)}`); }
          if (hits.length >= max) break;
        }
        return hits.length ? hits.length + ' définition(s) probable(s) de « ' + sym + ' » (' + files.length + ' fichiers analysés) :\n' + hits.join('\n') : 'Aucune définition trouvée pour « ' + sym + ' » (' + files.length + ' fichiers de code analysés). Essaie find_references ou search_regex.';
      },
    },
    find_references: {
      desc: 'Liste tous les endroits où un nom est utilisé (mot entier), en indiquant les définitions. args:{symbol, path?, glob?, max?:1-200}',
      run: async (a, c) => {
        const sym = ident(a.symbol), re = wordRe(sym), rs = defRes(sym), max = Math.min(200, Math.max(1, +a.max || 80)), files = codeFiles(c, a.path, a.glob), out = []; let n = 0, nf = 0;
        for (const f of files) {
          const L = readLines(c, f); if (!L) continue; let first = true;
          for (let i = 0; i < L.length; i++) {
            if (!L[i].includes(sym) || !re.test(L[i])) continue;
            if (n >= max) break; n++;
            if (first) { out.push(f); first = false; nf++; }
            out.push(`  ${i + 1}${defKind(L[i], rs) ? ' [déf]' : ''}: ${L[i].trim().slice(0, 150)}`);
          }
          if (n >= max) break;
        }
        return n ? `${n} occurrence(s) de « ${sym} » dans ${nf} fichier(s)${n >= max ? ' (limite atteinte)' : ''} :\n` + out.join('\n') : 'Aucune occurrence de « ' + sym + ' » (' + files.length + ' fichiers de code analysés).';
      },
    },
    rename_symbol: {
      desc: 'Renomme un nom dans tout le projet (mot entier, y compris commentaires et chaînes : renommage textuel, pas sémantique). SANS apply:true, simple aperçu. Sauvegardes dans .kairo/backups. args:{from, to, path?, glob?, apply?:true}',
      run: async (a, c) => {
        const from = ident(a.from, 'ancien nom'), to = ident(a.to, 'nouveau nom');
        if (from === from.toUpperCase() && from.length < 2) throw new Error('nom trop court pour un renommage automatique');
        if (from === to) throw new Error('l’ancien et le nouveau nom sont identiques');
        const re = wordRe(from, 'gu'), reTo = wordRe(to), files = codeFiles(c, a.path, a.glob), rows = []; let total = 0, collide = 0;
        for (const f of files) {
          let t; try { t = fs.readFileSync(path.join(c.root, f), 'utf8'); } catch { continue; }
          if (reTo.test(t)) collide++;
          const n = (t.match(re) || []).length; if (!n) continue;
          total += n; rows.push({ f, n, t });
        }
        if (!rows.length) return 'Aucune occurrence de « ' + from + ' » (' + files.length + ' fichiers de code analysés).';
        if (rows.length > 300) throw new Error(rows.length + ' fichiers concernés : trop pour un renommage automatique (300 maximum). Précise path ou glob.');
        const warn = collide ? `\nAttention : « ${to} » existe déjà dans ${collide} fichier(s) : vérifie qu'il n'y a pas de collision.` : '';
        const list = rows.slice(0, 60).map(r => `  ${r.f} : ${r.n}`).join('\n') + (rows.length > 60 ? `\n  … et ${rows.length - 60} autre(s) fichier(s)` : '');
        if (!a.apply) return `Aperçu : « ${from} » → « ${to} » : ${total} occurrence(s) dans ${rows.length} fichier(s). Relance avec apply:true pour appliquer.${warn}\n${list}`;
        for (const r of rows) {
          const p = path.join(c.root, r.f), after = r.t.replace(re, to);
          await h.backup(c, p, r.t, after, true); fs.writeFileSync(p, after); c.created?.add(p);
        }
        return `Renommé « ${from} » → « ${to} » : ${total} occurrence(s) dans ${rows.length} fichier(s) (sauvegardes dans .kairo/backups).${warn}\n${list}`;
      },
    },

    // ─────────────── Débogage ───────────────
    run_with_trace: {
      desc: 'Lance une commande et, si elle échoue, analyse l’erreur : message, pile d’appels dans les fichiers du projet et extrait de code autour de chaque ligne. Mêmes règles de sécurité que run_command. args:{command, timeout?:secondes (défaut 120, max 300)}',
      run: async (a, c) => {
        const cmd = String(a.command || '').trim(); if (!cmd) throw new Error('commande vide');
        let text, failed = false;
        try { text = String(await h.tools.run_command.run({ command: cmd, timeout: a.timeout }, c)); }
        catch (e) { text = String(e.message || e); if (!/^exit \S+/.test(text)) throw e; failed = true; }
        if (!failed) return 'Succès — ' + text.slice(0, 3500);
        const rep = traceReport(text, c.root);
        return `✗ Échec de « ${cmd.slice(0, 120)} » (${text.split('\n')[0]})\n` + (rep ? rep + '\n\n' : 'Aucune pile d’appels reconnue dans la sortie.\n\n') + 'Fin de la sortie :\n' + TAIL(text.split('\n').slice(1).join('\n'), 1800);
      },
    },
    read_logs: {
      desc: 'Lit la fin d’un fichier de log (ou liste les logs du projet), avec filtre texte ou niveau. args:{path?, lines?:1-500, filter?, level?:"error"|"warn"}',
      run: async (a, c) => {
        const n = Math.min(500, Math.max(1, +a.lines || 80)), lvl = a.level ? logLevel[String(a.level)] : null;
        if (a.level && !lvl) throw new Error('niveau inconnu (error ou warn)');
        const flt = a.filter ? String(a.filter).toLowerCase() : null;
        const base = perms.norm(a.path || '.', c.root); if (!perms.inside(base, c.root)) throw new Error('Chemin hors du projet refusé');
        if (!fs.existsSync(base)) throw new Error('Chemin inexistant : ' + (a.path || '.'));
        let file = base;
        if (fs.statSync(base).isDirectory()) {
          const logs = []; const visit = (d, depth) => { let ents; try { ents = fs.readdirSync(d, { withFileTypes: true }); } catch { return; } for (const e of ents) { if (SKIP_DIRS.has(e.name) || e.isSymbolicLink()) continue; const p = path.join(d, e.name); if (e.isDirectory()) { if (depth < 4) visit(p, depth + 1); } else if (/\.log$|\.log\.\d+$/i.test(e.name) || /(^|[\\/])logs?[\\/]/i.test(path.relative(c.root, p))) { try { logs.push({ p, m: fs.statSync(p).mtimeMs, s: fs.statSync(p).size }); } catch { /* ignoré */ } } } };
          visit(base, 0); logs.sort((x, y) => y.m - x.m);
          if (!logs.length) return 'Aucun fichier de log trouvé (*.log ou dossier logs/).';
          file = logs[0].p;
          var head = 'Logs du projet (du plus récent) :\n' + logs.slice(0, 8).map(l => `  ${path.relative(c.root, l.p).replace(/\\/g, '/')} (${Math.round(l.s / 1024)} Ko, ${new Date(l.m).toISOString().slice(0, 16).replace('T', ' ')})`).join('\n') + '\n\n';
        }
        const { size, text } = tailFile(file);
        let L = text.split(/\r?\n/); if (L.length && !L[L.length - 1]) L.pop();
        if (flt) L = L.filter(l => l.toLowerCase().includes(flt)); if (lvl) L = L.filter(l => lvl.test(l));
        const shown = L.slice(-n);
        return (head || '') + `${path.relative(c.root, file).replace(/\\/g, '/')} (${Math.round(size / 1024)} Ko) — ${shown.length} ligne(s)${L.length > n ? ' sur ' + L.length + ' (les dernières)' : ''}${flt ? ' · filtre « ' + a.filter + ' »' : ''}${lvl ? ' · niveau ' + a.level : ''}\n` + (shown.length ? TAIL(shown.map(l => l.slice(0, 300)).join('\n'), 12000) : 'Aucune ligne ne correspond.');
      },
    },
    watch_process: {
      desc: 'Lance une commande qui tourne longtemps (serveur de dev, tests en mode watch…), surveille sa sortie pendant quelques secondes, puis l’arrête et rapporte ce qui s’est passé. Mêmes règles de sécurité que run_command. args:{command, seconds?:1-60 (défaut 15), until?:"texte ou /regex/ qui indique que c’est prêt"}',
      run: (a, c) => new Promise((resolve, reject) => {
        const cmd = String(a.command || '').trim(); if (!cmd) return reject(new Error('commande vide'));
        const secs = Math.min(60, Math.max(1, +a.seconds || 15)); let until = null; try { until = a.until ? matcher(a.until) : null; } catch (e) { return reject(e); }
        const t0 = Date.now(); let out = '', done = false, matched = false, code = null;
        const p = require('child_process').spawn(cmd, { shell: true, cwd: c.root, windowsHide: true, detached: !WIN });
        const finish = why => {
          if (done) return; done = true; clearTimeout(timer); const running = code === null; if (running) killTree(p);
          const rep = (matched && !/(error|erreur|exception)/i.test(out)) ? '' : traceReport(out, c.root);
          resolve(`watch_process : ${why} (${((Date.now() - t0) / 1000).toFixed(1)} s)${running ? ' — processus arrêté' : ''}\n` + (rep ? rep + '\n\n' : '') + '--- sortie (fin) ---\n' + (TAIL(out, 4500) || '(aucune sortie)'));
        };
        const on = s => d => { const t = String(d); out += t; if (out.length > 200000) out = out.slice(-100000); c.emit?.('term', { stream: s, text: t }); if (until && !matched && until(out)) { matched = true; setTimeout(() => finish('motif « ' + String(a.until).slice(0, 60) + ' » trouvé'), 300); } };
        p.stdout.on('data', on('stdout')); p.stderr.on('data', on('stderr'));
        p.on('error', e => { out += e.message; finish('impossible de démarrer'); });
        p.on('close', k => { code = k; finish('terminé avec le code ' + k); });
        const timer = setTimeout(() => finish('toujours en cours après ' + secs + ' s'), secs * 1000);
      }),
    },

    // ─────────────── Recherche web ───────────────
    web_search: {
      desc: 'Cherche sur le web (DuckDuckGo, sans clé API) et renvoie titres, adresses et extraits. Utilise ensuite fetch_url pour lire une page. args:{query, n?:1-10}',
      run: async (a, c) => {
        const q = String(a.query || '').trim().replace(/\s+/g, ' ');
        if (!q) throw new Error('requête vide');
        if (q.length > 300) throw new Error('requête trop longue (300 caractères maximum)');
        const n = Math.min(10, Math.max(1, +a.n || 5)), searx = String(c.settings?.searchUrl || '').replace(/\/+$/, '');
        let rows = [];
        if (searx) {
          if (!/^https?:\/\//i.test(searx)) throw new Error('searchUrl invalide dans les réglages');
          const r = await fetch(searx + '/search?format=json&q=' + encodeURIComponent(q), { signal: AbortSignal.timeout(15000), headers: { accept: 'application/json' } });
          if (!r.ok) throw new Error('SearXNG a répondu ' + r.status);
          rows = parseSearx(await r.text());
        } else {
          const r = await fetch('https://html.duckduckgo.com/html/', { method: 'POST', signal: AbortSignal.timeout(15000), headers: { 'content-type': 'application/x-www-form-urlencoded', 'user-agent': 'Mozilla/5.0 (compatible; AstraAgent/1.8)', 'accept-language': 'fr-FR,fr;q=0.9,en;q=0.7' }, body: 'q=' + encodeURIComponent(q) + '&kl=fr-fr' });
          if (!r.ok) throw new Error('DuckDuckGo a répondu ' + r.status);
          rows = parseDuckDuckGo(await r.text());
        }
        return formatResults(q, rows, n) || 'Aucun résultat (ou le moteur a bloqué la requête). Reformule, ou utilise fetch_url sur une page précise.';
      },
    },
  };
};

module.exports.META = {
  git_commit: ['Git', 'CONFIRM'], git_branch: ['Git', 'variable'], git_checkout: ['Git', 'CONFIRM'], git_stash: ['Git', 'variable'], git_restore: ['Git', 'DANGER'],
  lint_code: ['Qualité', 'SAFE'], format_code: ['Qualité', 'CONFIRM'], type_check: ['Qualité', 'SAFE'],
  deps_install: ['Dépendances', 'CONFIRM'], deps_outdated: ['Dépendances', 'CONFIRM'], deps_audit: ['Dépendances', 'CONFIRM'],
  web_search: ['Réseau', 'CONFIRM'],
  find_definition: ['Navigation', 'SAFE'], find_references: ['Navigation', 'SAFE'], rename_symbol: ['Navigation', 'CONFIRM'],
  run_with_trace: ['Débogage', 'variable'], read_logs: ['Débogage', 'SAFE'], watch_process: ['Débogage', 'variable'],
};
module.exports.summarizeOutdated = summarizeOutdated;
module.exports.summarizeAudit = summarizeAudit;
module.exports.parseDuckDuckGo = parseDuckDuckGo;
module.exports.parseSearx = parseSearx;
module.exports.pkgSpec = pkgSpec;
module.exports.refName = refName;
module.exports.parseTrace = parseTrace;
module.exports.traceReport = traceReport;
module.exports.defRes = defRes;
module.exports.defKind = defKind;
module.exports.helpers = { relPath, TAIL, killTree, SKIP_DIRS, readLines, traceReport, matcher, exists, WIN };
