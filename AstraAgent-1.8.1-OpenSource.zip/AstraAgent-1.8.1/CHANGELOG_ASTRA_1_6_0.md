# Astra Agent 1.6.0 — Council, Time Machine & Open Source

## Astra Agent Council
- 2 à 4 modèles peuvent produire des analyses indépendantes.
- Un président compare les propositions et rédige une synthèse structurée.
- Les appels et réponses sont conservés dans l'historique local du projet (20 derniers conseils).
- Le nombre d'appels est explicite : un appel par membre, puis un appel de synthèse. Les fournisseurs cloud peuvent facturer ces appels.

## Astra Agent Time Machine
- Snapshots locaux nommés, limités à 30 par projet.
- Empreinte SHA-256 et validation des données avant restauration.
- Exclusion des secrets, `.env`, clés privées, `.git`, `node_modules`, données internes et caches.
- La restauration crée automatiquement un snapshot de sécurité préalable.
- Les fichiers ajoutés depuis le snapshot sont déplacés en quarantaine, pas supprimés.
- Confirmation explicite requise pour restaurer ou supprimer un snapshot.

## Open source
- Licence MIT, README, guide de contribution, politique de sécurité et code de conduite.
- `.gitignore` et `.env.example` pour éviter de publier les données locales ou secrets.
- Le dépôt ne contient aucune clé API ni donnée d'exécution locale.

## Préservation
- Astra Communication Graph (module 2), Astra Model Intelligence (module 6), Astra Command Center (module 11), Astra Swarm et le convertisseur Image-to-Data existant sont conservés.

## Limites
- Le Council effectue des appels réels aux providers configurés ; il n'est pas un benchmark et ne peut pas garantir l'exactitude de la synthèse.
- Time Machine est une sauvegarde locale de fichiers, pas un système de versionnement Git ni une sauvegarde hors machine.
- Les nouveaux modules ont des tests automatisés locaux ; les providers cloud ne sont pas déclarés testés avec de vraies clés.
