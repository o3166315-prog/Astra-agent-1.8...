# Astra Agent 1.7.3

## Modes de discussion
- La liste des modes (en haut du panneau Agent) propose maintenant : **Auto**, **Agent**, **Discussion** et **Discussion éphémère**.
- « Discussion éphémère » démarre une conversation privée : rien n'est enregistré (ni historique, ni mémoire du projet), et l'agent n'agit pas sur les fichiers (le serveur force le mode discussion). Elle disparaît quand tu changes de mode, de discussion ou de projet.
- Le petit bouton « Éphémère » sous la liste des discussions est retiré.
- « Chat » est renommé « Discussion ».
