# Astra Agent 1.7.4

## Mode Auto amélioré
- Auto = tu discutes normalement ; quand la demande est une vraie tâche (« recrée-moi Minecraft sur navigateur », « fais-moi un jeu de snake », « construis une API », « corrige le bug dans index.js »…), l'agent passe tout seul en mode Agent et l'écrit dans la discussion.
- Les questions de culture générale (« c'est quoi un script ? », « pourquoi… ») restent en discussion, sauf si elles parlent d'un fichier ou d'une erreur du projet.
- Nouveau module `server/automode.js`, testé.
- « Chat » retrouve son nom dans la liste des modes (Auto, Agent, Chat, Discussion éphémère).

## Nouveaux outils (6) — étape 2 de la V1.8
L'agent passe de 56 à 62 outils.

| Outil | Rôle | Permission |
|---|---|---|
| `find_definition` | où un nom est défini (JS/TS, Python, GDScript, C/C++/C#, Java, Rust, Go…) | SAFE |
| `find_references` | tous les usages d'un nom (mot entier), définitions marquées | SAFE |
| `rename_symbol` | renomme un nom dans tout le projet (textuel, par mot entier) ; aperçu par défaut, sauvegardes dans `.kairo/backups` | aperçu = SAFE, `apply` = CONFIRM |
| `run_with_trace` | lance une commande ; en cas d'échec : message d'erreur, pile d'appels dans le projet et extrait de code | comme `run_command` |
| `read_logs` | fin d'un fichier de log, filtre texte, niveau error/warn, liste des logs | SAFE |
| `watch_process` | lance un serveur/watcher, surveille la sortie quelques secondes (ou jusqu'à un motif), puis l'arrête | comme `run_command` |

Limites : `rename_symbol` ne comprend pas le code (il renomme aussi dans les commentaires et les chaînes) ; `find_definition` repose sur des motifs et peut rater des cas exotiques.

## Tests
- Nouveau `tests/devtools2.test.js` (12 contrôles : vrais fichiers JS/Python/GDScript/C++, vrais processus, aucun accès réseau).
