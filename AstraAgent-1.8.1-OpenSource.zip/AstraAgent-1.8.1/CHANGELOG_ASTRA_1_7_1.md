# Astra Agent 1.7.1

## Mascotte
- Nouvelle mascotte originale (`public/mascot.svg`) : petit robot rond **blanc et noir**, visage noir avec deux yeux ovales, antenne terminée par une étoile. Contours noirs : elle reste lisible sur fond clair comme sur fond noir.
- Animations intégrées au SVG (CSS, donc elles tournent partout où la mascotte est affichée) : flottement, ombre qui respire, antenne qui se balance, étoile qui scintille, clignement des yeux, regard qui se déplace, bras droit qui salue, bras gauche qui bouge, sourire qui s’agrandit.
- Respecte `prefers-reduced-motion` (animations coupées si le système le demande).
- Animations de l’interface : petit « salut » au survol de la mascotte dans la barre du haut, rebond quand l’agent termine une tâche, flottement pendant qu’il travaille. Les lueurs bleues autour de la mascotte sont devenues blanches.

## Thème Sombre
- Le thème **Sombre** est maintenant un vrai noir (`#000` pour le fond et l’éditeur, gris neutres pour les panneaux) au lieu d’un bleu très foncé.
- Le thème **Bleu nuit** reste disponible tel quel.
- Bordures et survols qui étaient en bleu fixe : ils suivent maintenant les couleurs du thème. Fonds assombris des boîtes de dialogue : noir neutre.
