# Astra Agent 1.6.1 — durcissement et intégration

## Sécurité et fiabilité
- Rejet des liens symboliques et liens matériels dans les racines, chemins de projet et parcours de fichiers.
- Racines `/` et dossier personnel refusés comme workspace.
- `calculate()` et la calculatrice du serveur MCP de démonstration utilisent le parseur arithmétique dédié ; aucune évaluation JavaScript dynamique.
- Expressions avec accès de propriété, identifiants inconnus ou syntaxe JavaScript refusées.
- JSON de requête invalide : HTTP 400.
- Écriture atomique des réglages JSON par fichier temporaire, synchronisation et renommage.
- Enregistrement d'une clé sans nouvelle URL : URL du provider préservée.
- Recovery partage le moteur Time Machine ; les fichiers ajoutés depuis un snapshot sont mis en quarantaine.

## Modules intégrés depuis 1.5.6
- Self-Healing : analyse statique et diagnostic assisté en lecture seule.
- Auto Testing : détection des commandes de tests et rapports ; lancement manuel avec confirmation, auto-test après modification opt-in.
- Astra Voice : dictée et lecture vocale basées sur les APIs du navigateur.
- Mission Recovery & Export : missions, checkpoints, restauration et export ZIP.

## Limites explicites
- Cloud persistant, comptes, dashboard Web/mobile, Marketplace avec sandbox et Astra Image Engine ne sont pas livrés dans cette version.
- Les tests automatisés ne prouvent pas le fonctionnement de providers cloud réels sans clés API.
- Les contrôles de chemins réduisent les risques de liens symboliques et matériels, mais les vérifications de chemins suivies d’une opération fichier gardent un risque TOCTOU : ce n’est pas une sandbox OS.
- Les serveurs MCP tiers configurés par l’utilisateur s’exécutent avec les droits du compte local ; ils ne sont pas isolés dans un conteneur dédié. N’ajouter que des serveurs de confiance.
