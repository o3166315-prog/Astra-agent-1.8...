# Astra Agent 1.7.0 — Release verification

## Included

- Dynamic model discovery for OpenAI, Anthropic and Google Gemini.
- 14 OpenAI-compatible provider entries: OpenRouter, Groq, Together AI, Fireworks AI, DeepSeek, Mistral, xAI, Perplexity, DeepInfra, SiliconFlow, Alibaba Cloud DashScope, Nebius AI Studio, Baseten custom endpoints and Cloudflare custom gateways.
- User-configurable API base URL overrides for compatible providers.
- English README, changelog, feature status and release notes.
- Retained 1.6.1 hardened code and tests.

## Test result

`npm test` completed successfully in the build environment, including the new model-discovery test. Provider HTTP calls in the new discovery test are mocked. No live API credentials were used, so no real provider account, billing entitlement, model availability or geographic access is certified by this test.

## Language status

The documentation and release metadata are in English. The existing application interface still contains French strings; the `lang` metadata is set to English, but this does not constitute a complete UI translation. Do not advertise this archive as a fully English-localized interface until that translation is completed and reviewed.

## Not included as completed features

Persistent cloud execution, account sync, remote mobile dashboard, isolated plugin marketplace and full image-generation engine remain roadmap items.
