# Astra Agent 1.7.2

## Nouveaux outils (12) — étape 1 de la V1.8
L'agent passe de 44 à 56 outils.

| Outil | Rôle | Permission |
|---|---|---|
| `git_commit` | commit (ignore `.kairo` et `node_modules`, identité de secours si git n'est pas configuré) | CONFIRM |
| `git_branch` | lister / créer / supprimer une branche | lister = SAFE, créer = CONFIRM, supprimer = CONFIRM (forcé = DANGER) |
| `git_checkout` | changer de branche | CONFIRM |
| `git_stash` | mettre des changements de côté | lister = SAFE, le reste = CONFIRM |
| `git_restore` | annuler des modifications non validées | DANGER |
| `lint_code` | ESLint, sinon Ruff | SAFE (`fix` = CONFIRM) |
| `format_code` | Prettier, sinon Ruff / Black / gofmt | CONFIRM (`check` = SAFE) |
| `type_check` | tsc, mypy ou pyright | SAFE |
| `deps_install` | npm / pnpm / yarn / pip (noms de paquets validés) | CONFIRM |
| `deps_outdated` | paquets à mettre à jour | CONFIRM (réseau) |
| `deps_audit` | failles de sécurité connues | CONFIRM (réseau) |
| `web_search` | recherche web DuckDuckGo sans clé API (ou une instance SearXNG via `searchUrl`) | CONFIRM (réseau) |

Aucune commande n'est passée à un shell (sauf les `.cmd` de Windows, dont les arguments sont strictement validés).

## Prénom
- Au premier lancement, une fenêtre demande ton prénom (bouton « Passer » possible).
- Il est enregistré une seule fois dans les réglages et ajouté automatiquement au contexte de l'agent dans toutes les discussions. Modifiable dans Paramètres › Profil.

## Discussions éphémères
- Bouton « Éphémère » sous la liste des discussions.
- Rien n'est écrit sur le disque : ni historique, ni mémoire du projet, ni mission de récupération. L'historique ne vit que dans la mémoire du serveur le temps de la session et disparaît quand tu changes de discussion ou de projet.

## Interface
- Le catalogue d'outils n'est plus un onglet ni une carte de l'accueil : il s'ouvre depuis Paramètres › « Outils de l'agent » (ou la palette de commandes).
- L'accueil propose maintenant une carte « Paramètres » à la place.

## Tests
- Nouveau `tests/devtools.test.js` (13 contrôles, vrai dépôt git temporaire, aucun accès réseau).
