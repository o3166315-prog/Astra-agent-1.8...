# Community Code of Conduct

Contributors are expected to be respectful, constructive, and welcoming. Harassment, discrimination, threats, doxxing, and personal attacks are not acceptable.

Maintain a focus on technical discussion, assume good faith where reasonable, and accept feedback professionally. Project maintainers may remove content or participation that violates these expectations.
