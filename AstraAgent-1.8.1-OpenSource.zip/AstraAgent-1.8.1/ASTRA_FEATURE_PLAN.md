# Astra Agent — Release status and roadmap

A feature is described as available only when it exists in the code and has an appropriate test or verification path.

## Implemented in 1.7.0

- [x] Astra Model Discovery for native and OpenAI-compatible providers.
- [x] Dynamic model listing for OpenAI, Anthropic and Gemini.
- [x] Compatible provider adapters: OpenRouter, Groq, Together AI, Fireworks AI, DeepSeek, Mistral, xAI, Perplexity, DeepInfra, SiliconFlow, Alibaba Cloud DashScope and Nebius AI Studio.
- [x] Custom-compatible endpoint configuration for Baseten and Cloudflare gateways.
- [x] Astra Swarm (2–4 agents, isolated workspaces and manual review/merge flow).
- [x] Astra Council (2–4 model participants and a synthesis step).
- [x] Astra Communication Graph and activity timeline.
- [x] Astra Time Machine with local snapshots, integrity checks and quarantine-based recovery.
- [x] Model Intelligence and Command Center.
- [x] Self-Healing diagnostics (read-only recommendations; no silent repair).
- [x] Auto Testing with user-confirmed test execution.
- [x] Browser/OS-based voice input and speech synthesis where supported.
- [x] Mission recovery/export features inherited from 1.6.1.
- [x] Path, symlink/hard-link, JSON parsing, settings persistence and recovery hardening.

## Not completed — do not advertise as available

- [ ] Persistent cloud task backend that continues while the local PC is off.
- [ ] Account system and secure multi-device synchronization.
- [ ] Remote mobile dashboard.
- [ ] Isolated plugin marketplace, public SDK and signed extension distribution.
- [ ] Full image generation/editing engine (separate from Image-to-Data).
- [ ] Native desktop installer and signed Windows release package.

## Model capability policy

- Provider catalogues are the source of model IDs; no guessed model names.
- Model discovery is separate from account entitlement and regional availability.
- Capabilities use `supported`, `unsupported` or `unknown` states. Unknown is never silently promoted to supported.
- Pricing is displayed only when sourced from a provider catalogue or explicitly configured by the user.
