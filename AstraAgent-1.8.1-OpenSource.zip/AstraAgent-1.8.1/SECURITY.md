# Security policy

## Reporting a vulnerability
Please do not publish an exploitable vulnerability or API key in a public issue. Contact the project maintainer privately through the security contact configured on the repository. If no private contact is configured yet, ask for one in a non-sensitive issue without including exploit details.

## Security expectations
- Keep the HTTP server bound to `127.0.0.1` by default.
- Preserve Host, Origin, and API-token checks.
- Keep provider credentials on the local machine; never expose them to browser code, model prompts, logs, or commits.
- Keep file operations confined to the selected workspace and reject traversal and unsafe symlinks.
- Destructive actions and external/system operations must remain behind explicit permission checks.
- Snapshots exclude credential files and local runtime state. Review snapshot contents before sharing them.

## Supported versions
Security fixes target the latest published version. Older versions may not receive fixes.
