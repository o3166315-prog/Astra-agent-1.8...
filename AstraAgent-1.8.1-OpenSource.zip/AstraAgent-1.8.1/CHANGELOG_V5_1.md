# Kairo V5.1.0 — 19 nouveaux outils

Tous les outils vivent dans `server/moretools.js`, sont classés dans `server/perms.js` (SAFE / CONFIRM / DANGER) et testés dans `tests/newtools.test.js` (22 tests).

## Fichiers
- `edit_file` : remplace un passage exact (erreur si introuvable ou ambigu, `all:true` pour tout remplacer) ; diff + sauvegarde annulable comme `write_file`.
- `append_file`, `read_lines` (plage numérotée), `find_files` (glob), `file_info` (taille, lignes, SHA-256), `move_file`, `copy_file`, `make_dir`, `diff_files`.
- `replace_in_files` : aperçu par défaut, n'écrit qu'avec `apply:true`, limité au projet, sauvegardes dans `.kairo/backups`.

## Développement
- `check_syntax` (js, mjs, cjs, json, py) sans exécuter le fichier.
- `run_tests` : détecte `npm test`, pytest, cargo, go ou ctest et applique les permissions de la commande détectée.
- `project_summary` : technologies, scripts, répartition des fichiers.
- `json_query` : lit une valeur par chemin (`scripts.test`, `items[0].name`).
- `todo` : liste de tâches persistante du projet (`.kairo/todo.json`).

## Utilitaires
- `calculate` : évaluateur mathématique à liste blanche (aucun accès au code JavaScript).
- `get_time` (fuseaux IANA), `system_info`.
- `http_request` : GET/POST/PUT/PATCH/DELETE/HEAD pour tester une API ; localhost = SAFE, sinon CONFIRM (réseau).

## Agent
- `edit_file` et `append_file` déclenchent la vérification avant conclusion, comme `write_file` ; `run_tests` compte comme vérification.
- Les nouveaux outils en lecture seule ne déclenchent pas de capture automatique.

## V5.1.1 — Meta en avant + mascotte animée

- **Meta AI · Muse** est le provider par défaut (au lieu d’Ollama).
- Liste des providers : Meta toujours en premier avec le préfixe ★.
- Panneau Paramètres : bloc Meta mis en évidence (badge « RECOMMANDÉ », fond plus marqué).
- **Mascotte animée** (`mascot.svg`) : clignement des yeux, antennes qui bougent, pointeau qui pulse, lévitation douce.
- Animations CSS : idle (flottement), busy (pulse + halo), success (pop) à la fin d’une tâche.
- Logo de la barre latérale : micro-animation de respiration.
