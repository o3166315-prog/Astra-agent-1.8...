# Astra Agent 1.8.0

L'agent passe de 44 à **72 outils**. Cette version regroupe les étapes 1 à 3 du plan « outils de développement » (1.7.2 → 1.7.4 → 1.8.0).

## Étape 3 — 10 nouveaux outils

| Outil | Rôle | Permission |
|---|---|---|
| `start_dev_server` | lance un serveur en arrière-plan (commande, script `dev`/`start`/`serve` de package.json, ou fichiers du projet en statique) et attend qu'il soit prêt ; 3 serveurs maximum | comme `run_command` (statique : CONFIRM) |
| `stop_dev_server` | arrête un serveur lancé par l'agent et rend la fin de sa sortie | SAFE |
| `check_port` | un port écoute-t-il ? liste des serveurs de l'agent, lecture de leurs logs | SAFE |
| `screenshot_page` | capture d'une page (Edge / Chrome / Chromium sans interface) enregistrée dans `.kairo/screenshots`, décrite sans modèle de vision | CONFIRM (page distante = réseau) |
| `scaffold_project` | modèles : `html-site`, `html-game`, `node-cli`, `node-api`, `python-cli`, `godot-2d` ; n'écrase jamais | CONFIRM |
| `generate_tests` | squelette de tests pour un fichier JS (node:test) ou Python (unittest) ; cas à compléter marqués todo/skip | CONFIRM |
| `create_readme` | README.md en français à partir du projet | CONFIRM |
| `zip_files` | archive .zip (ignore node_modules, .git, .kairo, .env) | CONFIRM |
| `unzip_files` | extraction sûre : refuse `../`, chemins absolus, `.git`, archives piégées ; n'écrase rien | CONFIRM |
| `patch_apply` | applique un diff unifié (`git diff`, `diff -u`) : plusieurs fichiers, création, décalages tolérés, tout ou rien, `check` et `reverse` | CONFIRM (`check` = SAFE) |

Remarques :
- `screenshot_page` essaie plusieurs réglages du navigateur sans interface (leur comportement varie selon les versions) ; il peut donc prendre quelques secondes de plus si le premier essai ne répond pas.
- Les serveurs lancés par l'agent sont arrêtés à la fermeture d'Astra Agent.
- Les modèles de projet sont de vrais fichiers dans `server/templates/` : tu peux les modifier ou en ajouter.
- La liste des outils envoyée au modèle est plus longue (≈ 3 200 tokens contre ≈ 1 500) : à surveiller avec un petit modèle local.

## Tests
- Nouveau `tests/devtools3.test.js` : 17 contrôles (vrais serveurs HTTP, vrais processus, archives ZIP relues par Python, diffs produits par `diff -u`, modèles exécutés pour de bon, faux navigateur pour la capture).

## Récapitulatif depuis la 1.7.1
- Mascotte blanche et noire animée, thème Sombre en vrai noir (1.7.1).
- 12 outils : Git, lint/format/types, dépendances, recherche web ; prénom au premier lancement ; discussions éphémères ; catalogue d'outils dans Paramètres (1.7.2).
- Liste des modes Auto / Agent / Chat / Discussion éphémère (1.7.3).
- Mode Auto qui passe tout seul en Agent pour une tâche ; 6 outils de navigation et de débogage (1.7.4).
