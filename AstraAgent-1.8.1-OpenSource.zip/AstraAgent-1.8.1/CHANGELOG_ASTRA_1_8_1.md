# Astra Agent 1.8.1

## Interface — navigation simplifiée

- Remplacement des 14 onglets visibles du panneau droit par quatre espaces : Agent, Outils, Activité et Mémoire.
- Les fonctions secondaires sont accessibles via un sélecteur compact dans Outils et Activité.
- Les fonctions existantes sont conservées : Swarm, Council, réparation, tests, terminal, aperçu, MCP, écran, Time Machine, récupération, plan, historique et mémoire.
- Les réglages de configuration restent accessibles depuis la fenêtre Paramètres.
- Aucun outil ni endpoint serveur n'a été supprimé ou modifié dans cette réorganisation.
