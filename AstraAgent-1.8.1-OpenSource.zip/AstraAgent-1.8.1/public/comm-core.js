/* Astra Communication Graph — noyau partagé (navigateur + Node).
   Principe : le graphe n'invente RIEN. Il reconstruit les échanges à partir des événements réellement
   enregistrés par Astra Swarm (plan, statuts des agents, erreurs, revue). Aucun message fictif.
   Dans l'état actuel de Swarm, les échanges réels sont :
     Coordinateur → Agent   : TASK_ASSIGNMENT (tâche attribuée par le plan)
     Agent → Coordinateur   : STATUS_UPDATE (démarrage, pause, reprise, arrêt) et ERROR
     Agent → Reviewer       : TASK_RESULT (rapport de fin de tâche)
     Reviewer → Coordinateur: RESPONSE (rapport de revue)
   Les agents ne s'envoient pas encore de QUESTION entre eux : aucun message de ce type n'est affiché. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.AstraComm = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  const COORD = 'coordinator', REVIEWER = 'reviewer';
  const TERMINAL = new Set(['completed', 'failed', 'stopped']);
  const MISSION_DONE = new Set(['ready_for_review', 'completed_with_errors', 'completed_with_conflicts', 'integrated', 'failed']);
  const ts = v => { const n = Date.parse(v); return Number.isFinite(n) ? n : 0; };
  const pad = n => String(n).padStart(4, '0');
  const clip = (s, n) => String(s == null ? '' : s).slice(0, n);

  function fmtDuration(ms) {
    if (!Number.isFinite(ms) || ms < 0) return '—';
    const s = Math.round(ms / 1000), m = Math.floor(s / 60);
    return String(m).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
  }

  function buildGraph(mission, opts) {
    opts = opts || {};
    const now = opts.now || Date.now();
    mission = mission || {};
    const workers = (mission.workers || []).map(w => ({ ...w }));
    const byId = Object.fromEntries(workers.map(w => [w.id, w]));
    const events = (mission.events || []).map((e, i) => ({ e, i, t: ts(e.at || (e.event && e.event.at)) }))
      .sort((a, b) => a.t - b.t || a.i - b.i).map(x => ({ ...x.e, _t: x.t }));
    const missionDone = MISSION_DONE.has(mission.status);
    const messages = [], timeline = [], alerts = [];
    const firstWork = {}, lastWork = {}, finishAt = {}, lastActivity = {};
    let seq = 0, reviewStartAt = 0, planSeen = false, reviewDone = false;
    const nameOf = id => id === COORD ? 'Coordinateur' : id === REVIEWER ? 'Reviewer' : (byId[id] && (byId[id].name || byId[id].id)) || id;
    const push = (from, to, type, content, t, status) => {
      const m = { id: 'msg_' + pad(++seq), missionId: mission.id || '', from, to, type, content: clip(content, 1500), timestamp: t, status: status || 'delivered' };
      messages.push(m); return m;
    };
    const tl = (t, actor, text, kind) => timeline.push({ at: t, actor, text: clip(text, 400), kind: kind || 'event' });
    const pendingAssign = {}, pendingResult = {};
    const errorSeen = new Set();

    if (mission.createdAt) tl(ts(mission.createdAt), 'Astra Swarm', 'Mission créée : ' + clip(mission.title || mission.id || '', 120), 'mission');

    for (const ev of events) {
      const t = ev._t, type = String(ev.type || '');
      if (type === 'mission') { tl(t, 'Astra Swarm', 'Préparation des copies isolées', 'mission'); continue; }
      if (type === 'plan') {
        planSeen = true;
        tl(t, nameOf(COORD), 'Plan réparti entre les agents' + (ev.fallback ? ' (plan de secours)' : ''), 'plan');
        if (ev.fallback) alerts.push({ level: 'warn', agentId: COORD, text: 'Le coordinateur n’a pas fourni de plan exploitable (' + clip(ev.fallback, 160) + ') : tâches par défaut utilisées.' });
        for (const x of ev.workers || []) {
          if (!x || !byId[x.id] && !x.name) continue;
          pendingAssign[x.id] = push(COORD, x.id, 'TASK_ASSIGNMENT', x.task || (byId[x.id] && byId[x.id].task) || '', t, 'pending');
          if (!byId[x.id]) byId[x.id] = { id: x.id, name: x.name, role: x.role };
        }
        continue;
      }
      if (type === 'worker') {
        const id = ev.workerId, st = String(ev.status || '');
        if (!id) continue;
        lastActivity[id] = t;
        if (st === 'working') {
          if (!firstWork[id]) firstWork[id] = t;
          if (pendingAssign[id]) { pendingAssign[id].status = 'delivered'; delete pendingAssign[id]; }
          push(id, COORD, 'STATUS_UPDATE', ev.lastAction || 'Agent au travail', t);
          tl(t, nameOf(id), ev.lastAction || 'Démarrage', 'status');
        } else if (st === 'completed') {
          finishAt[id] = t; lastWork[id] = t;
          pendingResult[id] = push(id, REVIEWER, 'TASK_RESULT', ev.result || byId[id] && byId[id].result || 'Tâche terminée', t, 'pending');
          tl(t, nameOf(id), 'Tâche terminée' + (ev.changes != null ? ' · ' + ev.changes + ' changement(s)' : ''), 'result');
        } else if (st === 'failed') {
          finishAt[id] = t;
          if (!errorSeen.has(id)) { errorSeen.add(id); push(id, COORD, 'ERROR', ev.result || ev.lastAction || 'Échec de l’agent', t, 'failed'); }
          tl(t, nameOf(id), 'Échec : ' + clip(ev.result || ev.lastAction || '', 200), 'error');
        } else if (st === 'stopped') {
          finishAt[id] = t;
          push(id, COORD, 'STATUS_UPDATE', 'Agent arrêté', t);
          tl(t, nameOf(id), 'Arrêté', 'status');
        } else if (st === 'pausing' || st === 'paused' || st === 'stopping') {
          push(id, COORD, 'STATUS_UPDATE', ev.lastAction || st, t);
          tl(t, nameOf(id), ev.lastAction || st, 'status');
        }
        continue;
      }
      if (type === 'worker-event') {
        const id = ev.workerId, inner = ev.event || {};
        if (!id) continue;
        lastActivity[id] = Math.max(lastActivity[id] || 0, t);
        if (inner.type === 'error') {
          errorSeen.add(id);
          push(id, COORD, 'ERROR', inner.message || 'Erreur agent', t, 'failed');
          tl(t, nameOf(id), 'Erreur : ' + clip(inner.message, 200), 'error');
        } else {
          tl(t, nameOf(id), inner.message || inner.type || 'activité', 'activity');
        }
        continue;
      }
      if (type === 'review-start') {
        reviewStartAt = t;
        for (const k of Object.keys(pendingResult)) { pendingResult[k].status = 'delivered'; delete pendingResult[k]; }
        tl(t, nameOf(REVIEWER), 'Revue indépendante démarrée', 'review');
        continue;
      }
      if (type === 'complete') {
        reviewDone = true;
        push(REVIEWER, COORD, 'RESPONSE', mission.review || 'Revue terminée', t);
        tl(t, 'Astra Swarm', 'Mission terminée', 'mission');
        for (const c of ev.conflicts || []) alerts.push({ level: 'warn', agentId: null, text: 'Conflit potentiel sur ' + clip(typeof c === 'string' ? c : c.path, 160) });
        continue;
      }
      if (type === 'error') {
        tl(t, 'Astra Swarm', 'Erreur de mission : ' + clip(ev.text, 240), 'error');
        alerts.push({ level: 'error', agentId: null, text: clip(ev.text, 300) });
        continue;
      }
    }

    // Historique tronqué ou mission sans événement 'plan' : on retombe sur les tâches attribuées connues.
    if (!planSeen) for (const w of workers) if (w.task) push(COORD, w.id, 'TASK_ASSIGNMENT', w.task, ts(mission.createdAt), w.startedAt ? 'delivered' : 'pending');

    // Les échanges encore « pending » alors que la mission est terminée n'ont jamais abouti.
    if (missionDone) {
      for (const m of messages) if (m.status === 'pending') { m.status = 'failed'; }
    }
    messages.sort((a, b) => a.timestamp - b.timestamp || a.id.localeCompare(b.id));
    timeline.sort((a, b) => a.at - b.at);

    // Nœuds
    const stats = {};
    const touch = id => stats[id] || (stats[id] = { sent: 0, received: 0, failed: 0 });
    for (const m of messages) { touch(m.from).sent++; touch(m.to).received++; if (m.status === 'failed') touch(m.from).failed++; }
    const workerNodeStatus = w => {
      const s = w.status;
      if (s === 'working') return 'active';
      if (s === 'paused' || s === 'pausing') return 'paused';
      if (s === 'completed') return 'done';
      if (s === 'failed') return 'error';
      if (s === 'stopped' || s === 'stopping') return 'stopped';
      if (s === 'assigned' || s === 'queued') return 'waiting';
      return 'idle';
    };
    const nodes = [];
    const ms = mission.status;
    nodes.push({
      id: COORD, kind: 'coordinator', label: 'Coordinateur', role: 'Planification et distribution',
      provider: mission.coordinator && mission.coordinator.provider || '', model: mission.coordinator && mission.coordinator.model || '',
      status: ms === 'preparing' || ms === 'planning' ? 'active' : ms === 'failed' ? 'error' : missionDone ? 'done' : 'waiting',
      ...touch(COORD)
    });
    for (const w of workers) {
      const start = firstWork[w.id] || ts(w.startedAt), end = finishAt[w.id] || ts(w.finishedAt);
      const activeMs = start ? ((end || (missionDone ? start : now)) - start) : 0;
      nodes.push({
        id: w.id, kind: 'worker', label: w.name || w.id, role: w.role || '', provider: w.provider || '', model: w.model || '',
        status: workerNodeStatus(w), rawStatus: w.status || '', task: w.task || '', lastAction: w.lastAction || '',
        activeMs: Math.max(0, activeMs), startedAt: start || null, finishedAt: end || null, ...touch(w.id)
      });
    }
    nodes.push({
      id: REVIEWER, kind: 'reviewer', label: 'Reviewer', role: 'Contrôle indépendant', provider: mission.coordinator && mission.coordinator.provider || '', model: mission.coordinator && mission.coordinator.model || '',
      status: ms === 'reviewing' ? 'active' : reviewDone || missionDone ? (ms === 'failed' && !reviewDone ? 'idle' : 'done') : 'waiting', ...touch(REVIEWER)
    });

    // Arêtes agrégées par direction
    const edgeMap = new Map();
    for (const m of messages) {
      const k = m.from + '>' + m.to;
      if (!edgeMap.has(k)) edgeMap.set(k, { id: k, from: m.from, to: m.to, count: 0, failed: 0, pending: 0, types: {}, lastAt: 0 });
      const e = edgeMap.get(k); e.count++; if (m.status === 'failed') e.failed++; if (m.status === 'pending') e.pending++;
      e.types[m.type] = (e.types[m.type] || 0) + 1; e.lastAt = Math.max(e.lastAt, m.timestamp);
    }
    const edges = [...edgeMap.values()];

    // Goulots d'étranglement
    const bottlenecks = [];
    const durations = nodes.filter(n => n.kind === 'worker' && n.startedAt && n.finishedAt).map(n => ({ id: n.id, ms: n.activeMs }));
    if (durations.length >= 2) {
      const sorted = durations.map(d => d.ms).sort((a, b) => a - b);
      const median = sorted.length % 2 ? sorted[(sorted.length - 1) / 2] : (sorted[sorted.length / 2 - 1] + sorted[sorted.length / 2]) / 2;
      const slow = durations.reduce((a, b) => b.ms > a.ms ? b : a);
      const fastEnd = Math.min(...durations.map(d => finishAt[d.id] || Infinity));
      if (slow.ms > 1.5 * median && slow.ms - median > 5000) {
        bottlenecks.push({ agentId: slow.id, level: 'warn', text: nameOf(slow.id) + ' a mis ' + fmtDuration(slow.ms) + ' contre ' + fmtDuration(median) + ' en médiane : il ralentit la mission.' });
      }
      const lastEnd = Math.max(...durations.map(d => finishAt[d.id] || 0));
      if (reviewStartAt && lastEnd && lastEnd - fastEnd > 10000) {
        bottlenecks.push({ agentId: REVIEWER, level: 'info', text: 'La revue n’a pu démarrer qu’après l’agent le plus lent (' + fmtDuration(lastEnd - fastEnd) + ' d’attente pour les autres résultats).' });
      }
    }
    const staleMs = opts.staleMs || 120000;
    if (!missionDone) for (const n of nodes) {
      if (n.kind === 'worker' && n.status === 'active' && lastActivity[n.id] && now - lastActivity[n.id] > staleMs) {
        bottlenecks.push({ agentId: n.id, level: 'warn', text: n.label + ' n’a émis aucune activité depuis ' + fmtDuration(now - lastActivity[n.id]) + '.' });
      }
    }
    for (const m of messages) if (m.status === 'failed' && m.type === 'ERROR') {
      alerts.push({ level: 'error', agentId: m.from, text: nameOf(m.from) + ' : ' + clip(m.content, 200) });
    }
    for (const m of messages) if (m.status === 'failed' && m.type !== 'ERROR') {
      alerts.push({ level: 'warn', agentId: m.from, text: 'Échange ' + m.type + ' ' + nameOf(m.from) + ' → ' + nameOf(m.to) + ' non abouti.' });
    }
    for (const b of bottlenecks) alerts.push({ level: b.level === 'info' ? 'info' : 'warn', agentId: b.agentId, text: b.text });

    return {
      missionId: mission.id || '', title: mission.title || '', status: ms || '',
      nodes, edges, messages, timeline, alerts, bottlenecks,
      diagnosis: diagnose(mission, nodes, alerts, nameOf, now, lastActivity),
      meta: { messageCount: messages.length, eventCount: events.length, truncated: events.length >= 300, real: true }
    };
  }

  function diagnose(mission, nodes, alerts, nameOf, now, lastActivity) {
    const ms = mission.status, workers = nodes.filter(n => n.kind === 'worker');
    const err = alerts.find(a => a.level === 'error');
    if (ms === 'failed') return 'Mission interrompue' + (err ? ' : ' + err.text : '.');
    const paused = workers.filter(w => w.status === 'paused');
    if (paused.length && !MISSION_DONE.has(ms)) return 'Mission en attente : ' + paused.map(w => w.label).join(', ') + ' en pause (reprise manuelle nécessaire).';
    if (ms === 'preparing') return 'Préparation des copies isolées du projet.';
    if (ms === 'planning') return 'Le coordinateur prépare le plan et attribue les tâches.';
    if (ms === 'reviewing') return 'Tous les agents ont terminé : le reviewer examine les changements.';
    const running = workers.filter(w => w.status === 'active');
    if (running.length) return 'En attente de ' + running.map(w => w.label).join(', ') + ' (en cours).';
    if (MISSION_DONE.has(ms)) return ms === 'completed_with_errors' ? 'Mission terminée avec des erreurs d’agents.' : ms === 'completed_with_conflicts' ? 'Mission terminée avec des conflits à examiner.' : 'Mission terminée.';
    return 'Aucune activité en cours.';
  }

  // État du graphe à l'étape i de la relecture : uniquement les messages déjà enregistrés jusque-là.
  function stateAt(graph, index) {
    const upto = graph.messages.slice(0, Math.max(0, Math.min(graph.messages.length, index + 1)));
    const edgeCounts = {}, nodeLast = {};
    for (const m of upto) {
      const k = m.from + '>' + m.to; edgeCounts[k] = (edgeCounts[k] || 0) + 1;
      nodeLast[m.from] = m; nodeLast[m.to] = nodeLast[m.to] || m;
    }
    return { message: upto[upto.length - 1] || null, edgeCounts, active: upto.length ? upto[upto.length - 1] : null, shown: upto.length, total: graph.messages.length };
  }

  // Disposition en trois colonnes : coordinateur | agents | reviewer.
  function layout(graph, width, height) {
    const pos = {}, w = width || 720, h = height || 420;
    const workers = graph.nodes.filter(n => n.kind === 'worker');
    pos[COORD] = { x: w * 0.12, y: h / 2 };
    pos[REVIEWER] = { x: w * 0.88, y: h / 2 };
    workers.forEach((n, i) => { pos[n.id] = { x: w / 2, y: workers.length === 1 ? h / 2 : h * (0.14 + 0.72 * i / (workers.length - 1)) }; });
    return pos;
  }

  const COLORS = { active: '#57a3ff', waiting: '#8492aa', idle: '#8492aa', done: '#42d6a2', error: '#f06c7a', paused: '#f0bd67', stopped: '#f06c7a' };
  const escXml = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  function toSVG(graph, positions, size) {
    const w = (size && size.w) || 720, h = (size && size.h) || 420, pos = positions || layout(graph, w, h);
    let out = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + w + ' ' + h + '" width="' + w + '" height="' + h + '" font-family="system-ui,sans-serif" font-size="12">';
    out += '<rect width="100%" height="100%" fill="#0c111b"/><defs><marker id="ar" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z" fill="#57a3ff"/></marker></defs>';
    for (const e of graph.edges) {
      const a = pos[e.from], b = pos[e.to]; if (!a || !b) continue;
      const bend = e.from < e.to ? 10 : -10, mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2 + bend;
      out += '<path d="M' + a.x + ' ' + a.y + ' Q' + mx + ' ' + my + ' ' + b.x + ' ' + b.y + '" fill="none" stroke="' + (e.failed ? '#f06c7a' : '#57a3ff') + '" stroke-width="1.6" marker-end="url(#ar)" opacity=".8"/>';
      out += '<text x="' + mx + '" y="' + (my - 4) + '" fill="#8492aa" text-anchor="middle" font-size="10">' + e.count + '</text>';
    }
    for (const n of graph.nodes) {
      const p = pos[n.id]; if (!p) continue;
      out += '<g><rect x="' + (p.x - 62) + '" y="' + (p.y - 24) + '" width="124" height="48" rx="9" fill="#121a27" stroke="' + (COLORS[n.status] || '#8492aa') + '" stroke-width="1.6"/>';
      out += '<text x="' + p.x + '" y="' + (p.y - 4) + '" fill="#e8edf7" text-anchor="middle" font-weight="700">' + escXml(String(n.label).slice(0, 16)) + '</text>';
      out += '<text x="' + p.x + '" y="' + (p.y + 13) + '" fill="#8492aa" text-anchor="middle" font-size="10">' + escXml(n.status) + '</text></g>';
    }
    return out + '</svg>';
  }

  function toExport(graph) {
    return { format: 'astra-communication-graph', version: 1, exportedAt: new Date().toISOString(), ...graph };
  }

  return { buildGraph, stateAt, layout, toSVG, toExport, fmtDuration, COLORS, COORD, REVIEWER };
});
