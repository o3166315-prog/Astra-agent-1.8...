# Kairo V5.2.0 — outils + interface

Tout est **additif** : aucun fichier existant n'a été réécrit. `public/index.html` ne gagne que 2 lignes
(le lien vers `kairo-ui.css` et la balise `kairo-ui.js`). Si tu retires ces 2 lignes, tu retrouves l'interface V5.1.1.

## 15 nouveaux outils pour l'agent (`server/extratools.js`, 15 tests dans `tests/extratools.test.js`)
| Catégorie | Outils |
|---|---|
| Recherche | `search_regex` (regex + contexte), `tree` (arbre avec tailles), `find_todos` |
| Code | `outline_code` (fonctions/classes js, py, gd, c/c++, go, rs, java, html, md), `code_stats` |
| Données | `csv_info` (colonnes, types, aperçu), `format_json` (diff + sauvegarde annulable) |
| Git (lecture seule) | `git_status`, `git_log`, `git_diff` |
| Utilitaires | `hash_text`, `encode_decode`, `uuid_generate`, `regex_test`, `date_calc` |
Permissions : lecture seule dans le projet = SAFE ; hors projet = confirmation ; `format_json` = comme `write_file`.
Nouvelle route `GET /api/tools` (catalogue : nom, description, catégorie, niveau).

## Interface (`public/kairo-ui.css`, `public/kairo-ui.js`, 41 nouvelles icônes SVG dans `icons/icons.svg`)
- **Barre de menus** Fichier / Édition / Affichage / Outils / Aide (clavier : F10, flèches, Entrée, Échap).
- **Palette de commandes** `Ctrl+K` : commandes, fichiers, `:42` pour aller à la ligne, ou texte libre pour préparer un message à l'agent. `Ctrl+P` ouvre la même palette en mode fichiers (remplace l'ancien `prompt()`).
- **Éditeur** : `Ctrl+F` / `Ctrl+H` (recherche, regex, casse, remplacer, surlignage), `Ctrl+G`, `Ctrl+D`, `Ctrl+/`, `Alt+↑/↓`, `Tab` / `Maj+Tab`, indentation automatique, taille du texte. Annuler / Rétablir reste fonctionnel.
- **Barre d'état** : ligne/colonne, taille, langage. **Notifications** discrètes (enregistrement, copie…).
- **Onglet Outils** : catalogue filtrable des 44 outils avec badges SAFE / CONFIRM / DANGER.
- **Accueil** quand aucun fichier n'est ouvert, **actions rapides** au-dessus de la zone de message.
- Modes : compact, masquer l'explorateur / le panneau Agent (mémorisés).
- Corrections : bouton « stop » qui s'affichait en permanence, bouton « + » coupé en haut à gauche, onglets sur deux lignes, glyphes `◉ → × ›` remplacés par des icônes SVG.

## Étendre
`KairoUI.registerCommand(id, titre, catégorie, icône, raccourci, fonction)` ajoute une commande à la palette (console du navigateur ou ton propre script).
