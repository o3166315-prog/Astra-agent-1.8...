# Astra Agent 1.7.2 — dix nouveaux outils de développement

## Nouveaux outils (10)

Tous sont enregistrés dans le même registre que les outils existants (`server/devtools.js`), exposés à l’agent
dans l’onglet « Outils », classés par le moteur de permissions et couverts par `tests/devtools.test.js`.

| Outil | Ce qu’il fait | Permission habituelle |
|---|---|---|
| `git_commit` | Indexe (au choix) et crée un commit ; identité git absente → auteur par défaut explicité dans la sortie. | CONFIRM (PROJECT_DEVELOPMENT) |
| `git_branch` | Liste, crée, bascule ou supprime une branche (`list` / `create` / `switch` / `delete`). | SAFE pour `list`, CONFIRM sinon, DANGER pour une suppression forcée |
| `project_deps` | Compare les dépendances déclarées (package.json, requirements.txt, pyproject.toml, Cargo.toml, go.mod) aux versions réellement installées. | SAFE |
| `env_keys` | Liste les clés des fichiers `.env` **sans jamais afficher les valeurs** et signale les clés sensibles. | SAFE |
| `config_query` | Lit une valeur dans un JSON, YAML, TOML, INI ou `.env` par chemin (`server.port`, `items[0].name`). | SAFE |
| `lint_code` | Lance le linter détecté (eslint, biome, prettier, tsc, ruff, flake8, pylint, golangci-lint, cargo clippy) en lecture seule. | CONFIRM (PROJECT_DEVELOPMENT) |
| `port_check` | Teste un port TCP local et liste les ports en écoute de la machine. | SAFE en local, CONFIRM (NETWORK) sinon |
| `duplicate_code` | Détecte les blocs de code copiés-collés (fenêtres de lignes normalisées). | SAFE |
| `convert_image` | Convertit réellement une image en PNG, PPM, BMP ou représentation numérique (`server/imagecodec.js` + encodeur PNG maison). | SAFE dans le projet |
| `archive_files` | Crée, liste et extrait une archive ZIP (écriture ZIP native, CRC32 vérifié). | SAFE en création, CONFIRM (DESTRUCTIVE) à l’extraction |

## Sécurité

- `env_keys` n’affiche jamais une valeur : uniquement le nom de la clé, le type et la longueur. Les clés de type
  secret / token / clé privée sont signalées.
- `archive_files` refuse toute entrée d’archive à chemin absolu ou contenant `..` (traversée de chemin / *zip-slip*)
  et vérifie que chaque extraction reste dans le dossier de destination.
- `convert_image` et `archive_files` n’écrivent que dans le projet et refusent les zones internes (`.git`, `node_modules`, `.kairo`).
- `git_commit` et `git_branch` sont classés comme des écritures : confirmation requise, la suppression forcée d’une
  branche est classée DANGER (jamais accordée automatiquement).
- `lint_code` ne reçoit jamais `--fix` : le linter ne modifie pas les fichiers.

## Limites explicites

- Les parseurs YAML et TOML couvrent des **sous-ensembles** (scalaires, listes, tables indentées, sections).
  Une construction non supportée (ancres YAML, chaînes multilignes TOML, flux complexes) produit une erreur
  explicite : aucune valeur n’est devinée.
- `convert_image` applique la taille demandée comme un **maximum** : une image plus petite n’est jamais agrandie.
- `port_check` s’appuie sur `ss`, `netstat` ou `lsof` pour l’inventaire des ports ; sans ces outils, seule la
  sonde d’un port précis fonctionne.
- `git_commit` crée un commit local : aucune poussée vers un dépôt distant n’est effectuée.
- L’archive ZIP générée est standard (méthode *deflate* ou *store*), mais `archive_files` ne gère pas les
  archives chiffrées ni les formats autres que ZIP.

## Tests

- `tests/devtools.test.js` : 15 contrôles (parseurs, secrets masqués, dépendances, commits et branches réels,
  lint en lecture seule, ports réels, duplication de code, conversion d’image, cycle ZIP complet, refus du
  *zip-slip*, présence et classification des 10 outils).
- Suite complète : `npm test` (le fichier est ajouté à la chaîne).

## Base

Issu d’Astra Agent 1.7.1 (mascotte et thème sombre). Aucun correctif de sécurité n’a été retiré.
