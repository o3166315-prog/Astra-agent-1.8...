// Outils de développement (Astra 1.7.2). Fabrique : reçoit les aides de tools.js, comme moretools.js / extratools.js.
// Chaque outil = { desc, run(args, ctx) }. Les permissions sont définies dans perms.js (classifyTool).
// Aucune dépendance npm : le ZIP, les parseurs YAML/TOML/INI et les contrôles réseau sont écrits ici.
'use strict';
const fs = require('fs'), path = require('path'), os = require('os'), zlib = require('zlib'), net = require('net'),
  crypto = require('crypto'), { spawnSync } = require('child_process');
const perms = require('./perms'), pathGuard = require('./path-guard');

// ---------- helpers partagés ----------
const sizeStr = n => n < 1024 ? n + ' o' : n < 1048576 ? (n / 1024).toFixed(1) + ' Ko' : (n / 1048576).toFixed(1) + ' Mo';
const isLocal = h => /^(localhost|127\.0\.0\.1|\[::1\]|::1|0\.0\.0\.0)$/i.test(String(h || ''));
const readText = (rel, c) => {
  const p = perms.norm(rel, c.root);
  if (!fs.existsSync(p) || fs.statSync(p).isDirectory()) throw new Error('Fichier inexistant : ' + rel);
  return { p, text: fs.readFileSync(p, 'utf8') };
};
const dirOf = (rel, c) => {
  const d = perms.norm(rel || '.', c.root);
  if (!fs.existsSync(d) || !fs.statSync(d).isDirectory()) throw new Error('Dossier inexistant : ' + (rel || '.'));
  return d;
};
// Sortie obligatoire dans le projet et hors des zones internes (.git, node_modules, .kairo).
const outGuard = (rel, c, hidden) => {
  if (!rel) throw new Error('chemin de sortie manquant');
  const p = pathGuard.resolveProjectPath(c.root, rel);
  if (hidden(path.relative(c.root, p))) throw new Error('Écriture dans une zone interne refusée : ' + rel);
  return p;
};
const git = (c, extra) => {
  const r = spawnSync('git', ['--no-pager', '-c', 'core.quotepath=false', ...extra], { cwd: c.root, encoding: 'utf8', timeout: 20000, windowsHide: true, maxBuffer: 4 * 1024 * 1024 });
  const out = String(r.stdout || ''), err = String(r.stderr || '');
  if (r.error) return { status: -1, ok: false, out, err: r.error.message };
  if (!r.status && /not a git repository/i.test(err)) return { status: 128, ok: false, out, err: 'Ce projet n’est pas un dépôt git' };
  return { status: r.status, ok: r.status === 0, out, err };
};
// ---------- lecture de chemin dans un objet (scripts.test, items[0].name) ----------
const getPath = (obj, q) => {
  let cur = obj;
  for (const k of String(q || '').replace(/\[(\d+)\]/g, '.$1').split('.').filter(Boolean)) {
    if (cur === null || typeof cur !== 'object' || !(k in cur)) throw new Error('clé introuvable : ' + k);
    cur = cur[k];
  }
  return cur;
};

// ---------- parseurs de configuration (sous-ensembles déclarés, jamais de devinette) ----------
const yamlFlow = s => {
  const body = s.trim();
  if (!body.startsWith('[') && !body.startsWith('{')) throw new Error('YAML non pris en charge : ' + s);
  const inner = body.slice(1, -1), items = []; let cur = '', q = null, depth = 0;
  for (const ch of inner) {
    if (q) { cur += ch; if (ch === q) q = null; continue; }
    if (ch === '"' || ch === "'") { q = ch; cur += ch; continue; }
    if (ch === '[' || ch === '{') { depth++; cur += ch; continue; }
    if (ch === ']' || ch === '}') { depth--; cur += ch; continue; }
    if (ch === ',' && depth === 0) { items.push(cur.trim()); cur = ''; continue; }
    cur += ch;
  }
  if (cur.trim()) items.push(cur.trim());
  if (body[0] === '[') return items.map(i => yamlScalar(i));
  const o = {};
  for (const it of items) {
    const i = it.indexOf(':');
    if (i < 0) throw new Error('YAML non pris en charge : ' + it);
    o[String(yamlScalar(it.slice(0, i)))] = yamlScalar(it.slice(i + 1));
  }
  return o;
};
const yamlScalar = s => {
  s = String(s).trim();
  if (!s || s === '~' || /^(null|Null|NULL)$/.test(s)) return null;
  if (/^(true|True|TRUE|yes|on)$/.test(s)) return true;
  if (/^(false|False|FALSE|no|off)$/.test(s)) return false;
  if (/^'.*'$/s.test(s)) return s.slice(1, -1).replace(/''/g, "'");
  if (/^".*"$/s.test(s)) { try { return JSON.parse(s); } catch { return s.slice(1, -1); } }
  if (/^[-+]?\d+$/.test(s)) return Number(s);
  if (/^[-+]?(\d+\.\d*|\.\d+)([eE][-+]?\d+)?$/.test(s)) return Number(s);
  if (s.startsWith('[') || s.startsWith('{')) return yamlFlow(s);
  if (/^[|>]/.test(s) || s.startsWith('&') || s.startsWith('*') || s.startsWith('!')) throw new Error('construction YAML non prise en charge : ' + s);
  return s;
};
const stripYamlComment = l => {
  let q = null;
  for (let i = 0; i < l.length; i++) {
    const c = l[i];
    if (q) { if (c === q) q = null; continue; }
    if (c === '"' || c === "'") { q = c; continue; }
    if (c === '#' && (i === 0 || /\s/.test(l[i - 1]))) return l.slice(0, i);
  }
  return l;
};
const yamlBlock = (lines, pos, indent) => {
  if (pos >= lines.length) return { value: null, pos };
  const isItem = t => t === '-' || t.startsWith('- ');
  if (isItem(lines[pos].text)) {
    const arr = [];
    while (pos < lines.length && lines[pos].indent === indent && isItem(lines[pos].text)) {
      const rest = lines[pos].text === '-' ? '' : lines[pos].text.slice(2).trim();
      pos++;
      if (rest === '') {
        if (pos < lines.length && lines[pos].indent > indent) { const r = yamlBlock(lines, pos, lines[pos].indent); arr.push(r.value); pos = r.pos; }
        else arr.push(null);
      } else if (/^(?:"[^"]*"|'[^']*'|[^:]+):([ \t]|$)/.test(rest)) {
        const sub = [{ indent: indent + 2, text: rest }];
        while (pos < lines.length && lines[pos].indent > indent) { sub.push(lines[pos]); pos++; }
        arr.push(yamlBlock(sub, 0, indent + 2).value);
      } else arr.push(yamlScalar(rest));
    }
    return { value: arr, pos };
  }
  const obj = {};
  while (pos < lines.length && lines[pos].indent === indent) {
    const m = /^(.+?):(?:[ \t]+(.*))?$/.exec(lines[pos].text);
    if (!m) throw new Error('YAML non pris en charge : « ' + lines[pos].text + ' »');
    const key = String(yamlScalar(m[1])), rest = String(m[2] || '').trim();
    pos++;
    if (rest === '') {
      if (pos < lines.length && lines[pos].indent > indent) { const r = yamlBlock(lines, pos, lines[pos].indent); obj[key] = r.value; pos = r.pos; }
      else obj[key] = null;
    } else obj[key] = yamlScalar(rest);
  }
  return { value: obj, pos };
};
const parseYaml = text => {
  const lines = [];
  for (const raw of String(text).split(/\r?\n/)) {
    const l = stripYamlComment(raw);
    if (!l.trim()) continue;
    lines.push({ indent: l.match(/^\s*/)[0].length, text: l.trim() });
  }
  if (!lines.length) return {};
  const r = yamlBlock(lines, 0, lines[0].indent);
  return r.value || {};
};
const tomlValue = v => {
  v = String(v).trim();
  if (/^"""|'''/.test(v)) throw new Error('TOML : chaînes multilignes non prises en charge');
  const hash = v.search(/\s#/);
  if (hash >= 0 && !/^["']/.test(v)) v = v.slice(0, hash).trim();
  if (/^".*"$/.test(v)) { try { return JSON.parse(v); } catch { return v.slice(1, -1); } }
  if (/^'.*'$/.test(v)) return v.slice(1, -1);
  if (v.startsWith('[')) {
    const inner = v.slice(1, v.lastIndexOf(']'));
    return inner.split(',').map(x => x.trim()).filter(x => x !== '').map(tomlValue);
  }
  if (v === 'true') return true;
  if (v === 'false') return false;
  if (/^[-+]?\d+$/.test(v)) return Number(v);
  if (/^[-+]?(\d+\.\d+|\d+)([eE][-+]?\d+)?$/.test(v)) return Number(v);
  return v;
};
const parseToml = text => {
  const root = {}; let cur = root;
  const lines = String(text).split(/\r?\n/);
  for (let i = 0; i < lines.length; i++) {
    let l = lines[i].trim();
    if (!l || l.startsWith('#')) continue;
    if (l.startsWith('[')) {
      const sec = l.replace(/^\[+/, '').replace(/\]+$/, '').trim();
      if (!sec) throw new Error('TOML : section vide');
      cur = root;
      for (const part of sec.split('.')) {
        const k = part.trim().replace(/^["']|["']$/g, '');
        if (typeof cur[k] !== 'object' || cur[k] === null) cur[k] = {};
        cur = cur[k];
      }
      continue;
    }
    const eq = l.indexOf('=');
    if (eq < 0) throw new Error('TOML non pris en charge : « ' + l + ' »');
    const key = l.slice(0, eq).trim().replace(/^["']|["']$/g, '');
    let val = l.slice(eq + 1).trim();
    while (val.startsWith('[') && (val.match(/\[/g) || []).length > (val.match(/\]/g) || []).length && i + 1 < lines.length) {
      i++; val += ' ' + lines[i].trim();
    }
    cur[key] = tomlValue(val);
  }
  return root;
};
const parseIni = text => {
  const out = {}; let sec = '';
  for (const raw of String(text).split(/\r?\n/)) {
    const l = raw.trim();
    if (!l || l.startsWith(';') || l.startsWith('#')) continue;
    const m = /^\[(.+)\]$/.exec(l);
    if (m) { sec = m[1].trim(); out[sec] = out[sec] || {}; continue; }
    const i = l.search(/[=:]/);
    if (i < 0) continue;
    const k = l.slice(0, i).trim(), v = l.slice(i + 1).trim();
    if (sec) out[sec][k] = v; else out[k] = v;
  }
  return out;
};
const parseEnv = text => {
  const out = {};
  for (const raw of String(text).split(/\r?\n/)) {
    const l = raw.trim();
    if (!l || l.startsWith('#')) continue;
    const m = /^(?:export\s+)?([A-Za-z_][A-Za-z0-9_.]*)\s*=\s*(.*)$/.exec(l);
    if (!m) continue;
    let v = m[2].trim();
    if (v.length > 1 && ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'")))) v = v.slice(1, -1);
    out[m[1]] = v;
  }
  return out;
};

// ---------- ZIP (écriture + lecture, sans dépendance) ----------
const CRC_TABLE = (() => { const t = new Int32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c; } return t; })();
const crc32 = buf => { let c = -1; for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xFF] ^ (c >>> 8); return (c ^ -1) >>> 0; };
const dosStamp = d => {
  const y = Math.max(1980, d.getFullYear());
  return { time: (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1), date: ((y - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate() };
};
const zipCreate = entries => {
  const parts = [], central = []; let offset = 0;
  for (const e of entries) {
    const name = Buffer.from(String(e.name).replace(/\\/g, '/'), 'utf8'), data = Buffer.isBuffer(e.data) ? e.data : Buffer.from(String(e.data));
    const crc = crc32(data), deflated = zlib.deflateRawSync(data, { level: 9 });
    const store = deflated.length >= data.length, body = store ? data : deflated, method = store ? 0 : 8;
    const { time, date } = dosStamp(e.mtime || new Date());
    const lh = Buffer.alloc(30);
    lh.writeUInt32LE(0x04034B50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(0x0800, 6); lh.writeUInt16LE(method, 8);
    lh.writeUInt16LE(time, 10); lh.writeUInt16LE(date, 12); lh.writeUInt32LE(crc, 14);
    lh.writeUInt32LE(body.length, 18); lh.writeUInt32LE(data.length, 22); lh.writeUInt16LE(name.length, 26); lh.writeUInt16LE(0, 28);
    parts.push(lh, name, body);
    const cd = Buffer.alloc(46);
    cd.writeUInt32LE(0x02014B50, 0); cd.writeUInt16LE(20, 4); cd.writeUInt16LE(20, 6); cd.writeUInt16LE(0x0800, 8);
    cd.writeUInt16LE(method, 10); cd.writeUInt16LE(time, 12); cd.writeUInt16LE(date, 14); cd.writeUInt32LE(crc, 16);
    cd.writeUInt32LE(body.length, 20); cd.writeUInt32LE(data.length, 24); cd.writeUInt16LE(name.length, 28);
    cd.writeUInt16LE(0, 30); cd.writeUInt16LE(0, 32); cd.writeUInt16LE(0, 34); cd.writeUInt16LE(0, 36);
    cd.writeUInt32LE((0o100644 << 16) >>> 0, 38); cd.writeUInt32LE(offset, 42);
    central.push(cd, name);
    offset += lh.length + name.length + body.length;
  }
  const cdBuf = Buffer.concat(central);
  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054B50, 0); eocd.writeUInt16LE(0, 4); eocd.writeUInt16LE(0, 6);
  eocd.writeUInt16LE(entries.length, 8); eocd.writeUInt16LE(entries.length, 10);
  eocd.writeUInt32LE(cdBuf.length, 12); eocd.writeUInt32LE(offset, 16); eocd.writeUInt16LE(0, 20);
  return Buffer.concat([...parts, cdBuf, eocd]);
};
const zipRead = buf => {
  let eocd = -1;
  for (let i = buf.length - 22; i >= 0 && i >= buf.length - 22 - 65535; i--) { if (buf.readUInt32LE(i) === 0x06054B50) { eocd = i; break; } }
  if (eocd < 0) throw new Error('Archive ZIP illisible (fin de répertoire central introuvable)');
  const count = buf.readUInt16LE(eocd + 10), cdOff = buf.readUInt32LE(eocd + 16);
  let p = cdOff; const out = [];
  for (let i = 0; i < count; i++) {
    if (p + 46 > buf.length || buf.readUInt32LE(p) !== 0x02014B50) throw new Error('Archive ZIP corrompue (répertoire central)');
    const method = buf.readUInt16LE(p + 10), crc = buf.readUInt32LE(p + 16), csize = buf.readUInt32LE(p + 20), usize = buf.readUInt32LE(p + 24);
    const nlen = buf.readUInt16LE(p + 28), elen = buf.readUInt16LE(p + 30), clen = buf.readUInt16LE(p + 32), lho = buf.readUInt32LE(p + 42);
    const name = buf.toString('utf8', p + 46, p + 46 + nlen);
    const lnlen = buf.readUInt16LE(lho + 26), lelen = buf.readUInt16LE(lho + 28);
    const start = lho + 30 + lnlen + lelen;
    const raw = buf.subarray(start, start + csize);
    let data;
    if (method === 0) data = Buffer.from(raw);
    else if (method === 8) data = zlib.inflateRawSync(raw);
    else throw new Error('Méthode de compression ZIP non prise en charge : ' + method);
    if (crc32(data) !== crc) throw new Error('Archive ZIP corrompue (CRC incorrect) : ' + name);
    out.push({ name, data, size: usize });
    p += 46 + nlen + elen + clen;
  }
  return out;
};

// ---------- image : writers PNG (via vision), PPM, BMP ----------
const bmp24 = (w, h, rgb) => {
  const row = ((w * 3 + 3) >> 2) << 2, size = 54 + row * h, b = Buffer.alloc(size);
  b.write('BM', 0); b.writeUInt32LE(size, 2); b.writeUInt32LE(54, 10); b.writeUInt32LE(40, 14);
  b.writeInt32LE(w, 18); b.writeInt32LE(h, 22); b.writeUInt16LE(1, 26); b.writeUInt16LE(24, 28);
  b.writeUInt32LE(row * h, 34); b.writeInt32LE(2835, 38); b.writeInt32LE(2835, 42);
  for (let y = 0; y < h; y++) {
    const sy = h - 1 - y;
    for (let x = 0; x < w; x++) {
      const s = (sy * w + x) * 3, d = 54 + y * row + x * 3;
      b[d] = rgb[s + 2]; b[d + 1] = rgb[s + 1]; b[d + 2] = rgb[s];
    }
  }
  return b;
};
const ppm = (w, h, rgb) => Buffer.concat([Buffer.from(`P6\n${w} ${h}\n255\n`, 'latin1'), Buffer.from(rgb)]);

// ---------- détection des linters ----------
// local : binaire dans node_modules/.bin du projet · sys : binaire global · needsFile : fichier attendu dans le projet
const LINTERS = [
  { id: 'eslint', local: 'node_modules/.bin/eslint', sys: 'eslint', bin: 'eslint', args: t => [t] },
  { id: 'biome', local: 'node_modules/.bin/biome', sys: 'biome', bin: 'biome', args: t => ['check', t] },
  { id: 'prettier', local: 'node_modules/.bin/prettier', sys: 'prettier', bin: 'prettier', args: t => ['--check', t] },
  { id: 'tsc', local: 'node_modules/.bin/tsc', sys: 'tsc', bin: 'tsc', needsFile: 'tsconfig.json', args: () => ['--noEmit'] },
  { id: 'ruff', sys: 'ruff', bin: 'ruff', args: t => ['check', t] },
  { id: 'flake8', sys: 'flake8', bin: 'flake8', args: t => [t] },
  { id: 'pylint', sys: 'pylint', bin: 'pylint', args: t => [t], fileOnly: true },
  { id: 'golangci-lint', sys: 'golangci-lint', bin: 'golangci-lint', args: t => ['run', t] },
  { id: 'clippy', sys: 'cargo', bin: 'cargo', needsFile: 'Cargo.toml', args: () => ['clippy'] },
];
const which = cmd => {
  const r = spawnSync(process.platform === 'win32' ? 'where' : 'which', [cmd], { encoding: 'utf8', timeout: 5000, windowsHide: true });
  return r.status === 0 ? String(r.stdout || '').split(/\r?\n/).find(x => x.trim()) : null;
};

// ---------- ports ----------
const probePort = (host, port, timeout) => new Promise(resolve => {
  const s = net.connect({ host, port: +port });
  let done = false;
  const finish = st => { if (done) return; done = true; try { s.destroy(); } catch {} resolve(st); };
  s.setTimeout(Math.max(200, Math.min(10000, +timeout || 1200)));
  s.on('connect', () => finish('ouvert'));
  s.on('timeout', () => finish('délai dépassé (filtré ?)'));
  s.on('error', e => finish(e.code === 'ECONNREFUSED' ? 'fermé (connexion refusée)' : 'erreur : ' + (e.code || e.message)));
});
const listeningPorts = () => {
  const out = [];
  const ss = spawnSync('ss', ['-ltnH'], { encoding: 'utf8', timeout: 8000, windowsHide: true });
  if (ss.status === 0 && ss.stdout) {
    for (const l of String(ss.stdout).split('\n')) {
      const m = l.trim().match(/^(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(.*)$/);
      if (!m) continue;
      const addr = m[5].trim(), port = (addr.match(/:(\d+)$/) || [])[1];
      if (port) out.push({ proto: 'tcp', addr, port: +port });
    }
    if (out.length) return out;
  }
  const ns = spawnSync('netstat', ['-an'], { encoding: 'utf8', timeout: 8000, windowsHide: true });
  if (ns.status === 0 && ns.stdout) {
    for (const l of String(ns.stdout).split('\n')) {
      const m = l.trim().match(/^(tcp|udp)\S*\s+(\S+)\s+(\S+)\s+(\S+)/i);
      if (!m || !/LISTEN/i.test(l)) continue;
      const port = (m[2].match(/:(\d+)$/) || [])[1];
      if (port) out.push({ proto: m[1].toLowerCase(), addr: m[2], port: +port });
    }
    if (out.length) return out;
  }
  const ls = spawnSync('lsof', ['-nP', '-iTCP', '-sTCP:LISTEN'], { encoding: 'utf8', timeout: 8000, windowsHide: true });
  if (ls.status === 0 && ls.stdout) {
    for (const l of String(ls.stdout).split('\n').slice(1)) {
      const m = l.trim().match(/:(\d+)\s*\(LISTEN\)|:(\d+)->/);
      const port = m && (m[1] || m[2]);
      if (port) out.push({ proto: 'tcp', addr: l.trim().split(/\s+/)[1] || '?', port: +port });
    }
  }
  return out;
};

module.exports = h => {
  const { walk, briefDiff, backup, hidden, textFile } = h;
  const textFiles = d => walk(d, d).filter(x => !x.endsWith('/') && textFile(x)).filter(x => { try { return fs.statSync(path.join(d, x)).size <= 1024 * 1024; } catch { return false; } });

  return {
    // ---------------------------------------------------------------- GIT
    git_commit: {
      desc: 'Crée un commit git (indexe d’abord les fichiers si demandé). args:{message, add?:true (indexe tout), path? (indexe ce chemin), author?:"Nom <email>"}',
      run: async (a, c) => {
        const msg = String(a.message || '').trim();
        if (!msg) throw new Error('message de commit manquant');
        if (msg.length > 500) throw new Error('message de commit trop long (500 caractères max)');
        const g = args => git(c, args);
        if (a.path) { const r = g(['add', '--', String(a.path)]); if (!r.ok) throw new Error('git add : ' + (r.err || r.out).slice(0, 400)); }
        else if (a.add) { const r = g(['add', '-A']); if (!r.ok) throw new Error('git add -A : ' + (r.err || r.out).slice(0, 400)); }
        const staged = g(['diff', '--cached', '--quiet']);
        if (staged.status === 0) throw new Error('Rien à indexer : modifie des fichiers, ou passe path: / add:true');
        const stat = g(['diff', '--cached', '--stat']).out.trim();
        let r = g(['commit', '-m', msg]), fallback = '';
        if (!r.ok && /author|identity|who you are/i.test(r.err + r.out)) {
          const who = String(a.author || 'Astra Agent <agent@astra.local>');
          const nm = (who.match(/^([^<]*)<([^>]*)>/) || []);
          const name = (nm[1] || who).trim(), mail = (nm[2] || 'agent@astra.local').trim();
          r = g(['-c', 'user.name=' + name, '-c', 'user.email=' + mail, 'commit', '-m', msg]);
          fallback = '\nIdentité git absente du dépôt : auteur utilisé → ' + name + ' <' + mail + '>';
        }
        if (!r.ok) throw new Error('git commit : ' + (r.err || r.out).trim().slice(0, 600));
        const sha = g(['rev-parse', '--short', 'HEAD']).out.trim();
        const files = (stat.match(/(\d+) files? changed/) || [])[1];
        return `Commit ${sha} créé\nSujet : ${msg}${fallback}\n${files ? files + ' fichier(s) modifié(s)' : ''}${stat ? '\n' + stat : ''}`;
      },
    },
    git_branch: {
      desc: 'Gère les branches git : liste, crée, bascule ou supprime une branche. args:{action:"list"|"create"|"switch"|"delete", name?, from?, force?}',
      run: async (a, c) => {
        const act = String(a.action || 'list').toLowerCase(), g = args => git(c, args);
        if (!['list', 'create', 'switch', 'delete'].includes(act)) throw new Error('action inconnue : ' + act + ' — choix : list, create, switch, delete');
        if (act === 'list') {
          const cur = g(['rev-parse', '--abbrev-ref', 'HEAD']).out.trim();
          const list = g(['branch', '--format=%(refname:short)']).out.split('\n').map(s => s.trim()).filter(Boolean);
          if (!list.length) return 'branche courante : ' + cur + '\n(aucune branche)';
          return 'branche courante : ' + cur + '\n' + list.map(b => (b === cur ? '* ' : '  ') + b).join('\n');
        }
        const name = String(a.name || '').trim();
        if (!name) throw new Error('nom de branche manquant (args:{name})');
        if (!/^[A-Za-z0-9._\/-]+$/.test(name) || name.includes('..')) throw new Error('nom de branche invalide : ' + name);
        if (act === 'create') {
          const r = g(a.from ? ['branch', name, String(a.from)] : ['branch', name]);
          if (!r.ok) throw new Error('git branch : ' + (r.err || r.out).trim().slice(0, 400));
          return 'Branche créée : ' + name + (a.from ? ' (depuis ' + a.from + ')' : '');
        }
        if (act === 'switch') {
          let r = g(['switch', name]);
          if (!r.ok) r = g(['checkout', name]);
          if (!r.ok) throw new Error('git switch : ' + (r.err || r.out).trim().slice(0, 400));
          return 'Branche active : ' + name;
        }
        if (act === 'delete') {
          const r = g(['branch', a.force ? '-D' : '-d', name]);
          if (!r.ok) throw new Error('git branch -d : ' + (r.err || r.out).trim().slice(0, 400));
          return 'Branche supprimée : ' + name + (a.force ? ' (suppression forcée : commits non fusionnés peuvent être perdus)' : '');
        }
        throw new Error('action inconnue : ' + act + ' — choix : list, create, switch, delete');      },
    },

    // ---------------------------------------------------------------- DÉPENDANCES
    project_deps: {
      desc: 'Analyse les dépendances déclarées par le projet (package.json, requirements.txt, pyproject.toml, Cargo.toml, go.mod) et les compare aux versions réellement installées. args:{path?}',
      run: async (a, c) => {
        const d = dirOf(a.path || '.', c), out = [];
        const sat = (v, w) => {
          w = String(w).trim();
          if (!w || w === '*' || w === 'latest') return true;
          if (/[<>=|]/.test(w)) return true; // plage non évaluable de façon fiable : on ne signale pas de faux écart
          const caret = w.startsWith('^'), m = w.match(/(\d+)(?:\.(\d+))?(?:\.(\d+))?/);
          if (!m) return true;
          const iv = String(v).split('.').map(Number), M = +m[1], mi = m[2] === undefined ? null : +m[2], pa = m[3] === undefined ? null : +m[3];
          if (iv[0] !== M) return false;
          if (caret) { if (mi !== null && iv[1] < mi) return false; if (mi !== null && iv[1] === mi && pa !== null && iv[2] < pa) return false; return true; }
          if (mi !== null && iv[1] !== mi) return false;
          if (pa !== null && iv[2] !== pa) return false;
          return true;
        };
        if (fs.existsSync(path.join(d, 'package.json'))) {
          let j;
          try { j = JSON.parse(fs.readFileSync(path.join(d, 'package.json'), 'utf8')); } catch (e) { throw new Error('package.json illisible : ' + e.message); }
          const declared = new Set();
          for (const [k, label] of [['dependencies', 'dépendances'], ['devDependencies', 'dev'], ['peerDependencies', 'peer'], ['optionalDependencies', 'optionnelles']]) {
            const deps = j[k] || {}, names = Object.keys(deps);
            if (!names.length) continue;
            const good = [], other = [], missing = [];
            for (const n of names) {
              declared.add(n);
              let inst = null;
              try { inst = JSON.parse(fs.readFileSync(path.join(d, 'node_modules', n, 'package.json'), 'utf8')).version; } catch {}
              if (!inst) missing.push(`${n} ${deps[n]} — non installée`);
              else if (sat(inst, deps[n])) good.push(`${n} ${inst}`);
              else other.push(`${n} ${deps[n]} → installée : ${inst}`);
            }
            out.push(`\npackage.json — ${label} (${names.length})`);
            good.forEach(x => out.push('  ✓ ' + x)); other.forEach(x => out.push('  ≠ ' + x)); missing.forEach(x => out.push('  ✗ ' + x));
          }
          const extra = [];
          const nm = path.join(d, 'node_modules');
          if (fs.existsSync(nm)) {
            for (const e of fs.readdirSync(nm, { withFileTypes: true })) {
              if (!e.isDirectory() || e.name.startsWith('.')) continue;
              if (e.name.startsWith('@')) {
                for (const s of fs.readdirSync(path.join(nm, e.name), { withFileTypes: true })) {
                  if (s.isDirectory() && !declared.has(e.name + '/' + s.name)) extra.push(e.name + '/' + s.name);
                }
              } else if (!declared.has(e.name)) extra.push(e.name);
            }
          }
          if (extra.length) out.push(`\ninstallées mais non déclarées (${extra.length}) : ` + extra.slice(0, 12).join(', ') + (extra.length > 12 ? ' …' : ''));
        }
        const req = path.join(d, 'requirements.txt');
        if (fs.existsSync(req)) {
          const lines = fs.readFileSync(req, 'utf8').split('\n').map(s => s.trim()).filter(s => s && !s.startsWith('#') && !s.startsWith('-'));
          out.push(`\nrequirements.txt (${lines.length})\n  ` + (lines.slice(0, 30).join('\n  ') || '(vide)') + (lines.length > 30 ? '\n  …' : ''));
        }
        const py = path.join(d, 'pyproject.toml');
        if (fs.existsSync(py)) {
          try {
            const t = parseToml(fs.readFileSync(py, 'utf8'));
            const list = (t.project && t.project.dependencies) || [];
            out.push(`\npyproject.toml — project.dependencies (${list.length})\n  ` + (list.join('\n  ') || '(aucune)'));
          } catch (e) { out.push('\npyproject.toml : ' + e.message); }
        }
        const car = path.join(d, 'Cargo.toml');
        if (fs.existsSync(car)) {
          try {
            const t = parseToml(fs.readFileSync(car, 'utf8'));
            const list = Object.entries(t.dependencies || {});
            out.push(`\nCargo.toml — dependencies (${list.length})\n  ` + (list.map(([k, v]) => `${k} ${v && v.version ? v.version : ''}`).join('\n  ') || '(aucune)'));
          } catch (e) { out.push('\nCargo.toml : ' + e.message); }
        }
        const go = path.join(d, 'go.mod');
        if (fs.existsSync(go)) {
          const lines = fs.readFileSync(go, 'utf8').split('\n').map(s => s.trim()).filter(s => s.startsWith('require'));
          out.push(`\ngo.mod — requires\n  ` + (lines.join('\n  ') || '(aucun)'));
        }
        if (!out.length) return 'Aucun manifeste de dépendances trouvé (package.json, requirements.txt, pyproject.toml, Cargo.toml, go.mod).';
        return out.join('\n');
      },
    },

    // ---------------------------------------------------------------- ENV
    env_keys: {
      desc: 'Liste les clés des fichiers d’environnement du projet (.env, .env.local…) sans jamais afficher les valeurs (elles sont masquées) et signale les clés sensibles. args:{path?}',
      run: async (a, c) => {
        const d = dirOf(a.path || '.', c);
        const files = walk(d, d).filter(x => !x.endsWith('/') && /^\.env(\..+)?$/i.test(path.basename(x))).sort();
        if (!files.length) return 'Aucun fichier .env trouvé dans ' + (a.path || '.') + '.';
        const out = [], sensitive = /(secret|token|key|password|passwd|credential|private|auth|salt|hash|dsn|webhook|api_?key)/i;
        const where = new Map();
        for (const f of files) {
          const { text } = readText(f, c), kv = parseEnv(text);
          out.push(`\n${f} — ${Object.keys(kv).length} clé(s)`);
          for (const [k, v] of Object.entries(kv)) {
            const kind = v === '' ? 'vide' : /^(https?|postgres|postgresql|mysql|mongodb|redis|amqp):\/\//i.test(v) ? 'URL' : /^-?\d+(\.\d+)?$/.test(v) ? 'nombre' : /^(true|false)$/i.test(v) ? 'booléen' : 'texte';
            out.push(`  ${k} = *** (${kind}, ${v.length} car.)${sensitive.test(k) ? '  ⚠ SENSIBLE — valeur jamais affichée' : ''}`);
            if (where.has(k)) { if (where.get(k).v !== v) out.push(`      ↪ aussi défini dans ${where.get(k).f} avec une valeur différente`); }
            else where.set(k, { f, v });
          }
        }
        return out.join('\n');
      },
    },

    // ---------------------------------------------------------------- CONFIG
    config_query: {
      desc: 'Lit une valeur dans un fichier de configuration (JSON, YAML, TOML, INI, .env) par chemin (ex: scripts.test, items[0].name, server.port). args:{path, query?}',
      run: async (a, c) => {
        const { p, text } = readText(a.path, c), ext = path.extname(p).toLowerCase(), base = path.basename(p);
        let data;
        if (ext === '.json') { try { data = JSON.parse(text); } catch (e) { throw new Error('JSON invalide : ' + e.message); } }
        else if (ext === '.yaml' || ext === '.yml') data = parseYaml(text);
        else if (ext === '.toml') data = parseToml(text);
        else if (ext === '.ini' || ext === '.cfg' || ext === '.conf' || ext === '.properties') data = parseIni(text);
        else if (base.toLowerCase().startsWith('.env') || ext === '.env') data = parseEnv(text);
        else throw new Error('Format non pris en charge : ' + (ext || '(sans extension)') + ' (JSON, YAML, TOML, INI, .env)');
        if (data === null || typeof data !== 'object') return JSON.stringify(data, null, 2).slice(0, 6000);
        if (!a.query) return 'clés : ' + (Object.keys(data).join(', ') || '(vide)');
        return JSON.stringify(getPath(data, a.query), null, 2).slice(0, 6000);
      },
    },

    // ---------------------------------------------------------------- LINT
    lint_code: {
      desc: 'Lance le linter du projet détecté (eslint, biome, prettier, tsc, ruff, flake8, pylint, golangci-lint, clippy) en lecture seule et résume les diagnostics. args:{path?}',
      run: async (a, c) => {
        const d = dirOf(a.path || '.', c);
        const target = path.relative(c.root, d) || '.';
        const isFile = !fs.statSync(d).isDirectory();
        const found = [];
        for (const L of LINTERS) {
          if (L.needsFile && !fs.existsSync(path.join(d, L.needsFile))) continue;
          let bin = null;
          if (L.local && fs.existsSync(path.join(c.root, L.local))) bin = path.join(c.root, L.local);
          else if (L.sys && which(L.sys)) bin = L.sys;
          else if (!which(L.bin)) continue;
          if (L.fileOnly && !isFile) continue;
          found.push({ L, bin });
        }
        if (!found.length) throw new Error('Aucun linter détecté (eslint, biome, prettier, tsc, ruff, flake8, pylint, golangci-lint, cargo clippy). Ajoute-le au projet ou utilise run_command.');
        const { L, bin } = found[0];
        const args = L.args(isFile ? target : target === '.' ? '.' : target);
        const r = spawnSync(bin, args, { cwd: c.root, encoding: 'utf8', timeout: 180000, windowsHide: true, maxBuffer: 8 * 1024 * 1024 });
        if (r.error) throw new Error('Linter indisponible : ' + r.error.message);
        const body = (String(r.stdout || '') + (String(r.stderr || '') ? '\n' + r.stderr : '')).trim();
        const errCount = (body.match(/\berror\b/gi) || []).length, warnCount = (body.match(/\bwarning\b/gi) || []).length;
        const head = `${L.id} sur ${target} — code de sortie ${r.status}${errCount || warnCount ? ` (${errCount} erreur(s), ${warnCount} avertissement(s) détectés)` : ''}`;
        if (!body) return head + '\nAucune remarque : le code passe le linter.';
        return head + '\n' + body.slice(0, 6000) + (body.length > 6000 ? '\n… (sortie tronquée)' : '');
      },
    },

    // ---------------------------------------------------------------- PORTS
    port_check: {
      desc: 'Vérifie si un port TCP local répond et liste les ports en écoute sur la machine. args:{port?, host?:"127.0.0.1", list?:true, timeout?:ms}',
      run: async a => {
        if (a.list) {
          const list = listeningPorts();
          if (!list.length) return 'Aucun port en écoute détecté (ss / netstat / lsof indisponibles ou aucun résultat).';
          return list.sort((x, y) => x.port - y.port).map(p => `${String(p.port).padStart(6)}  ${p.proto}  ${p.addr}`).join('\n');
        }
        const port = +a.port;
        if (!port || port < 1 || port > 65535) throw new Error('port manquant ou invalide (args:{port:3000})');
        const host = String(a.host || '127.0.0.1');
        const t0 = Date.now(), st = await probePort(host, port, a.timeout);
        return `Port ${port} sur ${host} : ${st} (${Date.now() - t0} ms)`;
      },
    },

    // ---------------------------------------------------------------- CODE DUPLIQUÉ
    duplicate_code: {
      desc: 'Détecte les blocs de code dupliqués (copier-coller) dans le projet. args:{path?, minLines?:4-40, max?:20}',
      run: async (a, c) => {
        const d = dirOf(a.path || '.', c), min = Math.min(40, Math.max(4, +a.minLines || 6)), max = Math.min(50, Math.max(1, +a.max || 12));
        const groups = new Map();
        for (const f of textFiles(d)) {
          let L;
          try { L = fs.readFileSync(path.join(d, f), 'utf8').split('\n'); } catch { continue; }
          const norm = [];
          L.forEach((l, i) => {
            const t = l.replace(/\s+/g, ' ').trim();
            if (!t || /^(\/\/|#(?!#)|\/\*|\*|<!--)/.test(t)) return;
            norm.push({ t, line: i + 1 });
          });
          if (norm.length < min) continue;
          for (let i = 0; i + min <= norm.length; i++) {
            const block = norm.slice(i, i + min), key = crypto.createHash('sha1').update(block.map(b => b.t).join('\n')).digest('hex');
            let g = groups.get(key);
            if (!g) { g = { lines: block.map(b => b.t), hits: [] }; groups.set(key, g); }
            g.hits.push({ file: f, line: block[0].line });
          }
        }
        const dup = [...groups.values()].filter(g => g.hits.length > 1).sort((x, y) => y.hits.length * y.lines.length - x.hits.length * x.lines.length);
        // deux fenêtres qui se chevauchent dans le même fichier décrivent le même bloc : on n’en garde qu’une
        const kept = [];
        for (const g of dup) {
          const overlap = kept.some(k => k.hits.some(h1 => g.hits.some(h2 => h1.file === h2.file && Math.abs(h1.line - h2.line) < k.lines.length)));
          if (!overlap) kept.push(g);
        }
        if (!kept.length) return `Aucun bloc dupliqué trouvé (blocs de ${min} lignes ou plus).`;
        let wasted = 0;
        const out = [`Blocs dupliqués détectés (${kept.length} groupe(s), blocs de ${min} lignes) :`];
        for (const g of kept.slice(0, max)) {
          wasted += g.hits.length * g.lines.length - g.lines.length;
          out.push(`\n· ${g.hits.length} occurrences × ${g.lines.length} lignes`);
          g.hits.slice(0, 8).forEach(h => out.push(`    ${h.file}:${h.line}`));
          if (g.hits.length > 8) out.push(`    … et ${g.hits.length - 8} autre(s)`);
          out.push('    ' + g.lines.slice(0, 4).map(s => '│ ' + s.slice(0, 110)).join('\n    '));
        }
        out.push(`\nEstimation : ${wasted} lignes dupliquées (hors groupes au-delà du top ${max}).`);
        return out.join('\n');
      },
    },

    // ---------------------------------------------------------------- IMAGES
    convert_image: {
      desc: 'Convertit réellement une image (PNG, JPEG, BMP, GIF, WebP) en PNG, PPM, BMP ou représentation numérique, à la résolution demandée (c’est un maximum : jamais d’agrandissement). args:{path, out?, format?:"png|ppm|bmp|txt", size?:16-256, colors?}',
      run: async (a, c) => {
        const src = perms.norm(a.path, c.root);
        if (!fs.existsSync(src) || fs.statSync(src).isDirectory()) throw new Error('Image inexistante : ' + a.path);
        const buf = fs.readFileSync(src);
        const format = String(a.format || 'png').toLowerCase();
        if (!['png', 'ppm', 'bmp', 'txt'].includes(format)) throw new Error('format inconnu : ' + format + ' (png, ppm, bmp, txt)');
        const size = Math.min(256, Math.max(16, +a.size || 128));
        const imagecodec = require('./imagecodec'), vision = require('./vision');
        const r = await imagecodec.prepare(buf, { name: path.basename(src), size, encoding: 'auto', lite: false, maxChars: 400000, colors: Math.min(62, +a.colors || 16) });
        const w = r.rep.width, h = r.rep.height, px = r._px;
        if (!px || !w || !h) throw new Error('Image non convertible');
        const rgb = Buffer.from(px.buffer, px.byteOffset, px.length);
        let outRel = String(a.out || '');
        if (!outRel) {
          const dir = path.dirname(a.path) === '.' ? '' : path.dirname(a.path) + '/';
          outRel = dir + path.basename(a.path).replace(/\.[^.]+$/, '') + '-' + format + (format === 'png' ? '.png' : format === 'ppm' ? '.ppm' : format === 'bmp' ? '.bmp' : '.txt');
        }
        const dest = outGuard(outRel, c, hidden);
        let data;
        if (format === 'png') data = vision.encodeRGB(w, h, rgb);
        else if (format === 'ppm') data = ppm(w, h, rgb);
        else if (format === 'bmp') data = bmp24(w, h, rgb);
        else data = Buffer.from((r.rep.palette ? 'légende : ' + r.rep.palette.map((col, i) => `${i}=#${col.map(v => v.toString(16).padStart(2, '0')).join('')}`).join(' ') + '\n' : '') + 'données (ligne 1 = haut) :\n' + r.rep.data, 'utf8');
        fs.mkdirSync(path.dirname(dest), { recursive: true });
        fs.writeFileSync(dest, data);
        c.created?.add(dest);
        const orig = r.meta.original, ratio = orig.width && orig.height ? (w / Math.max(1, orig.width)).toFixed(3) : '?';
        return `Image convertie : ${outRel}\nformat : ${format.toUpperCase()} · ${w}×${h} px · ${sizeStr(data.length)} · original ${orig.width}×${orig.height} px (échelle ${ratio})`;
      },
    },

    // ---------------------------------------------------------------- ARCHIVES
    archive_files: {
      desc: 'Crée, liste ou extrait une archive ZIP du projet (écriture ZIP native, sans dépendance). args:{action:"create"|"list"|"extract", path?, out?, files?:"a.txt,b.txt"}',
      run: async (a, c) => {
        const act = String(a.action || 'create').toLowerCase();
        if (act === 'list' || act === 'extract') {
          if (!a.path) throw new Error('chemin de l’archive manquant (args:{path})');
          const src = perms.norm(a.path, c.root);
          if (!fs.existsSync(src)) throw new Error('Archive inexistante : ' + a.path);
          const entries = zipRead(fs.readFileSync(src));
          if (act === 'list') {
            const total = entries.reduce((n, e) => n + e.size, 0);
            return `${path.basename(src)} — ${entries.length} entrée(s), ${sizeStr(total)} décompressées\n` +
              entries.slice(0, 200).map(e => `  ${String(e.size).padStart(10)}  ${e.name}`).join('\n') + (entries.length > 200 ? `\n  … et ${entries.length - 200} autre(s)` : '');
          }
          const destRel = String(a.out || path.basename(src).replace(/\.zip$/i, '') || 'archive');
          const dest = outGuard(destRel, c, hidden);
          const written = [];
          for (const e of entries) {
            if (!e.name || e.name.endsWith('/')) continue;
            const clean = e.name.replace(/\\/g, '/');
            if (clean.startsWith('/') || /^[a-zA-Z]:\//.test(clean)) throw new Error('Entrée d’archive refusée (chemin absolu) : ' + e.name);
            if (!clean || clean.split('/').includes('..')) throw new Error('Entrée d’archive refusée (traversée de chemin) : ' + e.name);
            const target = path.resolve(dest, clean);
            if (!pathGuard.isInside(target, dest)) throw new Error('Entrée d’archive refusée (chemin absolu) : ' + e.name);
            fs.mkdirSync(path.dirname(target), { recursive: true });
            fs.writeFileSync(target, e.data);
            c.created?.add(target);
            written.push(path.relative(dest, target));
          }
          return `Archive extraite : ${written.length} fichier(s) dans ${destRel}/\n` + written.slice(0, 60).map(f => '  ' + f).join('\n') + (written.length > 60 ? `\n  … et ${written.length - 60} autre(s)` : '');
        }
        if (act !== 'create') throw new Error('action inconnue : ' + act + ' — choix : create, list, extract');
        const src = perms.norm(a.path || '.', c.root);
        if (!fs.existsSync(src)) throw new Error('Chemin inexistant : ' + (a.path || '.'));
        let list = [];
        if (a.files) list = (Array.isArray(a.files) ? a.files : String(a.files).split(',')).map(s => String(s).trim()).filter(Boolean);
        const entries = [];
        const push = (name, abs) => {
          const st = fs.lstatSync(abs);
          if (st.isSymbolicLink()) return;
          entries.push({ name: name.replace(/\\/g, '/'), data: fs.readFileSync(abs), mtime: st.mtime });
        };
        if (list.length) {
          for (const f of list) {
            const abs = perms.norm(f, c.root);
            if (!fs.existsSync(abs)) throw new Error('Fichier inexistant : ' + f);
            if (fs.statSync(abs).isDirectory()) throw new Error('Répertoire non supporté dans files: (utilise path: sur le dossier) : ' + f);
            push(path.basename(abs), abs);
          }
        } else if (fs.statSync(src).isDirectory()) {
          let rel;
          try { rel = walk(src, src); } catch (e) { throw new Error(e.message); }
          for (const r of rel) { if (!r.endsWith('/')) push(r, path.join(src, r)); }
        } else push(path.basename(src), src);
        if (!entries.length) throw new Error('Archive vide : rien à compresser');
        const outRel = String(a.out || path.basename(src).replace(/\.[^.]+$/, '') + '.zip');
        const dest = outGuard(outRel, c, hidden);
        const buf = zipCreate(entries);
        fs.writeFileSync(dest, buf);
        c.created?.add(dest);
        return `Archive créée : ${outRel} (${entries.length} fichier(s), ${sizeStr(buf.length)})`;
      },
    },
  };
};

module.exports.parseYaml = parseYaml;
module.exports.parseToml = parseToml;
module.exports.parseIni = parseIni;
module.exports.parseEnv = parseEnv;
module.exports.zipCreate = zipCreate;
module.exports.zipRead = zipRead;
module.exports.crc32 = crc32;
module.exports.getPath = getPath;
