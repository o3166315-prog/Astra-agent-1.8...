// Boucle d’agent Astra Agent : compréhension -> clarification éventuelle -> plan -> action -> exécution -> observation (capture / vision) -> correction -> vérification -> fin.
const {providers}=require('./providers'),{tools}=require('./tools'),{envTools}=require('./envtools'),perms=require('./perms'),vision=require('./vision'),intent=require('./intent'),caps=require('./caps');
const classifyTask=msg=>{
 const s=String(msg||'').trim();
 const explicitMutation=/\b(cr[ée]e|cr[ée]er|ajoute|ajouter|modifie|modifier|change|changer|remplace|remplacer|corrige|corriger|refactor|refais|refaire|écris|[ée]cris|g[ée]n[èe]re|impl[ée]mente|installe|configure|renomme|déplace|supprime|supprimer)\b/i.test(s);
 const destructive=/\b(supprime|supprimer|efface|effacer|écrase|[ée]craser|reset|réinitialise|format)\b/i.test(s);
 const needsPlan=s.length>160||/\b(plusieurs|int[ée]gr|syst[èe]me|architecture|refonte|entier|toute|tout|compl[èe]t|workflow|auth|database|base de donn[ée]es|migration)\b/i.test(s);
 const verificationContext=explicitMutation||/\b(v[ée]rif|teste|test|corrige|bug|fonctionne|build|compile|compil)\b/i.test(s);
 const it=intent.classify(s);
 return {level:it.kind==='clarify'?'clarify':needsPlan?'complex':'small',explicitMutation,destructive,verificationContext,base:it.kind==='base'?it.hint:'',clarifyText:it.text||''};
};
const SYS=(list,mem,capsTxt,envTxt,task)=>`You are Astra Agent, an autonomous software-development agent working in the user's project folder on the user's real machine. Reply with ONE JSON object only (no markdown, no text around it).
Message types (field "type"):
{"type":"action","say":"short sentence","reason":"one short reason","plan":["step 1","step 2"],"tool":"tool_name","args":{}}   -> run ONE tool
{"type":"observation","say":"what you saw or learned (result, screenshot, error)"}   -> then continue with an action
{"type":"correction","say":"what was wrong and how you fix it"}   -> then act
{"type":"clarification","say":"1-3 short questions"}   -> ONLY if essential information is missing
{"type":"final","say":"result summary"}   -> only when the work is DONE and VERIFIED
(The older forms {"say":..,"tool":..,"args":..} and {"final":".."} are also accepted.)
Task level: ${task.level}.${task.base?'\n'+task.base:''}
PRINCIPLES
1. The user's request IS the authorization for what it asks: create or edit files, run, test, build, compile, fix your own code, install what the task needs. NEVER ask "may I...?", "shall I create...?" or "do you confirm?". Just act. Dangerous or external operations are confirmed by the runtime, not by you: if the runtime refuses an action, adapt.
2. Ask a clarification only when a missing detail prevents a reasonable result or would change it a lot (max 3 short questions). If the request is vague but a reasonable first version is possible, state your interpretation in one sentence, build a working base, then ask what to refine. Never block waiting for many details.
3. Work loop: understand -> short plan (only for medium or complex work) -> implement -> RUN it -> OBSERVE (screenshot when a screen/browser environment is active) -> find problems -> FIX -> run again -> verify -> final. The user must never have to say "now run it / look at it / fix it": that is part of the task.
4. Use only real tools. Never claim that you ran, built, tested, saw or clicked something you did not. If a capability is unavailable (see below), adapt or say so honestly.
5. If a result starts with ERROR or shows a non-zero exit code: read the error, find the cause, fix it, retry.
6. Prefer targeted context: search_files / read_file before guessing. One tool per turn. Answer in the user's language and keep "say" short.
Example: {"type":"action","say":"Je crée la page","reason":"fichier principal nécessaire","plan":["créer index.html","tester","vérifier visuellement"],"tool":"write_file","args":{"path":"index.html","content":"<h1>Hi</h1>"}}
Tools:
${list}
${capsTxt}
${envTxt}
${mem?'Memory:\n'+mem:''}`;
const parse=raw=>{raw=String(raw).replace(/```(json)?/gi,'');const a=raw.indexOf('{'),b=raw.lastIndexOf('}');if(a<0||b<a)return null;try{return JSON.parse(raw.slice(a,b+1))}catch{return null}};
// texte partiel d'une réponse finale/clarification pendant le streaming
const partial=raw=>{const fin=/"type"\s*:\s*"(final|clarification)"/.test(raw),m=fin?/"say"\s*:\s*"/.exec(raw):/"final"\s*:\s*"/.exec(raw);if(!m)return null;let s='';for(let i=m.index+m[0].length;i<raw.length;i++){const c=raw[i];if(c==='"')break;if(c==='\\'){const n=raw[i+1];if(n===undefined)break;if(n==='u'){if(i+6>raw.length)break;s+=String.fromCharCode(parseInt(raw.slice(i+2,i+6),16));i+=5}else{s+={n:'\n',t:'\t',r:'\r'}[n]??n;i++}}else s+=c}return s};
const wantAuto=(mode,env,n,a,root)=>env.driver.auto&&(mode==='all'?!['screenshot','list_dir','read_file','search_files','detect_tools','remember','read_lines','find_files','file_info','diff_files','json_query','check_syntax','calculate','get_time','system_info','project_summary','todo','http_request','search_regex','tree','code_stats','find_todos','outline_code','csv_info','git_status','git_log','git_diff','hash_text','encode_decode','uuid_generate','regex_test','date_calc','project_deps','env_keys','config_query','port_check','duplicate_code','git_branch','lint_code'].includes(n):mode==='important'&&(n.startsWith('gui_')||(n==='run_command'&&a.background)||(n==='write_file'&&env.driver.id==='browser'&&/\.(html?|js|css)$/i.test(a.path||'')&&require('fs').existsSync(require('path').join(root,'index.html')))));
const tok=s=>Math.ceil(String(s).length/3.2);
const fit=(hist,budget,asJson)=>{const out=[];let used=0;for(let i=hist.length-1;i>=0;i--){let c=String(hist[i].content);if(c.length>2000&&i<hist.length-2)c=c.slice(0,2000)+'…';const t=tok(c)+10;if(used+t>budget&&out.length>=2)break;used+=t;out.unshift({role:hist[i].role,content:asJson&&hist[i].role==='assistant'?JSON.stringify({type:'final',say:c}):c})}return out};
const budget=(prov,s)=>prov==='ollama'||prov==='local'?(s[prov]?.ctx||8192)*0.55:24000;
const vis={};const canSee=async(prov,s,model)=>{const k=prov+'|'+model;if(!(k in vis))vis[k]=await providers[prov].vision(s[prov]||{},model).catch(()=>false);return vis[k]};
const toolStatus=(name,args)=>name==='list_dir'||name==='search_files'?'Recherche…':name==='read_file'?'Lecture de '+(args.path||'fichier')+'…':name==='write_file'?'Modification de '+(args.path||'fichier')+'…':name==='run_command'?'Exécution : '+String(args.command||'').slice(0,50)+'…':name==='screenshot'?'Observation de l’écran…':name==='detect_tools'?'Détection des outils…':name==='edit_file'||name==='append_file'?'Modification de '+(args.path||'fichier')+'…':name==='run_tests'?'Lancement des tests…':name==='search_regex'?'Recherche dans le code…':name==='tree'?'Lecture de l’arborescence…':name.startsWith('git_')?'Lecture de git…':name==='format_json'?'Mise en forme de '+(args.path||'JSON')+'…':name==='check_syntax'?'Vérification de la syntaxe…':name==='http_request'?'Requête '+String(args.url||'').slice(0,50)+'…':name==='lint_code'?'Analyse du code…':name==='project_deps'?'Analyse des dépendances…':name==='env_keys'?'Lecture des variables d’environnement…':name==='config_query'?'Lecture de la configuration…':name==='port_check'?'Test du port…':name==='duplicate_code'?'Recherche de code dupliqué…':name==='convert_image'?'Conversion de l’image…':name==='archive_files'?'Traitement de l’archive…':name.startsWith('mcp:')?'Utilisation de '+name.split(':')[1]+'…':'Exécution de '+name+'…';
const CODE=/\.(html?|js|mjs|cjs|ts|jsx|tsx|py|c|cc|cpp|h|hpp|cs|java|rs|go|gd|lua|css)$|CMakeLists\.txt$/i;
exports.classifyTask=classifyTask;
exports.chat=async({prov,model,settings,msg,images,history,mem,emit,signal})=>{
 const P=providers[prov];if(!P){emit('error',{text:'Provider inconnu : '+prov});return}
 const m=[...mem.project,...mem.prefs].map(x=>x.text).join('\n');emit('status',{s:'Réponse…'});
 try{const t=await P.chat(settings[prov]||{},model,[{role:'system',content:"Tu es Astra Agent, un assistant. Réponds dans la langue de l'utilisateur, clairement et simplement."+(m?'\nMémoire :\n'+m:'')},...fit(history,budget(prov,settings),false),{role:'user',content:msg,...(images?.length?{images}:{})}],{plain:true,signal,onChunk:(n,pc)=>{emit('delta',{text:pc});emit('progress',{n})}});emit('final',{text:t});return t}catch(e){if(!signal?.aborted)emit('error',{text:e.message})}
};
exports.run=async({prov,model,settings,msg,images,history,root,mem,mcp,emit,ask,askLoop,signal,env,autoShot,grants={},created=new Set(),drivers,waitIfPaused=async()=>{}})=>{
 const task=classifyTask(msg);emit('task',{level:task.level});
 const all={...tools};if(env)for(const[n,t]of Object.entries(envTools)){const k={gui_click:'click',gui_type:'type',gui_key:'key'}[n];if(!k||env.caps?.[k])all[n]=t}
 for(const s of mcp)for(const t of s.tools)all[`mcp:${s.cfg.name}:${t.name}`]={desc:(t.description||'')+' args:'+JSON.stringify(Object.keys(t.inputSchema?.properties||{})),run:a=>s.call(t.name,a)};
 const list=Object.entries(all).map(([n,t])=>`- ${n}: ${t.desc}`).join('\n');
 const capsTxt=caps.describe(await caps.detect()),envTxt=caps.describeEnv(env,drivers);
 const msgs=[{role:'system',content:SYS(list,[...mem.project,...mem.prefs].map(m=>m.text).join('\n'),capsTxt,envTxt,task)},...fit(history,budget(prov,settings),true),{role:'user',content:msg,...(images?.length?{images}:{})}];
 const P=providers[prov];if(!P)throw new Error('Provider inconnu : '+prov);
 let plan=[],bad=0,nonAct=0,nudged=false,verified=false,shotN=0;const dirty=[],seen={},vmem=[],meta=new WeakMap();
 const userInstall=/install|npm i\b|d[ée]pendanc|pip install|npm ci|yarn add|pnpm add/i.test(msg),ctx={root,emit,env,mem,task,created,changes:[],imageBudget:Math.min(20000,Math.round(budget(prov,settings)*3.2*0.4))},pctx={root,env,created,userMsg:msg,userInstall};
 const showPlan=()=>emit('plan',{plan});
 // Capture -> texte/image pour le modèle + mémoire visuelle compacte
 const observe=async(shot,um)=>{let lite=null,err='';try{lite=await vision.analyze(Buffer.from(shot.b64,'base64'),{noOcr:settings.visionOcr===false})}catch(e){err=e.message}
  const n=++shotN,prev=vmem[vmem.length-1],rec={n,bullets:lite?lite.bullets:['capture non analysable : '+err],items:lite?lite.items:[]},base=um.content;
  msgs.forEach(x=>{delete x.images;const m=meta.get(x);if(m){x.content=m.base+'\n[SHOT #'+m.n+' (ancienne capture, résumé) '+m.bullets.join('; ')+']';meta.delete(x)}});
  const vm=settings.visionMode||'auto';let how='lite',block='',desc;
  if(vm!=='lite'&&await canSee(prov,settings,model)){how='native';um.images=[{mime:shot.mime,b64:shot.b64}];block="[SHOT #"+n+": the real screenshot is attached as an image: analyse it to decide the next action]"+(lite?'\n[pixel summary] '+lite.bullets.join('; '):'')}
  else if(vm!=='lite'&&settings.vision?.prov&&settings.vision?.model){try{desc=await providers[settings.vision.prov].chat(settings[settings.vision.prov]||{},settings.vision.model,[{role:'user',content:'Décris précisément cet écran : fenêtres, textes lisibles, couleurs, erreurs visibles.',images:[{mime:shot.mime,b64:shot.b64}]}],{plain:true,signal});how='model';block='[SHOT #'+n+' described by vision model '+settings.vision.model+'] '+desc}catch(e){block='[vision model failed: '+e.message+']'+(lite?'\n[VISION LITE · SHOT #'+n+']\n'+lite.text:'')}}
  else block=lite?'[VISION LITE · SHOT #'+n+' — pixel analysis of the REAL screenshot (no multimodal model involved)]\n'+lite.text:'[screenshot saved but could not be analysed: '+err+']';
  if(prev&&lite)block+='\n[CHANGES since SHOT #'+prev.n+'] '+vision.diff(prev,rec).join('; ');
  if(vmem.length)block+='\n[VISUAL MEMORY] '+vmem.slice(-6).map(r=>'SHOT #'+r.n+': '+r.bullets.join('; ')).join(' || ');
  vmem.push(rec);um.content=base+'\n'+block;if(how!=='native')meta.set(um,{base,n,bullets:rec.bullets});
  return{how,analysis:lite?.text,bullets:rec.bullets,desc}};
 for(let step=0;step<30&&!signal.aborted;step++){
  await waitIfPaused();if(signal.aborted)break;
  emit('status',{s:step===0?'Analyse de la demande…':'Poursuite de la tâche…'});
  let raw,sent='',lastN=0;try{raw=await P.chat(settings[prov]||{},model,msgs,{signal,onChunk:(n,pc,out)=>{if(n<lastN)lastN=0;if(n-lastN>=40){lastN=n;emit('progress',{n})}const p=partial(out);if(p!=null&&p.length>sent.length){emit('delta',{text:p.slice(sent.length)});sent=p}}})}catch(e){if(!signal.aborted)emit('error',{text:e.message});return}
  msgs.push({role:'assistant',content:raw});const j=parse(raw);
  if(!j){if(++bad>=2){const t=String(raw).trim()||'(réponse vide)';emit('final',{text:t});return t}msgs.push({role:'user',content:'Invalid. Reply with ONLY one valid JSON object.'});emit('say',{text:'Réponse non valide, nouvelle tentative…'});continue}
  bad=0;
  const typ=String(j.type||'').toLowerCase(),name=j.tool||j.tool_name||(typeof j.action==='string'&&j.action!=='action'?j.action:undefined)||j.name,args=j.args||j.arguments||j.parameters||{},say=j.say??j.message??j.response??j.answer??j.text??j.reply;
  if(j.reason)emit('decision',{text:String(j.reason).slice(0,220)});
  if(Array.isArray(j.plan)&&j.plan.length&&(task.level!=='small'||j.plan.length>=3)){plan=j.plan.slice(0,7).map((x,i)=>({t:typeof x==='string'?x:(x.t||x.step||JSON.stringify(x)),done:!!(plan[i]?.done||x.done)}));showPlan()}
  if(typ==='clarification'||(task.level==='clarify'&&!name&&j.final===undefined)){const t=String(say||j.question||'J’ai besoin de quelques précisions avant de commencer.');emit('final',{text:t,clarify:true});return t}
  if(typ==='final'||j.final!==undefined){const t=String(j.final??say??'');
   if(dirty.length&&!verified&&!nudged&&step<28){nudged=true;emit('say',{text:'Vérification avant de conclure…'});msgs.push({role:'user',content:'Before finishing: you changed code files ('+dirty.slice(-4).join(', ')+') but have not successfully run or observed the result yet. Run/test it now (take a screenshot if a browser or screen environment is active), fix any problem, then give the final. If nothing can be executed here, say so honestly in the final.'});continue}
   plan.forEach(p=>p.done=true);if(plan.length)showPlan();emit('final',{text:t});return t}
  if(!name&&['observation','correction','plan'].includes(typ)){if(say)emit('say',{text:String(say),kind:typ});if(++nonAct>=3){const t=String(say||'Terminé.');emit('final',{text:t});return t}msgs.push({role:'user',content:'Continue: give the next action (JSON with a tool) or the final.'});continue}
  nonAct=0;if(say&&name)emit('say',{text:String(say),kind:typ==='correction'?'correction':undefined});
  if(!name){if(say){emit('final',{text:String(say)});return String(say)}msgs.push({role:'user',content:'ERROR: no tool given. Give a tool or a final.'});continue}
  const t=all[name];
  if(!t){msgs.push({role:'user',content:'ERROR: unknown tool "'+name+'". Tools: '+Object.keys(all).join(', ')});emit('error',{text:'Outil indisponible : '+name});continue}
  const key=name+JSON.stringify(args);const count=(seen[key]=(seen[key]||0)+1);if(count>=(name==='screenshot'?6:4)){const loopId=Math.random().toString(36).slice(2);emit('loop',{id:loopId,name,args,count});const decision=await askLoop(loopId);if(decision!=='skip'){emit('error',{text:'Agent arrêté à la demande de l’utilisateur après détection de boucle.'});return}msgs.push({role:'user',content:'LOOP: the current action was detected as repetitive. Skip this step and continue with a different useful action; do not repeat the same tool/arguments unless you have a concrete reason.'});emit('say',{text:'Étape ignorée, je poursuis avec une autre action.'});continue}
  await waitIfPaused();if(signal.aborted)break;
  const cls=perms.classifyTool(name,args,pctx),dec=perms.decide(cls,grants),perm=dec.perm,id=Math.random().toString(36).slice(2);
  emit('tool',{id,name,args,perm,cat:cls.cat,reason:cls.reason||'',auto:dec.auto||''});
  if(perm!=='SAFE'){emit('status',{s:'Validation requise…'});if(!await ask(id)){emit('result',{id,ok:false,text:'Refusé par l’utilisateur'});msgs.push({role:'user',content:'ERROR: the user refused this action. Propose an alternative or finish.'});continue}}
  emit('status',{s:toolStatus(name,args)});
  try{const r=await t.run(args,ctx);let out=String(r&&r.text!==undefined?r.text:r),shot=r&&r.shot,auto=false;
   if(r?.diff)emit('diff',{id,name,path:r.path||r.diff.file,diff:r.diff,changeId:r.changeId});
   if(!shot&&env&&wantAuto(autoShot,env,name,args,root)){try{shot=await env.capture({});auto=true}catch(e){out+='\n(capture auto échouée : '+e.message+')'}}
   if(['write_file','edit_file','append_file'].includes(name)&&CODE.test(args.path||'')){dirty.push(args.path);verified=false}
   if((name==='run_command'||name==='run_tests'||shot)&&dirty.length)verified=true;
   const um={role:'user',content:'RESULT: '+out.slice(0,4000)};let o=null;
   if(shot)o=await observe(shot,um);
   emit('result',{id,ok:true,text:out.slice(0,1500)});if(shot)emit('shot',{id,name:shot.name,url:shot.url,w:shot.w,h:shot.h,auto,mode:o.how,analysis:o.analysis,bullets:o.bullets,desc:o.desc});
   msgs.push(um);const p=plan.find(x=>!x.done);if(p){p.done=true;showPlan()}
  }catch(e){emit('result',{id,ok:false,text:e.message});msgs.push({role:'user',content:'ERROR: '+e.message+'. Analyse the cause, fix it and retry.'})}
 }
 emit('error',{text:'Arrêt : limite de 30 étapes atteinte ou tâche interrompue.'});
};
