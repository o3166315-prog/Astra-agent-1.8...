/* Kairo V5.2 — couche d'interface additive.
   Chargée APRÈS le script de index.html. Elle n'en remplace rien : elle ajoute (barre de menus, palette, recherche,
   outils, accueil…) et réutilise les fonctions/boutons existants. Chaque fonctionnalité est isolée par guard() :
   si l'une échoue, le reste de l'application continue de fonctionner. */
(() => {
'use strict';
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const ic = (n, c = '') => `<svg class="svg-icon ${c}" aria-hidden="true"><use href="icons/icons.svg#${n}"></use></svg>`;
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const norm = s => String(s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
const guard = (name, fn) => { try { return fn(); } catch (e) { console.warn('[astra-ui] ' + name + ' :', e); } };
const stop = e => { e.preventDefault(); e.stopImmediatePropagation(); };
const pref = {
  get(k, d) { try { const v = localStorage.getItem('kui.' + k); return v === null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v) { try { localStorage.setItem('kui.' + k, JSON.stringify(v)); } catch {} },
};
// Accès (tolérant) aux variables globales de index.html.
const curFile = () => { try { return openFile || ''; } catch { return ''; } };
const fileList = () => { try { return Array.isArray(files) ? files : []; } catch { return []; } };
const curTab = () => { try { return tab; } catch { return ''; } };
const curTheme = () => { try { return themeMode; } catch { return ''; } };
const ED = () => $('#editor');
const isMac = /Mac|iPhone|iPad/.test(navigator.platform || '');
const MOD = isMac ? '⌘' : 'Ctrl';

/* ── Notifications ───────────────────────────────────────────────────────────────────────── */
let toastBox;
function toast(msg, type = 'info', ms = 2400) {
  if (!toastBox) { toastBox = document.createElement('div'); toastBox.className = 'ktoasts'; toastBox.setAttribute('role', 'status'); toastBox.setAttribute('aria-live', 'polite'); document.body.append(toastBox); }
  const el = document.createElement('div'); el.className = 'kt ' + type;
  el.innerHTML = ic({ ok: 'check', warn: 'warning', err: 'warning', info: 'info' }[type] || 'info') + '<span>' + esc(msg) + '</span>';
  toastBox.append(el);
  while (toastBox.children.length > 3) toastBox.firstChild.remove();
  setTimeout(() => { el.classList.add('out'); setTimeout(() => el.remove(), 260); }, ms);
}
const copyText = async (t, ok = 'Copié dans le presse-papiers') => {
  try { await navigator.clipboard.writeText(t); toast(ok, 'ok'); }
  catch { const a = document.createElement('textarea'); a.value = t; document.body.append(a); a.select(); try { document.execCommand('copy'); toast(ok, 'ok'); } catch { toast('Copie impossible', 'err'); } a.remove(); }
};

/* ── Aides d'édition (conservent l'historique Annuler / Rétablir) ───────────────────────── */
const needFile = () => { if (curFile()) return true; toast('Ouvre d’abord un fichier', 'warn'); return false; };
function edReplace(start, end, text) {
  const e = ED(); e.focus(); e.setSelectionRange(start, end);
  let ok = false;
  try { ok = text === '' ? document.execCommand('delete') : document.execCommand('insertText', false, text); } catch {}
  if (!ok) { e.setRangeText(text, start, end, 'end'); e.dispatchEvent(new Event('input', { bubbles: true })); }
}
const lineStart = (v, i) => v.lastIndexOf('\n', i - 1) + 1;
const lineEnd = (v, i) => { const x = v.indexOf('\n', i); return x < 0 ? v.length : x; };
// Bloc de lignes touché par la sélection : [début, fin] (fin sans le \n).
function block(e) {
  const v = e.value; let s = e.selectionStart, t = e.selectionEnd;
  if (t > s && v[t - 1] === '\n') t--;
  return [lineStart(v, s), lineEnd(v, t), s, e.selectionEnd];
}
const COMMENT = { js: '//', jsx: '//', ts: '//', tsx: '//', mjs: '//', cjs: '//', c: '//', cpp: '//', h: '//', hpp: '//', cs: '//', java: '//', rs: '//', go: '//', php: '//', kt: '//', swift: '//', scss: '//', gd: '#', py: '#', sh: '#', rb: '#', yml: '#', yaml: '#', toml: '#', pl: '#', ps1: '#', ini: ';', sql: '--', lua: '--' };
const extOf = p => (String(p).split('.').pop() || '').toLowerCase();

const EDIT = {
  duplicate() {
    if (!needFile()) return; const e = ED(), v = e.value, [ls, le] = block(e), t = v.slice(ls, le);
    edReplace(le, le, '\n' + t); e.setSelectionRange(le + 1, le + 1 + t.length);
  },
  move(dir) {
    if (!needFile()) return; const e = ED(), v = e.value, [ls, le, s, t] = block(e);
    if (dir < 0) {
      if (ls === 0) return; const ps = lineStart(v, ls - 1), prev = v.slice(ps, ls - 1), cur = v.slice(ls, le);
      edReplace(ps, le, cur + '\n' + prev); e.setSelectionRange(s - (ls - ps), t - (ls - ps));
    } else {
      if (le >= v.length) return; const ne = lineEnd(v, le + 1), next = v.slice(le + 1, ne), cur = v.slice(ls, le), d = next.length + 1;
      edReplace(ls, ne, next + '\n' + cur); e.setSelectionRange(s + d, t + d);
    }
  },
  comment() {
    if (!needFile()) return; const tok = COMMENT[extOf(curFile())];
    if (!tok) return toast('Commentaire non géré pour ce type de fichier', 'warn');
    const e = ED(), v = e.value, [ls, le, s, t] = block(e), lines = v.slice(ls, le).split('\n'), live = lines.filter(l => l.trim());
    const all = live.length && live.every(l => l.trimStart().startsWith(tok));
    const ind = Math.min(...live.map(l => l.match(/^\s*/)[0].length), 1e9);
    const out = lines.map(l => !l.trim() ? l : all ? l.replace(tok + ' ', '').replace(tok, '') : l.slice(0, ind) + tok + ' ' + l.slice(ind)).join('\n');
    edReplace(ls, le, out); e.setSelectionRange(ls, ls + out.length);
  },
  indent(back) {
    const e = ED(), v = e.value, [ls, le, s, t] = block(e), multi = e.selectionStart !== e.selectionEnd && v.slice(s, t).includes('\n');
    if (!back && !multi && s === t) return edReplace(s, s, '  ');
    const lines = v.slice(ls, le).split('\n');
    const out = lines.map(l => back ? l.replace(/^(\t| {1,2})/, '') : l ? '  ' + l : l).join('\n');
    if (out === v.slice(ls, le)) return;
    edReplace(ls, le, out); e.setSelectionRange(ls, ls + out.length);
  },
  enter() {
    const e = ED(), v = e.value, s = e.selectionStart, ls = lineStart(v, s), indent = v.slice(ls, s).match(/^[ \t]*/)[0];
    const prev = v[s - 1], more = '{[(:'.includes(prev) && (prev !== ':' || /\.(py|gd|yml|yaml)$/i.test(curFile())) ? '  ' : '';
    edReplace(s, e.selectionEnd, '\n' + indent + more);
  },
  formatJson() {
    if (!needFile()) return; if (extOf(curFile()) !== 'json') return toast('Disponible pour les fichiers .json', 'warn');
    const e = ED(); let j; try { j = JSON.parse(e.value); } catch (x) { return toast('JSON invalide : ' + x.message.slice(0, 80), 'err', 4000); }
    const out = JSON.stringify(j, null, 2) + '\n'; if (out === e.value) return toast('Déjà formaté', 'info'); edReplace(0, e.value.length, out); toast('JSON mis en forme', 'ok');
  },
  trim() {
    if (!needFile()) return; const e = ED(), out = e.value.replace(/[ \t]+$/gm, ''); if (out === e.value) return toast('Aucun espace superflu', 'info');
    edReplace(0, e.value.length, out); toast('Espaces de fin de ligne supprimés', 'ok');
  },
  goto(n) {
    const e = ED(), L = e.value.split('\n'); n = Math.max(1, Math.min(L.length, Math.floor(+n) || 1));
    const pos = L.slice(0, n - 1).reduce((a, l) => a + l.length + 1, 0); e.focus(); e.setSelectionRange(pos, pos + L[n - 1].length); reveal(pos);
  },
};
let _cw = 0, _cwFont = '';
function charWidth(e) {
  const f = getComputedStyle(e).font; if (f === _cwFont && _cw) return _cw;
  const c = document.createElement('canvas').getContext('2d'); c.font = f; _cw = c.measureText('0').width || 7.8; _cwFont = f; return _cw;
}
function reveal(pos) {
  const e = ED(), v = e.value, line = v.slice(0, pos).split('\n').length - 1, lh = parseFloat(getComputedStyle(e).lineHeight) || 21, top = line * lh;
  if (top < e.scrollTop + lh || top > e.scrollTop + e.clientHeight - lh * 3) e.scrollTop = Math.max(0, top - e.clientHeight / 2);
  const left = (pos - (v.lastIndexOf('\n', pos - 1) + 1)) * charWidth(e);
  if (left < e.scrollLeft || left > e.scrollLeft + e.clientWidth - 80) e.scrollLeft = Math.max(0, left - e.clientWidth / 2);
}

/* ── Recherche / remplacement dans l'éditeur ─────────────────────────────────────────────── */
const F = { el: null, q: '', cs: false, re: false, matches: [], idx: -1, mirror: null };
const findOpen = () => !!(F.el && !F.el.hidden);
function mkRe() {
  if (!F.q) return null;
  try { return new RegExp(F.re ? F.q : F.q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), F.cs ? 'g' : 'gi'); } catch { return 'bad'; }
}
function computeMatches() {
  const re = mkRe(), v = ED().value; F.matches = [];
  if (re === 'bad') return 'bad'; if (!re) return;
  let m; while ((m = re.exec(v)) && F.matches.length < 5000) { if (m[0] === '') { re.lastIndex++; continue; } F.matches.push({ i: m.index, len: m[0].length }); }
}
function paintMirror() {
  const e = ED(), mir = F.mirror; if (!mir) return;
  if (!findOpen() || !F.matches.length || e.value.length > 400000) { mir.innerHTML = ''; return; }
  const v = e.value; let html = '', last = 0;
  F.matches.forEach((m, k) => { html += esc(v.slice(last, m.i)) + `<mark${k === F.idx ? ' class="cur"' : ''}>${esc(v.slice(m.i, m.i + m.len))}</mark>`; last = m.i + m.len; });
  mir.innerHTML = html + esc(v.slice(last)) + '\n';
  syncMirror();
}
function syncMirror() {
  const e = ED(), mir = F.mirror; if (!mir) return;
  mir.style.right = (e.offsetWidth - e.clientWidth) + 'px'; mir.style.bottom = (e.offsetHeight - e.clientHeight) + 'px';
  mir.scrollTop = e.scrollTop; mir.scrollLeft = e.scrollLeft;
}
function updateFind(keepIdx) {
  if (!F.el) return; const bad = computeMatches(), cnt = $('.kf-count', F.el), e = ED();
  if (!keepIdx || F.idx >= F.matches.length) F.idx = -1;
  if (F.idx < 0 && F.matches.length) { const k = F.matches.findIndex(m => m.i >= e.selectionStart); F.idx = k < 0 ? 0 : k; }
  cnt.textContent = bad ? 'Motif invalide' : !F.q ? '' : !F.matches.length ? 'Aucun résultat' : (F.idx + 1) + ' / ' + F.matches.length + (F.matches.length >= 5000 ? '+' : '');
  cnt.style.color = bad || (F.q && !F.matches.length) ? 'var(--danger)' : '';
  paintMirror();
}
function selectMatch() {
  const m = F.matches[F.idx]; if (!m) return; const e = ED(); e.setSelectionRange(m.i, m.i + m.len); reveal(m.i); paintMirror();
  $('.kf-count', F.el).textContent = (F.idx + 1) + ' / ' + F.matches.length + (F.matches.length >= 5000 ? '+' : '');
}
function stepFind(d) {
  if (!F.matches.length) return updateFind(); F.idx = (F.idx + d + F.matches.length) % F.matches.length; selectMatch();
}
function replaceOne() {
  const m = F.matches[F.idx]; if (!m) return; const e = ED(), rep = $('.kf-rep input', F.el).value;
  let text = rep; if (F.re) { const re = mkRe(); if (re && re !== 'bad') text = e.value.slice(m.i, m.i + m.len).replace(new RegExp(re.source, re.flags.replace('g', '')), rep); }
  const at = m.i + text.length; edReplace(m.i, m.i + m.len, text); e.setSelectionRange(at, at);
  updateFind(false); const nx = F.matches.findIndex(x => x.i >= at); F.idx = nx < 0 ? 0 : nx; if (F.matches.length) selectMatch();
}
function replaceAll() {
  if (!F.matches.length) return; const e = ED(), re = mkRe(), n = F.matches.length; if (!re || re === 'bad') return;
  const out = e.value.replace(re, $('.kf-rep input', F.el).value); edReplace(0, e.value.length, out); toast(n + ' remplacement' + (n > 1 ? 's' : ''), 'ok'); updateFind(false);
}
function buildFind() {
  const wrap = $('.editor-wrap'); if (!wrap || F.el) return;
  F.mirror = document.createElement('pre'); F.mirror.className = 'kmirror'; F.mirror.setAttribute('aria-hidden', 'true'); wrap.insertBefore(F.mirror, ED());
  const el = F.el = document.createElement('div'); el.className = 'kfind'; el.hidden = true; el.setAttribute('role', 'search');
  el.innerHTML = `<div class="kf-row"><input class="kf-q" placeholder="Rechercher" aria-label="Rechercher dans le fichier"><span class="kf-count"></span>
    <button class="kib kf-case" title="Respecter la casse" aria-label="Respecter la casse"><span class="kf-txt">Aa</span></button>
    <button class="kib kf-re" title="Expression régulière" aria-label="Expression régulière"><span class="kf-txt">.*</span></button>
    <button class="kib kf-prev" title="Précédent (Maj+Entrée)" aria-label="Précédent">${ic('arrow-up')}</button>
    <button class="kib kf-next" title="Suivant (Entrée)" aria-label="Suivant">${ic('arrow-down')}</button>
    <button class="kib kf-close" title="Fermer (Échap)" aria-label="Fermer">${ic('close')}</button></div>
    <div class="kf-row kf-rep" hidden><input placeholder="Remplacer par" aria-label="Remplacer par"><button class="kf-btn kf-r1">Remplacer</button><button class="kf-btn kf-ra">Tout</button></div>`;
  wrap.append(el);
  const q = $('.kf-q', el);
  q.oninput = () => { F.q = q.value; updateFind(false); if (F.matches.length) selectMatch(); };
  q.onkeydown = ev => { if (ev.key === 'Enter') { ev.preventDefault(); stepFind(ev.shiftKey ? -1 : 1); } };
  $('.kf-rep input', el).onkeydown = ev => { if (ev.key === 'Enter') { ev.preventDefault(); replaceOne(); } };
  $('.kf-next', el).onclick = () => stepFind(1); $('.kf-prev', el).onclick = () => stepFind(-1); $('.kf-close', el).onclick = closeFind;
  $('.kf-case', el).onclick = ev => { F.cs = !F.cs; ev.currentTarget.classList.toggle('on', F.cs); updateFind(false); if (F.matches.length) selectMatch(); };
  $('.kf-re', el).onclick = ev => { F.re = !F.re; ev.currentTarget.classList.toggle('on', F.re); updateFind(false); if (F.matches.length) selectMatch(); };
  $('.kf-r1', el).onclick = replaceOne; $('.kf-ra', el).onclick = replaceAll;
  const e = ED();
  e.addEventListener('scroll', syncMirror, { passive: true });
  e.addEventListener('input', () => { if (findOpen()) updateFind(true); });
  new ResizeObserver(syncMirror).observe(e);
}
function openFind(withReplace) {
  if (!needFile()) return; buildFind(); F.el.hidden = false; $('.kf-rep', F.el).hidden = !withReplace;
  const q = $('.kf-q', F.el), sel = ED().value.slice(ED().selectionStart, ED().selectionEnd);
  if (sel && !sel.includes('\n') && sel.length < 120) { q.value = sel; F.q = sel; }
  q.focus(); q.select(); updateFind(false);
}
function closeFind() { if (!F.el) return; F.el.hidden = true; paintMirror(); ED().focus(); }

/* ── Commandes (menus + palette) ─────────────────────────────────────────────────────────── */
const CMD = [], byId = {};
function cmd(id, title, cat, icon, kbd, run, o = {}) { const c = { id, title, cat, icon, kbd: kbd || '', run, ...o }; CMD.push(c); byId[id] = c; return c; }
const proxy = sel => () => { const b = $(sel); if (b) b.click(); };
const fileAction = a => proxy(`[data-file-action="${a}"]`);
const hasFile = () => !!curFile();
const wide = () => innerWidth > 980;
function showAgent() { document.body.classList.remove('knoagent'); pref.set('noagent', false); $('#agentPanel')?.classList.add('open'); }
function fill(text, send) {
  showAgent(); const m = $('#message'); if (!m) return;
  m.value = text; m.dispatchEvent(new Event('input', { bubbles: true })); m.focus(); m.setSelectionRange(text.length, text.length);
}
function setTab(k) {
  showAgent(); try { tab = k; renderRightTabs(); renderRight(); } catch (e) { console.warn(e); }
}
const THEME_LABEL = { system: 'Système', light: 'Clair', dark: 'Sombre', night: 'Bleu nuit' }, THEME_ICON = { system: 'theme', light: 'sun', dark: 'moon', night: 'moon' };
const PROMPTS = [
  ['resume', 'Résumer le projet', 'sparkle', () => 'Fais un résumé de ce projet : technologies, structure et points d’entrée. Utilise project_summary puis tree.'],
  ['tests', 'Lancer les tests', 'play', () => 'Lance les tests du projet avec run_tests et explique les échecs éventuels.'],
  ['todo', 'Chercher les TODO', 'list', () => 'Liste tous les TODO et FIXME du code avec find_todos et propose un ordre de priorité.'],
  ['git', 'État git', 'git', () => 'Montre l’état git (git_status), les derniers commits (git_log) et résume les changements en cours (git_diff).'],
  ['outline', 'Plan du fichier ouvert', 'code', () => `Donne le plan du fichier ${curFile()} avec outline_code, puis explique son rôle en quelques phrases.`, true],
  ['review', 'Relire le fichier ouvert', 'search-code', () => `Relis ${curFile()} (read_file) : signale les bugs, les cas limites oubliés et les améliorations possibles, sans rien modifier.`, true],
];

// Fichier
cmd('file.newProject', 'Nouveau projet', 'Fichier', 'plus', '', fileAction('new-project'));
cmd('file.openFolder', 'Ouvrir un dossier…', 'Fichier', 'folder-open', MOD + '+Maj+O', fileAction('open-folder'));
cmd('file.openFile', 'Ouvrir un fichier…', 'Fichier', 'file', MOD + '+O', fileAction('open-file'));
cmd('file.newFile', 'Nouveau fichier', 'Fichier', 'file', MOD + '+N', fileAction('new-file'));
cmd('file.newFolder', 'Nouveau dossier', 'Fichier', 'folder', MOD + '+Maj+N', fileAction('new-folder'));
cmd('file.save', 'Enregistrer', 'Fichier', 'save', MOD + '+S', fileAction('save'), { when: hasFile });
cmd('file.reload', 'Recharger depuis le disque', 'Fichier', 'refresh', '', proxy('#reloadFile'), { when: hasFile });
cmd('file.manage', 'Renommer ou supprimer le fichier…', 'Fichier', 'more', '', proxy('#fileMore'), { when: hasFile });
cmd('file.copyPath', 'Copier le chemin du fichier', 'Fichier', 'copy', '', () => copyText(curFile(), 'Chemin copié'), { when: hasFile });
// Édition
cmd('edit.find', 'Rechercher dans le fichier', 'Édition', 'search', MOD + '+F', () => openFind(false), { when: hasFile });
cmd('edit.replace', 'Rechercher et remplacer', 'Édition', 'search-code', MOD + '+H', () => openFind(true), { when: hasFile });
cmd('edit.goto', 'Aller à la ligne…', 'Édition', 'hash', MOD + '+G', () => openPalette('line'), { when: hasFile });
cmd('edit.duplicate', 'Dupliquer la ligne', 'Édition', 'copy', MOD + '+D', EDIT.duplicate, { when: hasFile });
cmd('edit.comment', 'Commenter / décommenter', 'Édition', 'code', MOD + '+/', EDIT.comment, { when: hasFile });
cmd('edit.moveUp', 'Déplacer la ligne vers le haut', 'Édition', 'arrow-up', 'Alt+↑', () => EDIT.move(-1), { when: hasFile });
cmd('edit.moveDown', 'Déplacer la ligne vers le bas', 'Édition', 'arrow-down', 'Alt+↓', () => EDIT.move(1), { when: hasFile });
cmd('edit.copyAll', 'Copier tout le contenu', 'Édition', 'copy', '', () => copyText(ED().value, 'Contenu copié'), { when: hasFile });
cmd('edit.formatJson', 'Mettre en forme le JSON', 'Édition', 'code', '', EDIT.formatJson, { when: () => hasFile() && extOf(curFile()) === 'json' });
cmd('edit.trim', 'Supprimer les espaces en fin de ligne', 'Édition', 'list', '', EDIT.trim, { when: hasFile });
// Affichage
for (const k of ['system', 'light', 'dark', 'night']) cmd('view.theme.' + k, 'Thème ' + THEME_LABEL[k].toLowerCase(), 'Affichage', THEME_ICON[k], '', () => { try { applyTheme(k); } catch {} }, { checked: () => curTheme() === k });
const fs = () => pref.get('fs', 13);
const setFs = v => { v = Math.max(10, Math.min(24, v)); pref.set('fs', v); document.documentElement.style.setProperty('--ed-fs', v + 'px'); syncMirror(); toast('Taille du texte : ' + v + ' px', 'info', 1200); };
cmd('view.zoomIn', 'Agrandir le texte de l’éditeur', 'Affichage', 'zoom-in', '', () => setFs(fs() + 1));
cmd('view.zoomOut', 'Réduire le texte de l’éditeur', 'Affichage', 'zoom-out', '', () => setFs(fs() - 1));
cmd('view.zoomReset', 'Taille du texte par défaut', 'Affichage', 'zoom-in', '', () => setFs(13));
cmd('view.compact', 'Mode compact', 'Affichage', 'compact', '', () => { const v = !pref.get('compact', false); pref.set('compact', v); document.body.classList.toggle('kcompact', v); }, { checked: () => pref.get('compact', false) });
cmd('view.left', 'Explorateur', 'Affichage', 'sidebar', '', () => { const v = !document.body.classList.contains('knoleft'); document.body.classList.toggle('knoleft', v); pref.set('noleft', v); }, { checked: () => !document.body.classList.contains('knoleft'), when: wide });
cmd('view.agent', 'Panneau Agent', 'Affichage', 'panel-right', '', () => {
  if (wide()) { const v = !document.body.classList.contains('knoagent'); document.body.classList.toggle('knoagent', v); pref.set('noagent', v); }
  else $('#agentPanel')?.classList.toggle('open');
}, { checked: () => wide() ? !document.body.classList.contains('knoagent') : !!$('#agentPanel')?.classList.contains('open') });
const TAB_ICON = { chat: 'agent', plan: 'list', timeline: 'clock', term: 'terminal', files: 'eye', mem: 'layers', mcp: 'globe', screen: 'eye', tools: 'tools' };
const tabIds = () => { try { return Object.keys(RIGHT); } catch { return []; } };
// Les onglets sont enregistrés une fois RIGHT enrichi (voir initToolsTab).
// Outils
cmd('tools.palette', 'Palette de commandes', 'Outils', 'command', MOD + '+K', () => openPalette('cmd'));
cmd('tools.catalog', 'Catalogue des outils de l’agent', 'Outils', 'tools', '', () => setTab('tools'));
cmd('tools.newConv', 'Nouvelle discussion', 'Outils', 'plus', '', proxy('#newConv'));
cmd('tools.settings', 'Paramètres…', 'Outils', 'settings', '', proxy('#settingsBtn'));
for (const [id, title, icon, text, needs] of PROMPTS) cmd('prompt.' + id, title, 'Actions rapides', icon, '', () => { if (needs && !needFile()) return; fill(text()); }, { sub: 'Prépare le message pour l’agent', hide: false });
// Aide
cmd('help.shortcuts', 'Raccourcis clavier', 'Aide', 'keyboard', '', () => $('#shortcuts')?.showModal());
cmd('help.about', 'À propos d’Astra Agent', 'Aide', 'info', '', () => openAbout());

const MENUS = [
  { label: 'Fichier', icon: 'file', items: ['file.newProject', 'file.openFolder', 'file.openFile', '-', 'file.newFile', 'file.newFolder', 'file.save', '-', 'file.reload', 'file.copyPath', 'file.manage'] },
  { label: 'Édition', icon: 'edit', items: ['edit.find', 'edit.replace', 'edit.goto', '-', 'edit.duplicate', 'edit.comment', 'edit.moveUp', 'edit.moveDown', '-', 'edit.formatJson', 'edit.trim', 'edit.copyAll'] },
  { label: 'Affichage', icon: 'eye', items: () => ['#Thème', 'view.theme.system', 'view.theme.light', 'view.theme.dark', 'view.theme.night', '-', '#Éditeur', 'view.zoomIn', 'view.zoomOut', 'view.zoomReset', '-', '#Panneaux', 'view.left', 'view.agent', 'view.compact', '-', '#Onglets de l’agent', ...tabIds().map(k => 'tab.' + k)] },
  { label: 'Outils', icon: 'tools', items: ['tools.palette', 'tools.catalog', 'tools.newConv', '-', '#Actions rapides', ...PROMPTS.map(p => 'prompt.' + p[0]), '-', 'tools.settings'] },
  { label: 'Aide', icon: 'help', items: ['help.shortcuts', 'help.about'] },
];

/* ── Barre de menus ──────────────────────────────────────────────────────────────────────── */
let OM = null; // menu ouvert : { btn, el, idx }
function closeMenu() { if (!OM) return; OM.el.remove(); OM.btn.classList.remove('open'); OM.btn.setAttribute('aria-expanded', 'false'); OM = null; }
function showMenu(btn, def) {
  closeMenu(); const el = document.createElement('div'); el.className = 'kmenu'; el.setAttribute('role', 'menu');
  const ids = typeof def.items === 'function' ? def.items() : def.items; let html = '';
  for (const id of ids) {
    if (id === '-') { html += '<div class="ksep" role="separator"></div>'; continue; }
    if (id[0] === '#') { html += `<div class="khead">${esc(id.slice(1))}</div>`; continue; }
    const c = byId[id]; if (!c) continue; const dis = c.when && !c.when(), on = c.checked && c.checked();
    html += `<button class="kitem" role="${c.checked ? 'menuitemcheckbox' : 'menuitem'}" data-id="${id}" ${c.checked ? `aria-checked="${!!on}"` : ''} ${dis ? 'aria-disabled="true"' : ''}>
      <span class="kic">${ic(c.icon)}</span><span class="klab">${esc(c.menuTitle || c.title)}</span>${c.kbd ? `<kbd>${esc(c.kbd)}</kbd>` : '<span></span>'}<span class="kck">${on ? ic('check') : ''}</span></button>`;
  }
  el.innerHTML = html; document.body.append(el);
  const r = btn.getBoundingClientRect(); el.style.top = (r.bottom + 4) + 'px'; el.style.left = Math.max(6, Math.min(r.left, innerWidth - el.offsetWidth - 8)) + 'px';
  btn.classList.add('open'); btn.setAttribute('aria-expanded', 'true'); OM = { btn, el, idx: -1, def };
  $$('.kitem', el).forEach((b, i) => { b.onmouseenter = () => setSel(i); b.onclick = () => { const c = byId[b.dataset.id]; closeMenu(); runCmd(c); }; });
}
const menuItems = () => OM ? $$('.kitem:not([aria-disabled=true])', OM.el) : [];
function setSel(i) { if (!OM) return; const it = menuItems(); $$('.kitem', OM.el).forEach(b => b.classList.remove('sel')); OM.idx = i; if (it[i]) { it[i].classList.add('sel'); it[i].scrollIntoView({ block: 'nearest' }); } }
function runCmd(c) { if (!c) return; if (c.when && !c.when()) return; try { const r = c.run(); if (r && r.catch) r.catch(e => toast(String(e.message || e), 'err')); } catch (e) { console.warn(e); toast('Action impossible : ' + (e.message || e), 'err'); } }
function buildBar() {
  const bar = document.createElement('div'); bar.className = 'kbar'; bar.setAttribute('role', 'menubar');
  const btns = MENUS.map(def => {
    const b = document.createElement('button'); b.className = 'kmb'; b.type = 'button'; b.setAttribute('aria-haspopup', 'menu'); b.setAttribute('aria-expanded', 'false'); b.innerHTML = ic(def.icon) + '<span>' + def.label + '</span>';
    b.onclick = ev => { ev.stopPropagation(); OM && OM.btn === b ? closeMenu() : showMenu(b, def); };
    b.onmouseenter = () => { if (OM && OM.btn !== b) showMenu(b, def); };
    bar.append(b); return b;
  });
  const sp = document.createElement('div'); sp.className = 'kspace'; bar.append(sp);
  const pal = document.createElement('button'); pal.className = 'kpal-btn'; pal.type = 'button'; pal.title = 'Palette de commandes (' + MOD + '+K)';
  pal.innerHTML = ic('search') + '<span>Rechercher ou lancer une commande…</span><kbd>' + MOD + ' K</kbd>'; pal.onclick = () => openPalette('cmd'); bar.append(pal);
  const mk = (icon, title, fn) => { const b = document.createElement('button'); b.className = 'kib'; b.type = 'button'; b.title = title; b.setAttribute('aria-label', title); b.innerHTML = ic(icon); b.onclick = fn; bar.append(b); return b; };
  const th = mk('theme', 'Changer de thème', () => { try { cycleTheme(); toast('Thème : ' + THEME_LABEL[curTheme()], 'info', 1300); } catch {} });
  mk('keyboard', 'Raccourcis clavier', () => byId['help.shortcuts'].run()); mk('settings', 'Paramètres', () => byId['tools.settings'].run());
  document.body.prepend(bar);
  document.addEventListener('mousedown', ev => { if (OM && !OM.el.contains(ev.target) && !OM.btn.contains(ev.target)) closeMenu(); }, true);
  addEventListener('blur', closeMenu); addEventListener('resize', closeMenu);
  return { th };
}

/* ── Palette de commandes ────────────────────────────────────────────────────────────────── */
const PAL = { el: null, mode: 'cmd', sel: 0, items: [] };
function score(hay, q) { // plus petit = meilleur ; null = aucune correspondance
  const h = norm(hay); let s = 0;
  for (const t of norm(q).split(/\s+/).filter(Boolean)) { const i = h.indexOf(t); if (i < 0) return null; s += i - (i > 0 && /[\s\/._-]/.test(h[i - 1]) ? 2 : 0); }
  return s;
}
function palItems(q) {
  const out = [], mode = PAL.mode;
  if (mode === 'line' || q.startsWith(':')) {
    const n = parseInt(q.replace(/^:/, ''), 10), max = hasFile() ? ED().value.split('\n').length : 0;
    out.push(!hasFile() ? { icon: 'warning', title: 'Ouvre d’abord un fichier', sub: '', run: () => {} } : { icon: 'hash', title: n ? `Aller à la ligne ${Math.min(n, max)}` : `Saisis un numéro de ligne (1 – ${max})`, sub: curFile(), run: () => { if (n) EDIT.goto(n); } });
    return out;
  }
  if (mode === 'cmd') {
    const cs = CMD.filter(c => !c.hide && (!c.when || c.when())).map(c => ({ c, s: q ? score(c.title + ' ' + c.cat, q) : 0 })).filter(x => x.s !== null).sort((a, b) => a.s - b.s);
    for (const { c } of cs) out.push({ icon: c.icon, title: c.title, sub: c.sub || c.cat, kbd: c.kbd, run: c.run });
  }
  if (mode === 'file' || (mode === 'cmd' && q.length >= 1)) {
    const fl = fileList().filter(p => !p.endsWith('/')).map(p => { const raw = q ? score(p, q) : 0; return { p, raw, s: (raw ?? 0) - (q && norm(p.split('/').pop()).includes(norm(q)) ? 6 : 0) }; }).filter(x => x.raw !== null).sort((a, b) => a.s - b.s || a.p.localeCompare(b.p));
    for (const { p } of fl.slice(0, mode === 'file' ? 60 : 6)) out.push({ icon: 'file', title: p.split('/').pop(), sub: p, run: () => { try { openFileInEditor(p); } catch {} } });
  }
  if (mode === 'cmd' && q.trim().length >= 3) out.push({ icon: 'sparkle', title: 'Demander à l’agent : « ' + q.trim().slice(0, 70) + ' »', sub: 'Prépare le message dans le panneau Agent', run: () => fill(q.trim()) });
  return out;
}
function palRender() {
  const list = $('.kpal-list', PAL.el), q = $('input', PAL.el).value; PAL.items = palItems(q); PAL.sel = Math.min(PAL.sel, Math.max(0, PAL.items.length - 1));
  list.innerHTML = PAL.items.length ? PAL.items.map((it, i) => `<div class="kpr ${i === PAL.sel ? 'sel' : ''}" role="option" data-i="${i}">${ic(it.icon)}<div><b>${esc(it.title)}</b>${it.sub ? `<small>${esc(it.sub)}</small>` : ''}</div>${it.kbd ? `<kbd>${esc(it.kbd)}</kbd>` : ''}</div>`).join('') : '<div class="kpal-empty">Aucun résultat</div>';
  $$('.kpr', list).forEach(r => { r.onmousemove = () => { if (PAL.sel !== +r.dataset.i) { PAL.sel = +r.dataset.i; $$('.kpr', list).forEach(x => x.classList.toggle('sel', x === r)); } }; r.onclick = () => palRun(+r.dataset.i); });
}
function palRun(i) { const it = PAL.items[i]; if (!it) return; closePalette(); setTimeout(() => it.run(), 0); }
function openPalette(mode = 'cmd', initial = '') {
  closeMenu(); closePalette(); PAL.mode = mode; PAL.sel = 0;
  const ov = PAL.el = document.createElement('div'); ov.className = 'kov';
  const ph = { cmd: 'Tape une commande, un fichier, ou « : » + n° de ligne…', file: 'Ouvrir un fichier du projet…', line: 'Numéro de ligne…' }[mode];
  ov.innerHTML = `<div class="kpal" role="dialog" aria-modal="true" aria-label="Palette de commandes"><div class="kpal-in">${ic(mode === 'file' ? 'file' : mode === 'line' ? 'hash' : 'command')}<input autocomplete="off" spellcheck="false" placeholder="${ph}" aria-label="${ph}"></div>
    <div class="kpal-list" role="listbox"></div><div class="kpal-foot"><span><kbd>↑</kbd><kbd>↓</kbd> naviguer</span><span><kbd>↵</kbd> valider</span><span><kbd>Échap</kbd> fermer</span></div></div>`;
  document.body.append(ov); const inp = $('input', ov); inp.value = initial;
  ov.addEventListener('mousedown', e => { if (e.target === ov) closePalette(); });
  inp.addEventListener('input', () => { PAL.sel = 0; palRender(); });
  inp.addEventListener('keydown', e => {
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); const n = PAL.items.length; if (!n) return; PAL.sel = (PAL.sel + (e.key === 'ArrowDown' ? 1 : -1) + n) % n; palRender(); $('.kpr.sel', ov)?.scrollIntoView({ block: 'nearest' }); }
    else if (e.key === 'Enter') { e.preventDefault(); palRun(PAL.sel); }
  });
  palRender(); inp.focus();
}
function closePalette() { if (!PAL.el) return; PAL.el.remove(); PAL.el = null; }

/* ── À propos ────────────────────────────────────────────────────────────────────────────── */
async function openAbout() {
  let d = $('#kabout'); if (!d) { d = document.createElement('dialog'); d.id = 'kabout'; d.className = 'kabout'; document.body.append(d); d.addEventListener('click', e => { if (e.target === d) d.close(); }); }
  let v = '', n = 0; try { const r = await loadTools(); v = r.version; n = r.tools.length; } catch {}
  d.innerHTML = `<div class="top"><img src="mascot.svg" alt=""><div><h3>ASTRA AGENT</h3><div class="ver">Version ${esc(v || '—')} · ${n || '—'} outils pour l’agent</div></div></div>
    <p style="margin:0;color:var(--muted)">Plateforme d’agents IA locale, sans dépendance : Node.js suffit.</p>
    <ul><li>Barre de menus, palette de commandes (${MOD}+K) et notifications</li><li>Éditeur : recherche/remplacement, déplacer et dupliquer les lignes, commentaires, indentation</li><li>Onglet <b>Outils</b> : catalogue complet avec niveaux de permission</li><li>15 nouveaux outils : regex, arbre, git, plan de code, CSV, hash…</li></ul>
    <div class="foot"><button class="action primary" id="kabout-ok">Fermer</button></div>`;
  $('#kabout-ok', d).onclick = () => d.close(); d.showModal();
}

/* ── Catalogue d'outils (onglet « Outils ») ──────────────────────────────────────────────── */
let TOOLS = null, toolQ = '', toolCat = 'Tous';
async function loadTools() { if (TOOLS) return TOOLS; try { TOOLS = await (await fetch('/api/tools')).json(); } catch { TOOLS = { tools: [], version: '' }; } return TOOLS; }
function renderTools(q) {
  q.innerHTML = '<div class="kt-wrap"><div class="panel-note">Chargement des outils…</div></div>';
  loadTools().then(d => {
    if (curTab() !== 'tools') return;
    const cats = ['Tous', ...[...new Set(d.tools.map(t => t.cat))]];
    q.innerHTML = `<div class="kt-wrap"><div class="kt-top"><label class="kt-search">${ic('search')}<input id="ktq" placeholder="Filtrer les ${d.tools.length} outils…" value="${esc(toolQ)}" aria-label="Filtrer les outils"></label><span class="kt-count" id="ktn"></span></div>
      <div class="kt-chips" id="ktc"></div><div id="ktl" style="display:grid;gap:8px"></div></div>`;
    const paint = () => {
      const f = norm(toolQ), list = d.tools.filter(t => (toolCat === 'Tous' || t.cat === toolCat) && (!f || norm(t.name + ' ' + t.desc + ' ' + t.cat).includes(f)));
      $('#ktn', q).textContent = list.length + ' outil' + (list.length > 1 ? 's' : '');
      $('#ktc', q).innerHTML = cats.map(c => `<button class="kt-chip ${c === toolCat ? 'on' : ''}" data-c="${esc(c)}">${esc(c)}${c === 'Tous' ? '' : ' · ' + d.tools.filter(t => t.cat === c).length}</button>`).join('');
      $$('.kt-chip', q).forEach(b => b.onclick = () => { toolCat = b.dataset.c; paint(); });
      let html = '', last = '';
      for (const t of list) {
        if (t.cat !== last && toolCat === 'Tous') { html += `<div class="kt-cat">${esc(t.cat)}</div>`; last = t.cat; }
        html += `<div class="kt-card"><div class="kt-head"><code>${esc(t.name)}</code><span class="grow"></span><span class="kt-badge ${esc(t.level)}" title="${t.level === 'variable' ? 'Dépend de la commande ou de la cible' : 'Niveau de permission habituel'}">${t.level === 'variable' ? 'SELON CONTEXTE' : esc(t.level)}</span></div>
          <div class="kt-desc">${esc(t.desc)}</div>${t.args ? `<div class="kt-args">${esc(t.args)}</div>` : ''}<button class="kt-use" data-n="${esc(t.name)}">${ic('sparkle')} Demander à l’agent de l’utiliser</button></div>`;
      }
      $('#ktl', q).innerHTML = html || '<div class="panel-note">Aucun outil ne correspond.</div>';
      $$('.kt-use', q).forEach(b => b.onclick = () => fill(`Utilise l’outil ${b.dataset.n} pour `));
    };
    $('#ktq', q).oninput = e => { toolQ = e.target.value; paint(); };
    paint();
  });
}
function initToolsTab() {
  const s = RIGHT.screen; delete RIGHT.screen; RIGHT.tools = 'Outils'; if (s) RIGHT.screen = s;
  const orig = window.renderRight;
  window.renderRight = function () { return curTab() === 'tools' ? renderTools($('#rightContent')) : orig.apply(this, arguments); };
  for (const k of tabIds()) cmd('tab.' + k, 'Onglet ' + RIGHT[k], 'Affichage', TAB_ICON[k] || 'eye', '', () => setTab(k), { checked: () => curTab() === k, menuTitle: RIGHT[k] });
  renderRightTabs();
}

/* ── Accueil (aucun fichier ouvert) ──────────────────────────────────────────────────────── */
function initWelcome() {
  const wrap = $('.editor-wrap'), ed = ED(); if (!wrap || !ed) return;
  const w = document.createElement('div'); w.className = 'kwelcome';
  w.innerHTML = `<div class="kw-in"><img src="mascot.svg" alt=""><h2>ASTRA AGENT</h2><p>Ouvre un projet, ou demande directement à l’agent.</p><div class="kw-grid">
    <button class="kw-card" data-c="file.openFolder">${ic('folder-open')}<span><b>Ouvrir un dossier</b><small>${MOD}+Maj+O</small></span></button>
    <button class="kw-card" data-c="file.newFile">${ic('file')}<span><b>Nouveau fichier</b><small>${MOD}+N</small></span></button>
    <button class="kw-card" data-c="tools.palette">${ic('command')}<span><b>Palette de commandes</b><small>${MOD}+K</small></span></button>
    <button class="kw-card" data-c="tools.catalog">${ic('tools')}<span><b>Catalogue d’outils</b><small>Ce que l’agent sait faire</small></span></button></div>
    <div class="kw-foot" id="kw-foot"></div></div>`;
  wrap.append(w); $$('.kw-card', w).forEach(b => b.onclick = () => runCmd(byId[b.dataset.c]));
  const sync = () => { w.hidden = !ed.classList.contains('placeholder'); };
  new MutationObserver(sync).observe(ed, { attributes: true, attributeFilter: ['class'] }); sync();
  loadTools().then(d => { if (d.tools.length) $('#kw-foot', w).textContent = d.tools.length + ' outils · version ' + d.version; });
}

/* ── Barre d'état de l'éditeur ───────────────────────────────────────────────────────────── */
const LANG = { js: 'JavaScript', mjs: 'JavaScript', cjs: 'JavaScript', jsx: 'JSX', ts: 'TypeScript', tsx: 'TSX', py: 'Python', gd: 'GDScript', json: 'JSON', md: 'Markdown', html: 'HTML', htm: 'HTML', css: 'CSS', scss: 'SCSS', c: 'C', h: 'C', cpp: 'C++', hpp: 'C++', cs: 'C#', java: 'Java', rs: 'Rust', go: 'Go', php: 'PHP', rb: 'Ruby', sh: 'Shell', yml: 'YAML', yaml: 'YAML', toml: 'TOML', sql: 'SQL', txt: 'Texte', tscn: 'Godot scène', tres: 'Godot ressource', xml: 'XML', csv: 'CSV' };
function initStatus() {
  const st = $('.editor-status'), e = ED(); if (!st || !e) return;
  const anchor = $('#saveState'), mk = (id, cls = '') => { const s = document.createElement('span'); s.id = id; s.className = 'kstat ' + cls; anchor ? st.insertBefore(s, anchor) : st.append(s); return s; };
  const pos = mk('kPos', 'btn'), size = mk('kSize'), lang = mk('kLang'); pos.title = 'Aller à la ligne (' + MOD + '+G)'; pos.onclick = () => openPalette('line');
  let raf = 0;
  const upd = () => {
    raf = 0; if (!curFile()) { pos.textContent = lang.textContent = size.textContent = ''; return; }
    const v = e.value, p = e.selectionStart, ln = v.slice(0, p).split('\n').length, col = p - (v.lastIndexOf('\n', p - 1) + 1) + 1, n = e.selectionEnd - p;
    pos.textContent = `Ln ${ln}, Col ${col}` + (n ? ` (${n} sél.)` : ''); lang.textContent = LANG[extOf(curFile())] || extOf(curFile()).toUpperCase();
    const b = new Blob([v]).size; size.textContent = (b < 1024 ? b + ' o' : (b / 1024).toFixed(1) + ' Ko') + ' · ' + v.split('\n').length + ' lignes';
  };
  const q = () => { if (!raf) raf = requestAnimationFrame(upd); };
  ['keyup', 'click', 'input', 'focus', 'mouseup'].forEach(t => e.addEventListener(t, q));
  new MutationObserver(q).observe(e, { attributes: true, attributeFilter: ['class'] }); const ft = $('#fileTab'); if (ft) new MutationObserver(q).observe(ft, { childList: true, subtree: true });
  const ss = $('#saveState'); if (ss) new MutationObserver(() => { if (/Enregistré/.test(ss.textContent)) toast('Fichier enregistré', 'ok', 1500); }).observe(ss, { childList: true, characterData: true, subtree: true });
  q();
}

/* ── Raccourcis clavier (phase de capture : prioritaires, sans toucher aux existants) ───── */
function initKeys() {
  addEventListener('keydown', e => {
    const mod = e.ctrlKey || e.metaKey, k = e.key.toLowerCase(), t = e.target, inEd = t === ED(), inFind = !!(F.el && F.el.contains(t));
    if (e.key === 'Escape') {
      if (PAL.el) { stop(e); return closePalette(); }
      if (OM) { stop(e); return closeMenu(); }
      if (findOpen() && (inEd || inFind)) { stop(e); return closeFind(); }
      return;
    }
    if (OM) { // navigation clavier dans un menu ouvert
      const it = menuItems(), n = it.length;
      if (e.key === 'ArrowDown') { stop(e); return setSel((OM.idx + 1) % n); }
      if (e.key === 'ArrowUp') { stop(e); return setSel((OM.idx - 1 + n) % n); }
      if (e.key === 'Enter' && it[OM.idx]) { stop(e); const c = byId[it[OM.idx].dataset.id]; closeMenu(); return runCmd(c); }
      if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') { stop(e); const bs = $$('.kmb'), i = bs.indexOf(OM.btn), nb = bs[(i + (e.key === 'ArrowRight' ? 1 : -1) + bs.length) % bs.length]; showMenu(nb, MENUS[bs.indexOf(nb)]); return setSel(0); }
    }
    if (PAL.el) return; // la palette gère ses propres touches
    if (mod && k === 'k') { stop(e); return openPalette('cmd'); }
    if (mod && k === 'p') { stop(e); return openPalette(e.shiftKey ? 'cmd' : 'file'); }
    if (e.key === 'F10' && !mod) { stop(e); return $('.kmb')?.click(); }
    const editorCtx = inEd || inFind || (curFile() && (t === document.body || t === document.documentElement));
    if (mod && !e.shiftKey && k === 'f' && editorCtx) { stop(e); return openFind(false); }
    if (mod && !e.shiftKey && k === 'h' && editorCtx) { stop(e); return openFind(true); }
    if (!inEd) return;
    if (mod && !e.shiftKey && k === 'g') { stop(e); return openPalette('line'); }
    if (mod && !e.shiftKey && k === 'd') { stop(e); return EDIT.duplicate(); }
    if (mod && (e.key === '/' || e.code === 'Slash')) { stop(e); return EDIT.comment(); }
    if (e.altKey && !mod && e.key === 'ArrowUp') { stop(e); return EDIT.move(-1); }
    if (e.altKey && !mod && e.key === 'ArrowDown') { stop(e); return EDIT.move(1); }
    if (e.key === 'Tab' && !mod && !e.altKey) { stop(e); return EDIT.indent(e.shiftKey); }
    if (e.key === 'Enter' && !mod && !e.altKey && !e.shiftKey && !e.isComposing) { stop(e); return EDIT.enter(); }
    if (mod && (e.key === '+' || e.key === '=')) { stop(e); return setFs(fs() + 1); }
    if (mod && e.key === '-') { stop(e); return setFs(fs() - 1); }
    if (mod && e.key === '0') { stop(e); return setFs(13); }
  }, true);
  // Remplace le prompt() de quickOpen() par la palette (les appels existants en profitent aussi).
  window.quickOpen = () => openPalette('file');
}

/* ── Petites retouches de l'existant ─────────────────────────────────────────────────────── */
function polish() {
  const set = (sel, icon) => { const b = $(sel); if (b) b.innerHTML = ic(icon); };
  set('#mic', 'mic'); set('#send', 'send'); set('#closeAgentPanel', 'close'); set('#openAgentPanel', 'panel-right'); set('#fileMore', 'more'); set('#shortcutsBtn', 'keyboard');
  $('#send')?.setAttribute('aria-label', 'Envoyer'); $('#mic')?.setAttribute('aria-label', 'Dictée vocale');
  const list = $('#shortcuts .list');
  if (list) {
    const rows = [[MOD + '+K', 'Palette de commandes'], [MOD + '+P', 'Ouvrir un fichier (recherche rapide)'], [MOD + '+F', 'Rechercher dans le fichier'], [MOD + '+H', 'Rechercher et remplacer'], [MOD + '+G', 'Aller à la ligne'], [MOD + '+D', 'Dupliquer la ligne'], [MOD + '+/', 'Commenter / décommenter'], ['Alt+↑ / ↓', 'Déplacer la ligne'], ['Tab / Maj+Tab', 'Indenter / désindenter'], ['F10', 'Ouvrir la barre de menus']];
    list.insertAdjacentHTML('beforeend', rows.map(r => `<div class="list-row"><b>${esc(r[0])}</b><small>${esc(r[1])}</small></div>`).join(''));
  }
  // Actions rapides au-dessus du composeur
  const comp = $('#composer');
  if (comp && !$('.kchips', comp)) {
    const ch = document.createElement('div'); ch.className = 'kchips'; ch.setAttribute('aria-label', 'Actions rapides');
    ch.innerHTML = PROMPTS.slice(0, 5).map(p => `<button type="button" class="kchip" data-p="${p[0]}">${ic(p[2])}${esc(p[1])}</button>`).join('');
    comp.insertBefore(ch, comp.firstChild); $$('.kchip', ch).forEach(b => b.onclick = () => runCmd(byId['prompt.' + b.dataset.p]));
  }
}

/* ── Démarrage ───────────────────────────────────────────────────────────────────────────── */
function init() {
  document.documentElement.style.setProperty('--ed-fs', pref.get('fs', 13) + 'px');
  document.body.classList.toggle('kcompact', pref.get('compact', false));
  document.body.classList.toggle('knoagent', pref.get('noagent', false));
  document.body.classList.toggle('knoleft', pref.get('noleft', false));
  guard('onglet outils', initToolsTab);
  guard('barre de menus', buildBar);
  guard('recherche', buildFind);
  guard('accueil', initWelcome);
  guard('statut', initStatus);
  guard('retouches', polish);
  guard('raccourcis', initKeys);
  window.AstraUI = { toast, openPalette, registerCommand: cmd, commands: CMD };
  window.KairoUI = window.AstraUI; // compatibilité avec les extensions historiques
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
