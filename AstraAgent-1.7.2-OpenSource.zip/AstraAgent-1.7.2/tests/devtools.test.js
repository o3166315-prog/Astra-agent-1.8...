// Tests des outils de développement 1.7.2 (node tests/devtools.test.js) : vrais fichiers, vraies permissions, aucun modèle.
const assert = require('node:assert/strict'), fs = require('fs'), os = require('os'), path = require('path'), http = require('http'), { spawnSync } = require('child_process');
const { tools } = require('../server/tools'), perms = require('../server/perms'), { META } = require('../server/extratools');
const { parseYaml, parseToml, parseIni, parseEnv, zipCreate, zipRead } = require('../server/devtools'), vision = require('../server/vision');
const root = fs.mkdtempSync(path.join(os.tmpdir(), 'astra-dt-')), ctx = { root, emit() {}, created: new Set() };
const run = (n, a) => tools[n].run(a || {}, ctx), txt = r => String(r && r.text !== undefined ? r.text : r), rd = f => fs.readFileSync(path.join(root, f), 'utf8');
const rejects = async (p, re) => { try { await p; } catch (e) { assert.match(e.message, re); return; } assert.fail('aurait dû échouer'); };
const lvl = (n, a) => perms.classifyTool(n, a, { root, created: new Set() }).level;
const NEW = ['git_commit', 'git_branch', 'project_deps', 'env_keys', 'config_query', 'lint_code', 'port_check', 'duplicate_code', 'convert_image', 'archive_files'];
let ok = 0; const T = async (n, f) => { await f(); ok++; console.log('  ✓', n); };

(async () => {
  await run('write_file', { path: 'src/app.js', content: 'const a = 1;\nfunction clamp(v, min, max) {\n  if (v < min) return min;\n  if (v > max) return max;\n  return v;\n}\n' });

  // ------------------------------------------------------------------ configuration
  await T('config_query : JSON, YAML, TOML, INI et .env', async () => {
    await run('write_file', { path: 'conf.json', content: JSON.stringify({ scripts: { test: 'npm test' }, items: [{ name: 'n0' }] }) });
    assert.equal(JSON.parse(txt(await run('config_query', { path: 'conf.json', query: 'scripts.test' }))), 'npm test');
    assert.equal(JSON.parse(txt(await run('config_query', { path: 'conf.json', query: 'items[0].name' }))), 'n0');
    await run('write_file', { path: 'conf.yaml', content: 'server:\n  port: 8080\n  host: localhost\nfeatures:\n  - alpha\n  - beta\nname: astra\n' });
    assert.equal(JSON.parse(txt(await run('config_query', { path: 'conf.yaml', query: 'server.port' }))), 8080);
    assert.deepEqual(JSON.parse(txt(await run('config_query', { path: 'conf.yaml', query: 'features' }))), ['alpha', 'beta']);
    await run('write_file', { path: 'conf.toml', content: '[server]\nport = 3000\nname = "astra"\n\n[tools]\nenabled = true\n' });
    assert.equal(JSON.parse(txt(await run('config_query', { path: 'conf.toml', query: 'server.port' }))), 3000);
    assert.equal(JSON.parse(txt(await run('config_query', { path: 'conf.toml', query: 'tools.enabled' }))), true);
    await run('write_file', { path: 'conf.ini', content: '; commentaire\n[web]\nport=9000\n' });
    assert.equal(JSON.parse(txt(await run('config_query', { path: 'conf.ini', query: 'web.port' }))), '9000');
    await run('write_file', { path: '.env', content: 'API_URL=https://api.exemple.fr\n' });
    assert.equal(JSON.parse(txt(await run('config_query', { path: '.env', query: 'API_URL' }))), 'https://api.exemple.fr');
    assert.match(txt(await run('config_query', { path: 'conf.json' })), /clés : scripts, items/);
    await rejects(run('config_query', { path: 'conf.json', query: 'nope' }), /introuvable/);
    await run('write_file', { path: 'conf.txt', content: 'texte' });
    await rejects(run('config_query', { path: 'conf.txt' }), /Format non pris en charge/);
  });

  await T('parseurs : YAML, TOML, INI et .env (sous-ensembles documentés)', async () => {
    assert.deepEqual(parseYaml('a: 1\nb:\n  - x\n  - y\nc:\n  d: true\n'), { a: 1, b: ['x', 'y'], c: { d: true } });
    assert.deepEqual(parseYaml('# commentaire\nurl: http://x.fr/a\n'), { url: 'http://x.fr/a' });
    assert.deepEqual(parseToml('[a]\nb = 1\nc = "deux"\nd = [1, 2]\n'), { a: { b: 1, c: 'deux', d: [1, 2] } });
    assert.deepEqual(parseIni('[s]\nk=v\n'), { s: { k: 'v' } });
    assert.deepEqual(parseEnv('A=1\nexport B=2\n#c\n'), { A: '1', B: '2' });
    assert.throws(() => parseYaml('a: |\n  bloc\n'), /non prise en charge/);
    assert.throws(() => parseToml('pas une clé\n'), /non pris en charge/);
  });

  // ------------------------------------------------------------------ secrets
  await T('env_keys : les valeurs ne sont jamais affichées', async () => {
    await run('write_file', { path: '.env', content: 'API_URL=https://api.exemple.fr\nSECRET_TOKEN=super-secret-value\nEMPTY=\n' });
    const out = txt(await run('env_keys', {}));
    assert.match(out, /API_URL/);
    assert.match(out, /SENSIBLE/);
    assert.doesNotMatch(out, /super-secret-value/);
    assert.doesNotMatch(out, /api\.exemple\.fr/);
    assert.match(out, /EMPTY = \*\*\* \(vide/);
    fs.mkdirSync(path.join(root, 'vide'), { recursive: true });
    assert.match(txt(await run('env_keys', { path: 'vide' })), /Aucun fichier \.env/);
  });

  // ------------------------------------------------------------------ dépendances
  await T('project_deps : dépendances déclarées vs installées', async () => {
    await run('write_file', { path: 'package.json', content: JSON.stringify({ name: 'demo', dependencies: { left: '^1.0.0', ghost: '^2.0.0' }, devDependencies: { dev: '^3.0.0' } }, null, 2) });
    fs.mkdirSync(path.join(root, 'node_modules', 'left'), { recursive: true });
    fs.writeFileSync(path.join(root, 'node_modules', 'left', 'package.json'), JSON.stringify({ name: 'left', version: '1.2.0' }));
    const out = txt(await run('project_deps', {}));
    assert.match(out, /left 1\.2\.0/);
    assert.match(out, /ghost .*non installée/);
    assert.match(out, /dépendances \(2\)/);
    await run('write_file', { path: 'requirements.txt', content: 'flask==3.0.0\n# commentaire\n' });
    assert.match(txt(await run('project_deps', {})), /flask==3\.0\.0/);
  });

  // ------------------------------------------------------------------ git
  await T('git_commit : indexe puis crée un commit', async () => {
    const g = a => spawnSync('git', a, { cwd: root, encoding: 'utf8', windowsHide: true });
    assert.equal(g(['init', '-q']).status, 0);
    await run('write_file', { path: 'a.txt', content: 'bonjour\n' });
    const out = txt(await run('git_commit', { message: 'Premier commit', add: true }));
    assert.match(out, /Commit [0-9a-f]{7,} créé/);
    assert.match(out, /Sujet : Premier commit/);
    assert.equal(g(['log', '--oneline']).stdout.trim().split('\n').length, 1);
    assert.equal(g(['log', '-1', '--format=%s']).stdout.trim(), 'Premier commit');
    await rejects(run('git_commit', { message: 'Rien à faire' }), /Rien à indexer/);
    await rejects(run('git_commit', { message: '' }), /message de commit manquant/);
  });

  await T('git_branch : liste, création, bascule et suppression', async () => {
    const g = a => spawnSync('git', a, { cwd: root, encoding: 'utf8', windowsHide: true });
    const current = g(['rev-parse', '--abbrev-ref', 'HEAD']).stdout.trim();
    assert.match(txt(await run('git_branch', { action: 'list' })), /branche courante : /);
    await run('git_branch', { action: 'create', name: 'feature/test' });
    assert.match(txt(await run('git_branch', { action: 'list' })), /feature\/test/);
    await rejects(run('git_branch', { action: 'create', name: 'feature/test' }), /git branch/);
    await rejects(run('git_branch', { action: 'create', name: 'nom invalide' }), /invalide/);
    await rejects(run('git_branch', { action: 'bim' }), /action inconnue/);
    assert.match(txt(await run('git_branch', { action: 'switch', name: 'feature/test' })), /Branche active/);
    await run('git_branch', { action: 'switch', name: current });
    assert.match(txt(await run('git_branch', { action: 'delete', name: 'feature/test' })), /Branche supprimée/);
    assert.doesNotMatch(txt(await run('git_branch', { action: 'list' })), /feature\/test/);
  });

  // ------------------------------------------------------------------ lint
  await T('lint_code : lecture seule, aucun fichier modifié', async () => {
    const before = rd('src/app.js');
    try {
      const out = txt(await run('lint_code', {}));
      assert.ok(out.length > 0, 'sortie vide');
    } catch (e) { assert.match(e.message, /Aucun linter détecté/); }
    assert.equal(rd('src/app.js'), before);
  });

  // ------------------------------------------------------------------ ports
  await T('port_check : port ouvert, port fermé et liste', async () => {
    const srv = http.createServer((q, r) => r.end('ok'));
    await new Promise(res => srv.listen(0, '127.0.0.1', res));
    const port = srv.address().port;
    assert.match(txt(await run('port_check', { port })), /ouvert/);
    await new Promise(res => srv.close(res));
    assert.match(txt(await run('port_check', { port })), /fermé/);
    assert.ok(txt(await run('port_check', { list: true })).length > 0);
    await rejects(run('port_check', { port: 0 }), /invalide/);
  });

  // ------------------------------------------------------------------ code dupliqué
  await T('duplicate_code : détection des blocs copier-coller', async () => {
    const block = ['function clamp(v, min, max) {', '  if (v < min) return min;', '  if (v > max) return max;', '  return v;', '}'];
    await run('write_file', { path: 'dup/a.js', content: block.join('\n') + '\nconst x = 1;\n' });
    await run('write_file', { path: 'dup/b.js', content: 'const y = 2;\n' + block.join('\n') + '\n' });
    const out = txt(await run('duplicate_code', { path: 'dup', minLines: 4 }));
    assert.match(out, /Blocs dupliqués détectés/);
    assert.match(out, /a\.js/);
    assert.match(out, /b\.js/);
    assert.match(out, /lignes dupliquées/);
  });

  // ------------------------------------------------------------------ images
  await T('convert_image : PNG réel vers PNG, PPM, BMP et TXT', async () => {
    const w = 8, h = 4, rgb = Buffer.alloc(w * h * 3);
    for (let i = 0; i < w * h; i++) { rgb[i * 3] = (i * 30) % 256; rgb[i * 3 + 1] = 120; rgb[i * 3 + 2] = 200; }
    fs.writeFileSync(path.join(root, 'img.png'), vision.encodeRGB(w, h, rgb));
    assert.match(txt(await run('convert_image', { path: 'img.png', out: 'out.png', format: 'png' })), /Image convertie/);
    assert.deepEqual([...fs.readFileSync(path.join(root, 'out.png')).subarray(0, 8)], [137, 80, 78, 71, 13, 10, 26, 10]);
    await run('convert_image', { path: 'img.png', out: 'out.ppm', format: 'ppm' });
    assert.match(fs.readFileSync(path.join(root, 'out.ppm')).toString('latin1').slice(0, 16), /^P6\n8 4\n255\n/);
    await run('convert_image', { path: 'img.png', out: 'out.bmp', format: 'bmp' });
    const bmp = fs.readFileSync(path.join(root, 'out.bmp'));
    assert.equal(bmp.toString('latin1', 0, 2), 'BM');
    assert.equal(bmp.readInt32LE(18), 8);
    assert.equal(bmp.readInt32LE(22), 4);
    await run('convert_image', { path: 'img.png', out: 'out.txt', format: 'txt' });
    assert.ok(fs.readFileSync(path.join(root, 'out.txt'), 'utf8').length > 10);
    await rejects(run('convert_image', { path: 'img.png', format: 'webp' }), /format inconnu/);
    await rejects(run('convert_image', { path: 'img.png', out: '.kairo/x.png' }), /interne/);
  });

  // ------------------------------------------------------------------ archives
  await T('archive_files : création, liste et extraction ZIP', async () => {
    await run('write_file', { path: 'src/one.txt', content: 'un\n' });
    await run('write_file', { path: 'src/deux/two.txt', content: 'deux\n' });
    assert.match(txt(await run('archive_files', { action: 'create', path: 'src', out: 'archive.zip' })), /Archive créée/);
    assert.ok(fs.existsSync(path.join(root, 'archive.zip')));
    const l = txt(await run('archive_files', { action: 'list', path: 'archive.zip' }));
    assert.match(l, /one\.txt/);
    assert.match(l, /deux\/two\.txt/);
    assert.match(txt(await run('archive_files', { action: 'extract', path: 'archive.zip', out: 'extrait' })), /Archive extraite/);
    assert.equal(fs.readFileSync(path.join(root, 'extrait', 'one.txt'), 'utf8'), 'un\n');
    assert.equal(fs.readFileSync(path.join(root, 'extrait', 'deux', 'two.txt'), 'utf8'), 'deux\n');
  });

  await T('archive_files : refus de la traversée de chemin (zip-slip)', async () => {
    fs.writeFileSync(path.join(root, 'evil.zip'), zipCreate([{ name: '../evade.txt', data: Buffer.from('x') }]));
    await rejects(run('archive_files', { action: 'extract', path: 'evil.zip', out: 'dest' }), /refusée/);
    assert.ok(!fs.existsSync(path.join(root, 'evade.txt')));
    fs.writeFileSync(path.join(root, 'abs.zip'), zipCreate([{ name: '/etc/evade.txt', data: Buffer.from('x') }]));
    await rejects(run('archive_files', { action: 'extract', path: 'abs.zip', out: 'dest2' }), /refusée/);
  });

  await T('ZIP : écriture et relecture avec CRC correct', async () => {
    const buf = zipCreate([{ name: 'a.txt', data: Buffer.from('bonjour') }, { name: 'b/c.txt', data: Buffer.from('monde') }]);
    const entries = zipRead(buf);
    assert.equal(entries.length, 2);
    assert.equal(entries[0].name, 'a.txt');
    assert.equal(entries[0].data.toString(), 'bonjour');
    assert.equal(entries[1].data.toString(), 'monde');
    assert.throws(() => zipRead(Buffer.from('pas une archive')), /ZIP illisible/);
  });

  // ------------------------------------------------------------------ registre et permissions
  await T('registre : les 10 nouveaux outils sont présents et documentés', async () => {
    for (const n of NEW) {
      assert.ok(tools[n], 'outil manquant : ' + n);
      assert.ok(typeof tools[n].desc === 'string' && tools[n].desc.length > 10, 'description manquante : ' + n);
      assert.match(tools[n].desc, /args:/, 'arguments non documentés : ' + n);
      assert.ok(typeof tools[n].run === 'function', 'run manquant : ' + n);
      assert.ok(META[n], 'META manquant : ' + n);
      const c = perms.classifyTool(n, {}, { root, created: new Set() });
      assert.notEqual(c.reason, 'outil non classé : ' + n, 'outil non classé : ' + n);
    }
  });

  await T('permissions : niveaux attendus pour chaque nouvel outil', async () => {
    assert.equal(lvl('git_commit', { message: 'x' }), 'CONFIRM');
    assert.equal(lvl('git_branch', { action: 'list' }), 'SAFE');
    assert.equal(lvl('git_branch', { action: 'create', name: 'x' }), 'CONFIRM');
    assert.equal(lvl('git_branch', { action: 'delete', name: 'x' }), 'CONFIRM');
    assert.equal(lvl('git_branch', { action: 'delete', name: 'x', force: true }), 'DANGER');
    assert.equal(lvl('project_deps', {}), 'SAFE');
    assert.equal(lvl('env_keys', {}), 'SAFE');
    assert.equal(lvl('config_query', { path: 'conf.json' }), 'SAFE');
    assert.equal(lvl('lint_code', {}), 'CONFIRM');
    assert.equal(lvl('port_check', { port: 80 }), 'SAFE');
    assert.equal(lvl('port_check', { port: 80, host: 'exemple.fr' }), 'CONFIRM');
    assert.equal(lvl('duplicate_code', {}), 'SAFE');
    assert.equal(lvl('convert_image', { path: 'img.png' }), 'SAFE');
    assert.equal(lvl('archive_files', { action: 'create', path: '.' }), 'SAFE');
    assert.equal(lvl('archive_files', { action: 'extract', path: 'a.zip' }), 'CONFIRM');
    assert.equal(lvl('env_keys', { path: '/etc' }), 'CONFIRM');
  });

  console.log(`\n${ok} tests OK`);
})().catch(e => { console.error('✗', e.message); process.exit(1); });
